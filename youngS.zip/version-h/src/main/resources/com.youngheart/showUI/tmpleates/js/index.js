document.addEventListener('DOMContentLoaded', function() {
    const startButton = document.getElementById('start-button');
    startButton.addEventListener('click', function() {
        window.location.href = 'core.html';
    });

    const bgm = document.getElementById('bgm');
    const musicControl = document.querySelector('.music-control');
    let isPlaying = false;

    musicControl.addEventListener('click', function() {
        if (isPlaying) {
            bgm.pause();
            musicControl.classList.remove('music-playing');
        } else {
            bgm.play();
            musicControl.classList.add('music-playing');
        }
        isPlaying = !isPlaying;
    });

    const volumeSlider = document.querySelector('.volume-slider');
    volumeSlider.addEventListener('input', function() {
        bgm.volume = this.value;
    });

    bgm.volume = 0.7;

    // 雪花飘落效果
    function createSnowflake() {
        const snowflake = document.createElement('div');
        const size = Math.random() * 3 + 1;
        const snowflakeClass = size < 2 ? 'small' : size < 2.5 ? 'medium' : 'large';
        const symbols = ['❄️', '❅', '❆'];
        const symbol = symbols[Math.floor(Math.random() * symbols.length)];

        snowflake.className = `snowflake ${snowflakeClass}`;
        snowflake.innerHTML = symbol;
        snowflake.style.left = `${Math.random() * 100}vw`;
        snowflake.style.animationDelay = `${Math.random() * 10}s`;
        snowflake.style.opacity = Math.random() * 0.5 + 0.3;

        document.body.appendChild(snowflake);

        // 移除雪花元素以优化性能
        setTimeout(() => {
            snowflake.remove();
        }, 25000);
    }

    // 初始创建雪花
    for (let i = 0; i < 30; i++) {
        setTimeout(createSnowflake, i * 500);
    }

    // 持续创建新雪花
    setInterval(createSnowflake, 2000);

});