document.addEventListener('DOMContentLoaded', function() {
    // 初始化标签切换
    initTabSwitching();
    fetchCoreData();
    
    // 添加防抖的resize处理
    let resizeTimer;
    window.addEventListener('resize', function() {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(function() {
            resizeAllCharts();
        }, 300);
    });

    initAirlineSelectAndGantt();

    var flightSelect = document.getElementById('flight-select');
    if (flightSelect) {
        flightSelect.addEventListener('change', function() {
            renderSelectedFlightsGantt();
        });
    }

    var btnAll = document.getElementById('flight-select-all');
    if (btnAll && flightSelect) {
        btnAll.addEventListener('click', function() {
            for (let i = 0; i < flightSelect.options.length; i++) {
                flightSelect.options[i].selected = true;
            }
            renderSelectedFlightsGantt();
        });
    }
});

// 存储所有图表实例
const coreCharts = {};
const marketCharts = {};
const timeCharts = {};
const geoCharts = {};

// 调整所有图表大小
function resizeAllCharts() {
    for (const key in coreCharts) {
        coreCharts[key] && coreCharts[key].resize();
    }
    for (const key in marketCharts) {
        marketCharts[key] && marketCharts[key].resize();
    }
    for (const key in timeCharts) {
        timeCharts[key] && timeCharts[key].resize();
    }
    for (const key in geoCharts) {
        geoCharts[key] && geoCharts[key].resize();
    }
}

// 初始化标签切换功能
function initTabSwitching() {
    const tabLinks = document.querySelectorAll('.tab-link');
    
    tabLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            tabLinks.forEach(item => item.classList.remove('active'));
            this.classList.add('active');
            const targetId = this.getAttribute('data-tab');
            document.querySelectorAll('.content-section').forEach(section => {
                section.classList.remove('active');
            });
            document.getElementById(targetId).classList.add('active');
            
            // 延迟一点时间确保DOM渲染完成后再获取数据
            setTimeout(() => {
                if (targetId === 'core-content') {
                    fetchCoreData();
                } else if (targetId === 'market-content') {
                    fetchMarketData();
                } else if (targetId === 'time-content') {
                    fetchTimeData();
                } else if (targetId === 'geo-content') {
                    fetchGeoData();
                }
            }, 50);
            
            // 再延迟一点调整所有图表尺寸
            setTimeout(() => {
                resizeAllCharts();
            }, 200);
        });
    });
}

// 获取业务指标数据
function fetchCoreData() {
    fetch('http://localhost:8080/core')
        .then(response => {
            if (!response.ok) {
                throw new Error('网络响应不正常');
            }
            return response.json();
        })
        .then(data => {
            renderCoreCharts(data);
        })
        .catch(error => {
            console.error('获取业务指标数据出错:', error);
            const mockData = getMockCoreData();
            renderCoreCharts(mockData);
        });
}

// 获取市场指标数据
function fetchMarketData() {
    fetch('http://localhost:8080/market')
        .then(response => {
            if (!response.ok) {
                throw new Error('网络响应不正常');
            }
            return response.json();
        })
        .then(data => {
            renderMarketCharts(data);
        })
        .catch(error => {
            console.error('获取市场指标数据出错:', error);
            const mockData = getMockMarketData();
            renderMarketCharts(mockData);
        });
}

// 获取时间指标数据
function fetchTimeData() {
    fetch('http://localhost:8080/time')
        .then(response => {
            if (!response.ok) {
                throw new Error('网络响应不正常');
            }
            return response.json();
        })
        .then(data => {
            console.log('时间指标数据:', data);
            // 延迟渲染确保DOM完全准备好
            setTimeout(() => {
                renderTimeSlotPieChart(data.flightTimeSlotStatsVOList);
                renderFlightScheduleTable(data.flightScheduleVOList);
                
                // 延迟后再次调整图表大小
                setTimeout(() => {
                    Object.values(timeCharts).forEach(chart => {
                        if (chart && typeof chart.resize === 'function') {
                            chart.resize();
                        }
                    });
                }, 500);
            }, 100);
        })
        .catch(error => {
            console.error('获取时间指标数据出错:', error);
            // 使用模拟数据进行展示
            const mockData = getMockTimeData();
            setTimeout(() => {
                renderTimeSlotPieChart(mockData.flightTimeSlotStatsVOList);
                renderFlightScheduleTable(mockData.flightScheduleVOList);
                
                // 延迟后再次调整图表大小
                setTimeout(() => {
                    Object.values(timeCharts).forEach(chart => {
                        if (chart && typeof chart.resize === 'function') {
                            chart.resize();
                        }
                    });
                }, 500);
            }, 100);
        });
}

// 渲染航班时间段分布饼图
function renderTimeSlotPieChart(data) {
    const chartDom = document.getElementById('time-slot-chart');
    if (!ensureChartContainerSize(chartDom)) return;
    
    const chart = echarts.init(chartDom);
    timeCharts.timeSlot = chart;

    // 聚合相同时间段的数据
    const timeSlotData = {};
    data.forEach(item => {
        if (!timeSlotData[item.timeSlot]) {
            timeSlotData[item.timeSlot] = 0;
        }
        timeSlotData[item.timeSlot] += item.flightCount;
    });

    // 准备饼图数据
    const pieData = Object.entries(timeSlotData).map(([name, value]) => ({
        name,
        value
    }));

    const option = {
        tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b}: {c} ({d}%)'
        },
        legend: {
            orient: 'vertical',
            left: 10,
            data: Object.keys(timeSlotData)
        },
        series: [
            {
                name: '航班数量',
                type: 'pie',
                radius: ['40%', '70%'],
                avoidLabelOverlap: false,
                itemStyle: {
                    borderRadius: 10,
                    borderColor: '#fff',
                    borderWidth: 2
                },
                label: {
                    show: false,
                    position: 'center'
                },
                emphasis: {
                    label: {
                        show: true,
                        fontSize: 16,
                        fontWeight: 'bold'
                    }
                },
                labelLine: {
                    show: false
                },
                data: pieData
            }
        ]
    };

    chart.setOption(option);
    
    // 强制resize确保正确显示
    setTimeout(() => {
        chart.resize();
    }, 100);
}

// 渲染航线竞争强度柱状图
function renderRouteCompetitionBarChart(data) {
    const chartDom = document.getElementById('route-competition-chart');
    if (!ensureChartContainerSize(chartDom)) return;
    
    console.log('航线竞争强度数据:', data);
    
    // 如果数据为空，显示提示信息
    if (!data || data.length === 0) {
        chartDom.innerHTML = '<div style="text-align:center;line-height:300px;color:#666;">暂无航线竞争强度数据</div>';
        return;
    }
    
    const chart = echarts.init(chartDom);
    marketCharts.competition = chart;

    // 提取前10条航线数据
    const topData = [...data].sort((a, b) => b.airlineCount - a.airlineCount).slice(0, 10);
    const routes = topData.map(item => item.route);
    const airlineCounts = topData.map(item => item.airlineCount);
    const flightDensity = topData.map(item => item.flightDensityDaily);

    const option = {
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'shadow'
            }
        },
        legend: {
            data: ['航空公司数量', '航班密度(每日)']
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis: {
            type: 'value',
            boundaryGap: [0, 0.01]
        },
        yAxis: {
            type: 'category',
            data: routes
        },
        series: [
            {
                name: '航空公司数量',
                type: 'bar',
                data: airlineCounts,
                itemStyle: {
                    color: '#50a3ba'
                }
            },
            {
                name: '航班密度(每日)',
                type: 'bar',
                data: flightDensity,
                itemStyle: {
                    color: '#d94e5d'
                }
            }
        ]
    };

    chart.setOption(option);
    
    // 强制resize确保正确显示
    setTimeout(() => {
        chart.resize();
    }, 100);
}

function renderAirportKnowledgeGraph(data) {
    const chartDom = document.getElementById('airport-knowledge-graph');
    if (!ensureChartContainerSize(chartDom)) return;
    
    console.log('机场知识图谱数据:', data);
    
    // 如果数据为空，显示提示信息
    if (!data || data.length === 0) {
        chartDom.innerHTML = '<div style="text-align:center;line-height:300px;color:#666;">暂无机场知识图谱数据</div>';
        return;
    }
    
    const chart = echarts.init(chartDom);
    marketCharts.knowledgeGraph = chart;

    const nodes = data.map(item => ({
        name: item.airport,
        value: item.pagerank,
        symbolSize: Math.min(50, Math.max(10, item.pagerank / 0.5))
    }));

    const links = [];
    for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < Math.min(i + 3, nodes.length); j++) {
            links.push({
                source: nodes[i].name,
                target: nodes[j].name,
                value: Math.random() * 3 + 1
            });
        }
    }

    const option = {
        title: {
            text: '机场重要性知识图谱',
            left: 'center'
        },
        tooltip: {
            formatter: '{b}: {c}'
        },
        legend: [{
            data: ['机场节点'],
            left: 'left'
        }],
        series: [{
            name: '机场节点',
            type: 'graph',
            layout: 'force',
            force: {
                repulsion: 200,
                edgeLength: 100
            },
            roam: true,
            label: {
                show: true
            },
            edgeSymbol: ['none', 'arrow'],
            edgeSymbolSize: [0, 10],
            edgeLabel: {
                fontSize: 10
            },
            data: nodes,
            links: links,
            lineStyle: {
                opacity: 0.9,
                width: 1,
                curveness: 0
            }
        }]
    };

    chart.setOption(option);
    
    // 强制resize确保正确显示
    setTimeout(() => {
        chart.resize();
    }, 100);
    
    // 再次延迟resize，确保图表完全渲染
    setTimeout(() => {
        chart.resize();
    }, 500);
}

// 生成时间指标模拟数据
function getMockTimeData() {
    return {
        "airportPagerankVOList": [
            {"airport": "首都机场", "pagerank": 6.6263577145856685},
            {"airport": "白云机场", "pagerank": 4.921869904311425},
            {"airport": "双流机场", "pagerank": 4.650052164994991},
            {"airport": "长水机场", "pagerank": 4.514393872340536},
            {"airport": "宝安机场", "pagerank": 4.490016265114064},
            {"airport": "江北机场", "pagerank": 4.465776759873335},
            {"airport": "咸阳机场", "pagerank": 3.817889621620452},
            {"airport": "浦东机场", "pagerank": 3.6499772736089393},
            {"airport": "地窝堡机场", "pagerank": 2.812630439318486},
            {"airport": "萧山机场", "pagerank": 2.788741854648085}
        ],
        "flightTimeSlotStatsVOList": [
            {"timeSlot": "00:00 - 01:59", "airline": "九元航空", "flightCount": 1},
            {"timeSlot": "00:00 - 01:59", "airline": "祥鹏航空", "flightCount": 1},
            {"timeSlot": "00:00 - 01:59", "airline": "东方航空", "flightCount": 1},
            {"timeSlot": "02:00 - 03:59", "airline": "南方航空", "flightCount": 2},
            {"timeSlot": "02:00 - 03:59", "airline": "中国国航", "flightCount": 1},
            {"timeSlot": "04:00 - 05:59", "airline": "海南航空", "flightCount": 3},
            {"timeSlot": "06:00 - 07:59", "airline": "东方航空", "flightCount": 15},
            {"timeSlot": "06:00 - 07:59", "airline": "南方航空", "flightCount": 12},
            {"timeSlot": "06:00 - 07:59", "airline": "中国国航", "flightCount": 10},
            {"timeSlot": "08:00 - 09:59", "airline": "东方航空", "flightCount": 28},
            {"timeSlot": "08:00 - 09:59", "airline": "南方航空", "flightCount": 25},
            {"timeSlot": "08:00 - 09:59", "airline": "中国国航", "flightCount": 22},
            {"timeSlot": "08:00 - 09:59", "airline": "海南航空", "flightCount": 18},
            {"timeSlot": "10:00 - 11:59", "airline": "东方航空", "flightCount": 32},
            {"timeSlot": "10:00 - 11:59", "airline": "南方航空", "flightCount": 29},
            {"timeSlot": "10:00 - 11:59", "airline": "中国国航", "flightCount": 26},
            {"timeSlot": "10:00 - 11:59", "airline": "海南航空", "flightCount": 20},
            {"timeSlot": "12:00 - 13:59", "airline": "东方航空", "flightCount": 25},
            {"timeSlot": "12:00 - 13:59", "airline": "南方航空", "flightCount": 22},
            {"timeSlot": "12:00 - 13:59", "airline": "中国国航", "flightCount": 20},
            {"timeSlot": "14:00 - 15:59", "airline": "东方航空", "flightCount": 30},
            {"timeSlot": "14:00 - 15:59", "airline": "南方航空", "flightCount": 28},
            {"timeSlot": "14:00 - 15:59", "airline": "中国国航", "flightCount": 25},
            {"timeSlot": "14:00 - 15:59", "airline": "海南航空", "flightCount": 22},
            {"timeSlot": "16:00 - 17:59", "airline": "东方航空", "flightCount": 35},
            {"timeSlot": "16:00 - 17:59", "airline": "南方航空", "flightCount": 32},
            {"timeSlot": "16:00 - 17:59", "airline": "中国国航", "flightCount": 28},
            {"timeSlot": "16:00 - 17:59", "airline": "海南航空", "flightCount": 25},
            {"timeSlot": "18:00 - 19:59", "airline": "东方航空", "flightCount": 38},
            {"timeSlot": "18:00 - 19:59", "airline": "南方航空", "flightCount": 35},
            {"timeSlot": "18:00 - 19:59", "airline": "中国国航", "flightCount": 30},
            {"timeSlot": "18:00 - 19:59", "airline": "海南航空", "flightCount": 28},
            {"timeSlot": "20:00 - 21:59", "airline": "东方航空", "flightCount": 25},
            {"timeSlot": "20:00 - 21:59", "airline": "南方航空", "flightCount": 22},
            {"timeSlot": "20:00 - 21:59", "airline": "中国国航", "flightCount": 20},
            {"timeSlot": "22:00 - 23:59", "airline": "东方航空", "flightCount": 10},
            {"timeSlot": "22:00 - 23:59", "airline": "南方航空", "flightCount": 8},
            {"timeSlot": "22:00 - 23:59", "airline": "中国国航", "flightCount": 5}
        ],
        "flightRouteDensityStatsVOList": [ 
            {"route": "重庆 -> 上海", "depCity": "重庆", "arrCity": "上海", "flightDensityDaily": 6.43, "airlineCount": 15, "totalFlights": 45, "coveredDays": 7},
            {"route": "上海 -> 西安", "depCity": "上海", "arrCity": "西安", "flightDensityDaily": 6.43, "airlineCount": 14, "totalFlights": 45, "coveredDays": 7},
            {"route": "上海 -> 成都", "depCity": "上海", "arrCity": "成都", "flightDensityDaily": 6.43, "airlineCount": 13, "totalFlights": 45, "coveredDays": 7},
            {"route": "昆明 -> 成都", "depCity": "昆明", "arrCity": "成都", "flightDensityDaily": 6.43, "airlineCount": 11, "totalFlights": 45, "coveredDays": 7},
            {"route": "北京 -> 重庆", "depCity": "北京", "arrCity": "重庆", "flightDensityDaily": 6.43, "airlineCount": 11, "totalFlights": 45, "coveredDays": 7},
            {"route": "大连 -> 上海", "depCity": "大连", "arrCity": "上海", "flightDensityDaily": 6.43, "airlineCount": 11, "totalFlights": 45, "coveredDays": 7},
            {"route": "成都 -> 昆明", "depCity": "成都", "arrCity": "昆明", "flightDensityDaily": 6.43, "airlineCount": 11, "totalFlights": 45, "coveredDays": 7},
            {"route": "北京 -> 上海", "depCity": "北京", "arrCity": "上海", "flightDensityDaily": 9.29, "airlineCount": 10, "totalFlights": 65, "coveredDays": 7},
            {"route": "广州 -> 上海", "depCity": "广州", "arrCity": "上海", "flightDensityDaily": 8.57, "airlineCount": 10, "totalFlights": 60, "coveredDays": 7},
            {"route": "深圳 -> 上海", "depCity": "深圳", "arrCity": "上海", "flightDensityDaily": 7.86, "airlineCount": 9, "totalFlights": 55, "coveredDays": 7}
        ]
    };
}

// 获取地理指标数据
function fetchGeoData() {
    fetch('http://localhost:8080/geo')
        .then(response => {
            if (!response.ok) {
                throw new Error('网络响应不正常');
            }
            return response.json();
        })
        .then(data => {
            console.log('地理指标数据:', data);
            renderGeoCharts(data);
        })
        .catch(error => {
            console.error('获取地理指标数据出错:', error);
            const mockData = getMockGeoData();
            renderGeoCharts(mockData);
        });
}

// 渲染地理指标图表
function renderGeoCharts(data) {
    // 延迟一点时间确保DOM完全渲染
    setTimeout(() => {
        // 提取数据
        const departureStats = data.departureStats || [];
        const landingStats = data.landingStats || [];
        const routeStats = data.routeStats || [];
        
        // 渲染各个图表
        renderGeoCityMapChart(data);
        renderGeoDepartureChart(departureStats);
        renderGeoLandingChart(landingStats);
        renderGeoRouteChart(routeStats);
        
        // 获取市场指标数据来渲染城市航班分布地图
        fetch('http://localhost:8080/market')
            .then(response => {
                if (!response.ok) {
                    throw new Error('网络响应不正常');
                }
                return response.json();
            })
            .then(marketData => {
                const posData = marketData.posCountVO || [];
                renderCityMapChart(posData);
            })
            .catch(error => {
                console.error('获取市场指标数据出错:', error);
                // 如果获取失败，可以调用模拟数据或显示错误
                console.log('城市航班分布地图数据获取失败');
            });
        
        // 延迟后再次调整图表大小
        setTimeout(() => {
            Object.values(geoCharts).forEach(chart => {
                if (chart && typeof chart.resize === 'function') {
                    chart.resize();
                }
            });
        }, 500);
    }, 100);
}

// 渲染城市航班分布地图
function renderGeoCityMapChart(data) {
    const chartDom = document.getElementById('geo-city-map-chart');
    const chart = echarts.init(chartDom);
    geoCharts.cityMap = chart;
    
    // 加载阿里云在线地图数据
    chart.showLoading();
    
    fetch('https://geo.datav.aliyun.com/areas_v3/bound/100000_full.json')
        .then(response => response.json())
        .then(geoJson => {
            // 注册地图
            echarts.registerMap('china', geoJson);

            // 使用对象形式存储数据，确保名称和数值正确对应
            var regionData = {
                '南海诸岛': 180,
                '北京市': 524,
                '天津市': 113,
                '上海市': 140,
                '重庆市': 752,
                '河北省': 13,
                '河南省': 83,
                '云南省': 11,
                '辽宁省': 19,
                '黑龙江省': 415,
                '湖南省': 269,
                '安徽省': 260,
                '山东省': 39,
                '新疆维吾尔自治区': 94,
                '江苏省': 31,
                '浙江省': 104,
                '江西省': 36,
                '湖北省': 1052,
                '广西壮族自治区': 33,
                '甘肃省': 347,
                '山西省': 129,
                '内蒙古自治区': 157,
                '陕西省': 22,
                '吉林省': 46,
                '福建省': 18,
                '贵州省': 355,
                '广东省': 698,
                '青海省': 341,
                '西藏自治区': 210,
                '四川省': 484,
                '宁夏回族自治区': 404,
                '海南省': 224,
                '台湾省': 43,
                '香港特别行政区': 25,
                '澳门特别行政区': 225
            };

            // 转换为ECharts需要的数据格式
            var outdata = Object.keys(regionData).map(name => ({
                name: name,
                value: regionData[name]
            }));

            airline = [
                {
                    name: '国航',
                    value: 100
                }
            ]

            var scatter = [[110.81, 33.40, 99], [116.55, 40.01, 77], [113.11, 28.40, 34], [106.44, 29.50, 112], [112.85, 38.95, 6], [82.78, 43.27, 50]]
            var lineToLf = [
                {
                    kv: airline,
                    coords: [[110.81, 33.40], [116.55, 40.01]],
                    lineStyle: { color: '#c1bb1f' }
                },
                {
                    name: '南方航空',
                    value: 34,
                    coords: [[113.11, 28.40], [116.55, 40.01]],
                    lineStyle: { color: '#f9b207' }
                },
                {
                    name: '厦门航空',
                    value: 90,
                    coords: [[106.44, 29.50], [116.55, 40.01]],
                    lineStyle: { color: '#3eef1d' }
                },
                {
                    name: '四川航空',
                    value: 100,
                    coords: [[112.85, 38.95], [116.55, 40.01]],
                    lineStyle: { color: '#3eef1d' }
                },
                {
                    name: '国航',
                    value: 50,
                    coords: [[82.78, 43.27], [116.55, 40.01]],
                    lineStyle: { color: '#3eef1d' }
                }
            ]
            var planePath = 'path://M1705.06,1318.313v-89.254l-319.9-221.799l0.073-208.063c0.521-84.662-26.629-121.796-63.961-121.491c-37.332-0.305-64.482,36.829-63.961,121.491l0.073,208.063l-319.9,221.799v89.254l330.343-157.288l12.238,241.308l-134.449,92.931l0.531,42.034l175.125-42.917l175.125,42.917l0.531-42.034l-134.449-92.931l12.238-241.308L1705.06,1318.313z'

            var option = {
                tooltip: {
                    show: true,
                    formatter: function (params) {
                        if (params.value !== undefined) {
                            return '&nbsp;&nbsp;' + params.name + '&nbsp;&nbsp;&nbsp;' + params.value + '架次&nbsp;&nbsp;'
                        } else {
                            return '&nbsp;&nbsp;' + airline[0].name + airline[0].value + '&nbsp;&nbsp;&nbsp;暂无数据&nbsp;&nbsp;'
                        }
                    }
                },

                visualMap: {
                    type: 'continuous',
                    showLabel: false,
                    left: "20%",
                    bottom: "15%",
                    min: 0,
                    max: 500,
                    seriesIndex: [0],
                    // 增加更丰富的颜色层次
                    inRange: {
                        color: [
                            '#d0f9ff',  // 最浅蓝
                            '#c0f2fe',  // 浅蓝
                            '#bae6fd',  // 淡蓝
                            '#7dd3fc',  // 中蓝
                            '#38bdf8',  // 标准蓝
                            '#0ea5e9',  // 深蓝
                            '#0284c7',  // 更深蓝
                            '#0369a1',  // 深蓝色
                            '#075985'   // 最深蓝
                        ]
                    },
                    // 确保超出范围显示红色
                    outOfRange: {
                        color: 'pink'  
                    },
                    // 增加分割段数以匹配颜色数量
                    splitNumber: 8,
                    // 添加这些属性确保超出范围的处理
                    calculable: true,
                    realtime: true,
                    // 可选：添加边界线
                    itemWidth: 20,
                    itemHeight: 100,
                    textStyle: {
                        color: '#333'
                    },

                },

                geo: {
                    map: 'china',
                    show: true,
                    roam: false,
                    zoom: 1.35,
                    center: [104, 35],
                    label: {
                        emphasis: {
                            show: false
                        }
                    }
                },
                series: [
                    {
                        type: 'map',
                        map: 'china',
                        aspectScale: 0.75,
                        zoom: 1.35,
                        center: [104, 35],
                        label: {
                            normal: {
                                show: false
                            },
                            emphasis: {
                                show: true
                            }
                        },
                        itemStyle: {
                            normal: {
                                areaColor: '#B2CAE0',
                                borderColor: '#fff',
                                borderWidth: 1
                            },
                            emphasis: {
                                areaColor: '#FFAE00'
                            }
                        },
                        emphasis: {
                            itemStyle: {
                                areaColor: null,
                                borderWidth: 3,
                                shadowColor: 'rgba(0,0,0,.2)',
                                shadowOffsetX: 5,
                                shadowOffsetY: 5
                            }
                        },
                        animation: false,
                        data: outdata
                    },
                    {
                        name: '散点',
                        type: 'effectScatter',
                        coordinateSystem: 'geo',
                        showEffectOn: 'render',
                        top: 10,
                        bottom: 10,
                        zlevel: 2,

                        rippleEffect: {
                            number: 5,
                            period: 4,
                            scale: 3.5,
                            brushType: 'stroke'
                        },
                        data: scatter.map((it) => {
                            return {
                                name: 'cccccccc',
                                value: it,
                                itemStyle: {
                                    normal: {
                                        color: '#f9b207',
                                        areaColor: '#f9b207'
                                    }
                                }
                            }
                        }),
                        symbolSize: function (val) {
                            return val[2] / 10
                        }
                    },
                    {
                        type: 'lines',
                        zlevel: 2,
                        symbol: ['none', 'arrow'],
                        effect: {
                            show: true,
                            period: 6,
                            trailLength: 0,
                            symbol: planePath,
                            symbolSize: 15
                        },
                        lineStyle: {
                            normal: {
                                color: '#a6c84c',
                                width: 1,
                                opacity: 0.6,
                                curveness: 0.2
                            }
                        },
                        data: lineToLf,
                        z: 3
                    }
                ]
            }

            chart.hideLoading();
            chart.setOption(option);
        })
        .catch(error => {
            console.error('无法加载地图数据:', error);
            chart.hideLoading();
            // 如果在线加载失败，显示错误信息
            chartDom.innerHTML = '<div style="text-align:center;line-height:600px;color:red;">地图数据加载失败，请检查网络连接</div>';
        });
}

// 渲染出发机场航班量图表
function renderGeoDepartureChart(data) {
    const chartDom = document.getElementById('geo-departure-chart');
    const chart = echarts.init(chartDom);
    geoCharts.departure = chart;
    
    // 排序数据
    data.sort((a, b) => b.flightCount - a.flightCount);
    // 只取前5个机场
    const topData = data.slice(0, 5);
    
    const option = {
        tooltip: {
            trigger: 'item',
            formatter: '{b}: {c}架次'
        },
        series: [{
            type: 'pie',
            radius: '70%',
            center: ['50%', '50%'],
            data: topData.map(item => ({
                name: item.airportName,
                value: item.flightCount
            })),
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            },
            label: {
                formatter: '{b}: {c}架次'
            },
            itemStyle: {
                color: function(params) {
                    const colorList = ['#5470c6', '#91cc75', '#fac858', '#ee6666', '#73c0de'];
                    return colorList[params.dataIndex % colorList.length];
                }
            }
        }]
    };
    
    chart.setOption(option);
}

// 渲染到达机场航班量图表
function renderGeoLandingChart(data) {
    const chartDom = document.getElementById('geo-landing-chart');
    const chart = echarts.init(chartDom);
    geoCharts.landing = chart;
    
    // 排序数据
    data.sort((a, b) => b.flightCount - a.flightCount);
    // 只取前5个机场
    const topData = data.slice(0, 5);
    
    const option = {
        tooltip: {
            trigger: 'item',
            formatter: '{b}: {c}架次'
        },
        series: [{
            type: 'pie',
            radius: '70%',
            center: ['50%', '50%'],
            data: topData.map(item => ({
                name: item.airportName,
                value: item.flightCount
            })),
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            },
            label: {
                formatter: '{b}: {c}架次'
            },
            itemStyle: {
                color: function(params) {
                    const colorList = ['#5470c6', '#91cc75', '#fac858', '#ee6666', '#73c0de'];
                    return colorList[params.dataIndex % colorList.length];
                }
            }
        }]
    };
    
    chart.setOption(option);
}

// 渲染热门航线图表
function renderGeoRouteChart(data) {
    const chartDom = document.getElementById('geo-route-chart');
    const chart = echarts.init(chartDom);
    geoCharts.route = chart;
    
    // 排序数据
    data.sort((a, b) => b.flightCount - a.flightCount);
    
    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: '{b}: {c}架次'
        },
        xAxis: {
            type: 'category',
            data: data.map(item => `${item.depCity} → ${item.arrCity}`),
            axisLabel: {
                interval: 0,
                rotate: 30
            }
        },
        yAxis: {
            type: 'value',
            name: '航班数量'
        },
        series: [{
            data: data.map(item => item.flightCount),
            type: 'bar',
            barWidth: '40%',
            itemStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                    { offset: 0, color: '#ff9a00' },
                    { offset: 1, color: '#ff6a00' }
                ])
            },
            label: {
                show: true,
                position: 'top',
                formatter: '{c}架次'
            }
        }]
    };
    
    chart.setOption(option);
}

// 渲染业务指标图表
function renderCoreCharts(data) {
    // 延迟一点时间确保DOM完全渲染
    setTimeout(() => {
        // 提取数据
        const delayData = data.delayVO;
        const prateData = data.prateVO;
        
        // 按类型分组延迟数据
        const airlineDelayData = delayData.filter(item => item.type === 1);
        const airportDelayData = delayData.filter(item => item.type === 2);
        const routeDelayData = delayData.filter(item => item.type === 3);
        
        // 渲染各个图表
        renderAirlineDelayTop5Chart(airlineDelayData);
        renderAirlineDelayBottom5Chart(airlineDelayData);
        renderAirportDelayTop5Chart(airportDelayData);
        renderAirportDelayBottom5Chart(airportDelayData);
        renderRouteDelayTop5Chart(routeDelayData);
        renderRouteDelayBottom5Chart(routeDelayData);
        renderPunctualityTop5Chart(prateData);
        renderPunctualityBottom5Chart(prateData);
        
        // 延迟后再次调整图表大小
        setTimeout(() => {
            Object.values(coreCharts).forEach(chart => {
                if (chart && typeof chart.resize === 'function') {
                    chart.resize();
                }
            });
        }, 500);
    }, 100);
}

// 延迟值转颜色（Top5深红到浅红，Bottom5天蓝到绿色）
function getDelayColor(value, min, max, mode = 'top') {
    let t = (value - min) / (max - min);
    t = Math.max(0, Math.min(1, t));
    if (mode === 'top') {
        // 深红到浅红
        const start = {r: 183, g: 28, b: 28};   // #b71c1c
        const end = {r: 255, g: 138, b: 128};   // #ff8a80
        const r = Math.round(start.r + (end.r - start.r) * (1 - t));
        const g = Math.round(start.g + (end.g - start.g) * (1 - t));
        const b = Math.round(start.b + (end.b - start.b) * (1 - t));
        return `rgb(${r},${g},${b})`;
    } else {
        // 蓝色到绿色过渡（大->小）
        const start = {r: 30, g: 144, b: 255};  // #1e90ff (道奇蓝)
        const end = {r: 50, g: 205, b: 50};     // #32cd32 (酸橙绿)
        // 反转t值，使得大的数值显示为蓝色
        const reversedT = 1 - t;
        const r = Math.round(start.r + (end.r - start.r) * reversedT);
        const g = Math.round(start.g + (end.g - start.g) * reversedT);
        const b = Math.round(start.b + (end.b - start.b) * reversedT);
        return `rgb(${r},${g},${b})`;
    }
}

// 确保图表容器有正确的尺寸
function ensureChartContainerSize(chartDom) {
    if (!chartDom) return false;
    
    // 确保容器可见
    if (chartDom.offsetWidth === 0 || chartDom.offsetHeight === 0) {
        console.warn('图表容器尺寸为0，强制设置最小尺寸');
        chartDom.style.width = '100%';
        chartDom.style.height = '300px';
        chartDom.style.minWidth = '300px';
        chartDom.style.minHeight = '300px';
    }
    
    return true;
}

// 航司平均延迟时间Top5图表
function renderAirlineDelayTop5Chart(data) {
    const chartDom = document.getElementById('airline-delay-top5-chart');
    if (!ensureChartContainerSize(chartDom)) return;
    
    const chart = echarts.init(chartDom);
    coreCharts.airlineDelayTop5 = chart;
    
    // 取前5并降序
    const top5 = [...data].sort((a, b) => parseFloat(b.avgDelay) - parseFloat(a.avgDelay)).slice(0, 5);
    const delays = top5.map(item => parseFloat(item.avgDelay));
    const max = Math.max(...delays);
    const min = Math.min(...delays);
    
    const option = {
        tooltip: { trigger: 'axis', formatter: '{b}: {c}分钟' },
        xAxis: { type: 'category', data: top5.map(item => item.name), axisLabel: { interval: 0, rotate: 30 } },
        yAxis: { type: 'value', name: '平均延误(分钟)' },
        series: [{
            data: delays,
            type: 'bar',
            itemStyle: {
                color: function(params) {
                    return getDelayColor(params.data, min, max, 'top');
                }
            },
            label: { show: true, position: 'top', formatter: '{c}分钟' }
        }]
    };
    chart.setOption(option);
    
    // 强制resize确保正确显示
    setTimeout(() => {
        chart.resize();
    }, 100);
}

// 航司平均延迟时间Bottom5图表
function renderAirlineDelayBottom5Chart(data) {
    const chartDom = document.getElementById('airline-delay-bottom5-chart');
    const chart = echarts.init(chartDom);
    coreCharts.airlineDelayBottom5 = chart;
    
    // 取后5并升序后再降序排列
    const bottom5 = [...data]
        .sort((a, b) => parseFloat(a.avgDelay) - parseFloat(b.avgDelay))
        .slice(0, 5)
        .sort((a, b) => parseFloat(b.avgDelay) - parseFloat(a.avgDelay));
    const delays = bottom5.map(item => parseFloat(item.avgDelay));
    const max = Math.max(...delays);
    const min = Math.min(...delays);
    
    const option = {
        tooltip: { trigger: 'axis', formatter: '{b}: {c}分钟' },
        xAxis: { type: 'category', data: bottom5.map(item => item.name), axisLabel: { interval: 0, rotate: 30 } },
        yAxis: { type: 'value', name: '平均延误(分钟)' },
        series: [{
            data: delays,
            type: 'bar',
            itemStyle: {
                color: function(params) {
                    return getDelayColor(params.data, min, max, 'bottom');
                }
            },
            label: { show: true, position: 'top', formatter: '{c}分钟' }
        }]
    };
    chart.setOption(option);
}

// 机场平均延迟时间Top5图表
function renderAirportDelayTop5Chart(data) {
    const chartDom = document.getElementById('airport-delay-top5-chart');
    const chart = echarts.init(chartDom);
    coreCharts.airportDelayTop5 = chart;
    
    // 取前5并降序
    const top5 = [...data].sort((a, b) => parseFloat(b.avgDelay) - parseFloat(a.avgDelay)).slice(0, 5);
    const delays = top5.map(item => parseFloat(item.avgDelay));
    const max = Math.max(...delays);
    const min = Math.min(...delays);
    
    const option = {
        tooltip: { trigger: 'axis', formatter: '{b}: {c}分钟' },
        xAxis: { type: 'category', data: top5.map(item => item.name), axisLabel: { interval: 0, rotate: 30 } },
        yAxis: { type: 'value', name: '平均延误(分钟)' },
        series: [{
            data: delays,
            type: 'bar',
            itemStyle: {
                color: function(params) {
                    return getDelayColor(params.data, min, max, 'top');
                }
            },
            label: { show: true, position: 'top', formatter: '{c}分钟' }
        }]
    };
    
    chart.setOption(option);
}

// 机场平均延迟时间Bottom5图表
function renderAirportDelayBottom5Chart(data) {
    const chartDom = document.getElementById('airport-delay-bottom5-chart');
    const chart = echarts.init(chartDom);
    coreCharts.airportDelayBottom5 = chart;
    
    // 取后5并升序后再降序排列
    const bottom5 = [...data]
        .sort((a, b) => parseFloat(a.avgDelay) - parseFloat(b.avgDelay))
        .slice(0, 5)
        .sort((a, b) => parseFloat(b.avgDelay) - parseFloat(a.avgDelay));
    const delays = bottom5.map(item => parseFloat(item.avgDelay));
    const max = Math.max(...delays);
    const min = Math.min(...delays);
    
    const option = {
        tooltip: { trigger: 'axis', formatter: '{b}: {c}分钟' },
        xAxis: { type: 'category', data: bottom5.map(item => item.name), axisLabel: { interval: 0, rotate: 30 } },
        yAxis: { type: 'value', name: '平均延误(分钟)' },
        series: [{
            data: delays,
            type: 'bar',
            itemStyle: {
                color: function(params) {
                    return getDelayColor(params.data, min, max, 'bottom');
                }
            },
            label: { show: true, position: 'top', formatter: '{c}分钟' }
        }]
    };
    chart.setOption(option);
}

// 渲染航线延迟Top5图表
function renderRouteDelayTop5Chart(data) {
    const chartDom = document.getElementById('route-delay-top5-chart');
    const chart = echarts.init(chartDom);
    coreCharts.routeDelayTop5 = chart;
    
    // 取前5并降序
    const top5 = [...data].sort((a, b) => parseFloat(b.avgDelay) - parseFloat(a.avgDelay)).slice(0, 5);
    const delays = top5.map(item => parseFloat(item.avgDelay));
    const max = Math.max(...delays);
    const min = Math.min(...delays);
    
    const option = {
        tooltip: { trigger: 'axis', formatter: '{b}: {c}分钟' },
        xAxis: { type: 'category', data: top5.map(item => item.name), axisLabel: { interval: 0, rotate: 30 } },
        yAxis: { type: 'value', name: '平均延误(分钟)' },
        series: [{
            data: delays,
            type: 'bar',
            itemStyle: {
                color: function(params) {
                    return getDelayColor(params.data, min, max, 'top');
                }
            },
            label: { show: true, position: 'top', formatter: '{c}分钟' }
        }]
    };
    chart.setOption(option);
}

// 渲染航线延迟Bottom5图表
function renderRouteDelayBottom5Chart(data) {
    const chartDom = document.getElementById('route-delay-bottom5-chart');
    const chart = echarts.init(chartDom);
    coreCharts.routeDelayBottom5 = chart;
    
    // 取后5并升序后再降序排列
    const bottom5 = [...data]
        .sort((a, b) => parseFloat(a.avgDelay) - parseFloat(b.avgDelay))
        .slice(0, 5)
        .sort((a, b) => parseFloat(b.avgDelay) - parseFloat(a.avgDelay));
    const delays = bottom5.map(item => parseFloat(item.avgDelay));
    const max = Math.max(...delays);
    const min = Math.min(...delays);
    
    const option = {
        tooltip: { trigger: 'axis', formatter: '{b}: {c}分钟' },
        xAxis: { type: 'category', data: bottom5.map(item => item.name), axisLabel: { interval: 0, rotate: 30 } },
        yAxis: { type: 'value', name: '平均延误(分钟)' },
        series: [{
            data: delays,
            type: 'bar',
            itemStyle: {
                color: function(params) {
                    return getDelayColor(params.data, min, max, 'bottom');
                }
            },
            label: { show: true, position: 'top', formatter: '{c}分钟' }
        }]
    };
    chart.setOption(option);
}

// 渲染航班准点率Top5图表
function renderPunctualityTop5Chart(data) {
    const chartDom = document.getElementById('punctuality-top5-chart');
    const chart = echarts.init(chartDom);
    coreCharts.punctualityTop5 = chart;

    // 取前5并降序
    let top5 = [...data].sort((a, b) => parseFloat(b.punctuality) - parseFloat(a.punctuality)).slice(0, 5);

    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: '{b}: {c}%'
        },
        xAxis: {
            type: 'category',
            data: top5.map(item => item.name),
            axisLabel: {
                interval: 0,
                rotate: 30
            }
        },
        yAxis: {
            type: 'value',
            name: '准点率(%)',
            min: 0,
            max: 100
        },
        series: [{
            data: top5.map(item => parseFloat(item.punctuality)),
            type: 'bar',
            barWidth: '40%',
            itemStyle: {
                color: function(params) {
                    const colorList = ['#4ecdc4', '#52b788', '#76c893', '#99d98c', '#b5e48c'];
                    return colorList[params.dataIndex % colorList.length] || '#b5e48c';
                }
            },
            label: {
                show: true,
                position: 'top',
                formatter: '{c}%'
            }
        }]
    };
    chart.setOption(option);
}

// 渲染航班准点率Bottom5图表
function renderPunctualityBottom5Chart(data) {
    const chartDom = document.getElementById('punctuality-bottom5-chart');
    const chart = echarts.init(chartDom);
    coreCharts.punctualityBottom5 = chart;

    // 取后5并降序
    let bottom5 = [...data].sort((a, b) => parseFloat(a.punctuality) - parseFloat(b.punctuality)).slice(0, 5).sort((a, b) => parseFloat(b.punctuality) - parseFloat(a.punctuality));

    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: '{b}: {c}%'
        },
        xAxis: {
            type: 'category',
            data: bottom5.map(item => item.name),
            axisLabel: {
                interval: 0,
                rotate: 30
            }
        },
        yAxis: {
            type: 'value',
            name: '准点率(%)',
            min: 0,
            max: 100
        },
        series: [{
            data: bottom5.map(item => parseFloat(item.punctuality)),
            type: 'bar',
            barWidth: '40%',
            itemStyle: {
                color: function(params) {
                    const colorList = ['#ff6b6b', '#ffb385', '#ffd6a5', '#fdffb6', '#caffbf'];
                    return colorList[params.dataIndex % colorList.length] || '#caffbf';
                }
            },
            label: {
                show: true,
                position: 'top',
                formatter: '{c}%'
            }
        }]
    };
    chart.setOption(option);
}

// 渲染市场指标图表
function renderMarketCharts(data) {
    console.log('市场指标数据:', data);
    
    // 延迟一点时间确保DOM完全渲染
    setTimeout(() => {
        // 提取数据
        const airlineCountData = data.airlineCountVO || [];
        const cityCountData = data.cityCountVO || [];
        const airportCountData = data.airportCountVO || [];
        const coverageData = data.top5VO || [];
        const posData = data.posCountVO || [];
        const airlineMileageData = data.airlineMileageVO || [];
        const aircraftFlightData = data.aircraftFlightVO || [];
        
        console.log('机型航班数据提取:', aircraftFlightData);
        
        // 渲染各个图表
        renderAirlineCountChart(airlineCountData);
        renderCityCountChart(cityCountData);
        renderAirportCountChart(airportCountData);
        renderCoverageChart(coverageData);
        renderAirlineMileageChart(airlineMileageData);
        renderAircraftFlight3DChart(aircraftFlightData);
        
        // 获取时间指标数据来渲染机场知识图谱和航线竞争强度
        fetch('http://localhost:8080/time')
            .then(response => {
                if (!response.ok) {
                    throw new Error('网络响应不正常');
                }
                return response.json();
            })
            .then(timeData => {
                renderAirportKnowledgeGraph(timeData.airportPagerankVOList);
                renderRouteCompetitionBarChart(timeData.flightRouteDensityStatsVOList);
            })
            .catch(error => {
                console.error('获取时间指标数据出错:', error);
                // 使用模拟数据
                const mockData = getMockTimeData();
                renderAirportKnowledgeGraph(mockData.airportPagerankVOList);
                renderRouteCompetitionBarChart(mockData.flightRouteDensityStatsVOList);
            });
        
        // 延迟后再次调整图表大小
        setTimeout(() => {
            Object.values(marketCharts).forEach(chart => {
                if (chart && typeof chart.resize === 'function') {
                    chart.resize();
                }
            });
        }, 500);
    }, 100);
}

// 航司航班数量图表
function renderAirlineCountChart(data) {
    const chartDom = document.getElementById('airline-count-chart');
    const chart = echarts.init(chartDom);
    marketCharts.airlineCount = chart;
    
    // 排序
    data.sort((a, b) => b.count - a.count);
    
    const option = {
        tooltip: {
            trigger: 'item',
            formatter: '{b}: {c}架次'
        },
        series: [{
            type: 'pie',
            radius: '70%',
            center: ['50%', '50%'],
            data: data.map(item => ({
                name: item.airlineName,
                value: item.count
            })),
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            },
            label: {
                formatter: '{b}: {c}架次'
            }
        }]
    };
    
    chart.setOption(option);
}

// 城市航班数量图表
function renderCityCountChart(data) {
    const chartDom = document.getElementById('city-count-chart');
    const chart = echarts.init(chartDom);
    marketCharts.cityCount = chart;
    
    // 排序
    data.sort((a, b) => b.count - a.count);
    // 只取前6个城市
    const topData = data.slice(0, 6);
    
    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: '{b}: {c}架次'
        },
        xAxis: {
            type: 'category',
            data: topData.map(item => item.cityName),
            axisLabel: {
                interval: 0,
                rotate: 30
            }
        },
        yAxis: {
            type: 'value',
            name: '航班数量'
        },
        series: [{
            data: topData.map(item => item.count),
            type: 'bar',
            barWidth: '40%',
            itemStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                    { offset: 0, color: '#83a4d4' },
                    { offset: 1, color: '#b6fbff' }
                ])
            },
            label: {
                show: true,
                position: 'top',
                formatter: '{c}架次'
            }
        }]
    };
    
    chart.setOption(option);
}

// 机场航班数量图表
function renderAirportCountChart(data) {
    const chartDom = document.getElementById('airport-count-chart');
    const chart = echarts.init(chartDom);
    marketCharts.airportCount = chart;
    
    // 排序
    data.sort((a, b) => parseInt(b.count) - parseInt(a.count));
    // 只取前6个机场
    const topData = data.slice(0, 6);
    
    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: '{b}: {c}架次'
        },
        xAxis: {
            type: 'category',
            data: topData.map(item => item.airportName),
            axisLabel: {
                interval: 0,
                rotate: 30
            }
        },
        yAxis: {
            type: 'value',
            name: '航班数量'
        },
        series: [{
            data: topData.map(item => parseInt(item.count)),
            type: 'bar',
            barWidth: '40%',
            itemStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                    { offset: 0, color: '#5ee7df' },
                    { offset: 1, color: '#b490ca' }
                ])
            },
            label: {
                show: true,
                position: 'top',
                formatter: '{c}架次'
            }
        }]
    };
    
    chart.setOption(option);
}

// 航司覆盖率TOP5图表
function renderCoverageChart(data) {
    const chartDom = document.getElementById('coverage-chart');
    const chart = echarts.init(chartDom);
    marketCharts.coverage = chart;
    
    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: '{b}: {c}%'
        },
        xAxis: {
            type: 'value',
            name: '覆盖率(%)',
            max: 50
        },
        yAxis: {
            type: 'category',
            data: data.map(item => item.airline).reverse(),
            axisLabel: {
                interval: 0
            }
        },
        series: [{
            data: data.map(item => parseFloat(item.coverage_rate)).reverse(),
            type: 'bar',
            barWidth: '60%',
            itemStyle: {
                color: function(params) {
                    const colorList = ['#ff9a00', '#ff9a3c', '#ffa361', '#ffad86', '#ffb8a8'];
                    return colorList[params.dataIndex] || '#ffb8a8';
                }
            },
            label: {
                show: true,
                position: 'right',
                formatter: '{c}%'
            }
        }]
    };
    
    chart.setOption(option);
}

// 航司里程数图表
function renderAirlineMileageChart(data) {
    const chartDom = document.getElementById('airline-mileage-chart');
    if (!ensureChartContainerSize(chartDom)) return;
    
    const chart = echarts.init(chartDom);
    marketCharts.airlineMileage = chart;
    
    // 排序
    data.sort((a, b) => b.totalMileage - a.totalMileage);
    
    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: '{b}: {c}公里'
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis: {
            type: 'value',
            name: '总里程数(公里)',
            axisLabel: {
                formatter: function(value) {
                    if (value >= 1000000) {
                        return (value / 1000000).toFixed(1) + 'M';
                    } else if (value >= 1000) {
                        return (value / 1000).toFixed(1) + 'K';
                    }
                    return value;
                }
            }
        },
        yAxis: {
            type: 'category',
            data: data.map(item => item.airlineName).reverse(),
            axisLabel: {
                interval: 0
            }
        },
        series: [{
            data: data.map(item => parseInt(item.totalMileage)).reverse(),
            type: 'bar',
            barWidth: '60%',
            itemStyle: {
                color: function(params) {
                    const colorList = ['#ff9a00', '#ff9a3c', '#ffa361', '#ffad86', '#ffb8a8'];
                    return colorList[params.dataIndex] || '#ffb8a8';
                }
            },
            label: {
                show: true,
                position: 'right',
                formatter: function(params) {
                    const value = params.value;
                    if (value >= 1000000) {
                        return (value / 1000000).toFixed(1) + 'M公里';
                    } else if (value >= 1000) {
                        return (value / 1000).toFixed(1) + 'K公里';
                    }
                    return value + '公里';
                }
            }
        }]
    };
    
    chart.setOption(option);
    
    // 强制resize确保正确显示
    setTimeout(() => {
        chart.resize();
    }, 100);
}

// 城市航班分布地图
function renderCityMapChart(data) {
    const chartDom = document.getElementById('city-map-chart');
    const chart = echarts.init(chartDom);
    geoCharts.cityMap = chart;
    
    // 加载中国地图
    chart.showLoading();
    registerMap(chart, function() {
        continueRenderMap();
    });
    
    function continueRenderMap() {
        try {
            const mapData = data.map(item => ({
                name: item.city,
                value: [item.lng, item.lat, item.depCount + item.arrCount],
                depCount: item.depCount,
                arrCount: item.arrCount
            }));
    
    const option = {
        tooltip: {
            trigger: 'item',
            formatter: function(params) {
                const data = params.data;
                return `${data.name}<br/>总航班量: ${data.value[2]}<br/>出发: ${data.depCount}<br/>到达: ${data.arrCount}`;
            }
        },
        visualMap: {
            min: 0,
            max: Math.max(...mapData.map(item => item.value[2])),
            calculable: true,
            inRange: {
                color: ['#50a3ba', '#eac736', '#d94e5d']
            },
            textStyle: {
                color: '#333'
            },
            left: 'right',
            top: 'bottom',
            text: ['高航班量', '低航班量'],
            dimension: 2
        },
        legend: {
            data: ['航班数量', '航线'],
            orient: 'horizontal',
            bottom: 10,
            textStyle: {
                color: '#333'
            }
        },
        geo: {
            map: 'china',
            roam: true,
            zoom: 1.2, 
            center: [104.0, 37.5], 
            label: {
                show: true,  
                fontSize: 10,
                color: '#333'
            },
            itemStyle: {
                areaColor: '#f3f3f3',
                borderColor: '#ddd',
                borderWidth: 1
            },
            emphasis: {
                label: {
                    show: true,
                    fontSize: 12,
                    fontWeight: 'bold'
                },
                itemStyle: {
                    areaColor: '#e6f7ff'
                }
            }
        },
        series: [{
            name: '航班数量',
            type: 'scatter',
            coordinateSystem: 'geo',
            data: mapData,
            symbolSize: function(val) {
                return Math.min(Math.max(val[2] / 2, 15), 45);
            },
            encode: {
                value: 2
            },
            itemStyle: {
                    color: function(params) {
                        const value = params.data.value[2];
                        if (value > 800) return '#d94e5d';
                        if (value > 400) return '#eac736';
                        return '#50a3ba';
                    },
                    shadowBlur: 10,
                    shadowColor: 'rgba(0, 0, 0, 0.3)'
                },
                tooltip: {
                    formatter: function(params) {
                        const data = params.data;
                        return `${data.name}<br/>总航班量: <b>${data.value[2]}</b><br/>出发航班: ${data.depCount}<br/>到达航班: ${data.arrCount}`;
                    }
                },
            label: {
                formatter: '{b}',
                position: 'right',
                show: true,
                color: '#333',
                fontWeight: 'bold'
            },
            emphasis: {
                label: {
                    show: true,
                    formatter: function(params) {
                        return params.name + '\n' + params.data.value[2] + '架次';
                    },
                    backgroundColor: 'rgba(255,255,255,0.8)',
                    padding: [4, 8],
                    borderRadius: 4
                },
                itemStyle: {
                    shadowBlur: 20,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            }
        }]
    };
    
        chart.hideLoading();
        chart.setOption(option);
        } catch (error) {
            console.error('城市航班分布地图渲染错误:', error);
            chart.hideLoading();
            chartDom.innerHTML = '<div style="text-align:center;line-height:300px;color:red;">地图渲染失败</div>';
        }
    }
}

// 注册中国地图
function registerMap(chart, callback) {
    if (!echarts.getMap('china')) {
        console.log('正在加载中国地图数据...');
        $.get('https://geo.datav.aliyun.com/areas_v3/bound/100000_full.json', function(chinaJson) {
            console.log('中国地图数据加载成功');
            echarts.registerMap('china', chinaJson);
            if (callback) callback();
        });
    } else {
        console.log('中国地图数据已成功加载');
        if (callback) callback();
    }
}

// 调整所有图表大小
function resizeAllCharts() {
    const activeSection = document.querySelector('.content-section.active');
    if (activeSection.id === 'core-content') {
        Object.values(coreCharts).forEach(chart => {
            if (chart && typeof chart.resize === 'function') {
                chart.resize();
            }
        });
    } else if (activeSection.id === 'market-content') {
        Object.values(marketCharts).forEach(chart => {
            if (chart && typeof chart.resize === 'function') {
                chart.resize();
            }
        });
    } else if (activeSection.id === 'time-content') {
        Object.values(timeCharts).forEach(chart => {
            if (chart && typeof chart.resize === 'function') {
                chart.resize();
            }
        });
    } else if (activeSection.id === 'geo-content') {
        Object.values(geoCharts).forEach(chart => {
            if (chart && typeof chart.resize === 'function') {
                chart.resize();
            }
        });
    }
}

// 获取地理指标模拟数据
function getMockGeoData() {
    return {
        "departureStats": [
            {
                "airportName": "首都机场",
                "flightCount": 954
            },
            {
                "airportName": "江北机场",
                "flightCount": 680
            },
            {
                "airportName": "白云机场",
                "flightCount": 678
            },
            {
                "airportName": "长水机场",
                "flightCount": 672
            },
            {
                "airportName": "双流机场",
                "flightCount": 639
            }
        ],
        "landingStats":[
            {
                "airportName": "首都机场",
                "flightCount": 881
            },
            {
                "airportName": "白云机场",
                "flightCount": 695
            },
            {
                "airportName": "江北机场",
                "flightCount": 635
            },
            {
                "airportName": "双流机场",
                "flightCount": 627
            },
            {
                "airportName": "宝安机场",
                "flightCount": 620
            }
        ],
        "routeStats":[
            {
                "depCity": "成都",
                "arrCity": "昆明",
                "flightCount": 45
            },
            {
                "depCity": "上海",
                "arrCity": "成都",
                "flightCount": 45
            },
            {
                "depCity": "重庆",
                "arrCity": "北京",
                "flightCount": 45
            },
            {
                "depCity": "重庆",
                "arrCity": "上海",
                "flightCount": 45
            },
            {
                "depCity": "北京",
                "arrCity": "重庆",
                "flightCount": 45
            },
            {
                "depCity": "大连",
                "arrCity": "上海",
                "flightCount": 45
            },
            {
                "depCity": "昆明",
                "arrCity": "成都",
                "flightCount": 45
            }
        ]
    };
}

// 机型航班数饼图
function renderAircraftFlight3DChart(data) {
    const chartDom = document.getElementById('aircraft-flight-chart');
    if (!ensureChartContainerSize(chartDom)) return;
    
    console.log('机型航班数据:', data);
    
    // 如果数据为空，显示提示信息
    if (!data || data.length === 0) {
        chartDom.innerHTML = '<div style="text-align:center;line-height:300px;color:#666;">暂无机型航班数据</div>';
        return;
    }
    
    const chart = echarts.init(chartDom);
    marketCharts.aircraftFlight = chart;
    
    // 计算总数
    let total = 0;
    data.forEach(item => {
        total += item.flightCount;
    });
    
    // 转换数据格式，只显示前10个机型，其余归为"其他"
    const topData = [...data].sort((a, b) => b.flightCount - a.flightCount).slice(0, 10);
    const otherCount = data.slice(10).reduce((sum, item) => sum + item.flightCount, 0);
    
    const pieData = topData.map(item => ({
        name: item.aircraftModel,
        value: item.flightCount
    }));
    
    // 如果有其他机型，添加到数据中
    if (otherCount > 0) {
        pieData.push({
            name: '其他机型',
            value: otherCount
        });
    }
    
    const option = {
        tooltip: {
            trigger: 'item',
            formatter: function(params) {
                const percentage = ((params.value / total) * 100).toFixed(1);
                return `${params.name}<br/>航班数: ${params.value}架次<br/>占比: ${percentage}%`;
            }
        },
        legend: {
            orient: 'vertical',
            left: '2%',
            top: '10%',
            textStyle: {
                fontSize: 12
            },
            itemWidth: 12,
            itemHeight: 12,
            itemGap: 8
        },
        series: [{
            name: '机型分布',
            type: 'pie',
            radius: ['40%', '70%'],
            center: ['60%', '50%'],
            avoidLabelOverlap: false,
            itemStyle: {
                borderRadius: 8,
                borderColor: '#fff',
                borderWidth: 2
            },
            label: {
                show: true,
                position: 'outside',
                formatter: function(params) {
                    const percentage = ((params.value / total) * 100).toFixed(1);
                    // 确保百分比不为0.0%，如果小于0.1%则显示<0.1%
                    const displayPercentage = percentage === '0.0' ? '<0.1' : percentage;
                    return `${displayPercentage}%`;
                },
                fontSize: 11
            },
            emphasis: {
                label: {
                    show: true,
                    fontSize: 14,
                    fontWeight: 'bold'
                },
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            },
            labelLine: {
                show: true,
                length: 15,
                length2: 10
            },
            data: pieData,
            animationType: 'scale',
            animationEasing: 'elasticOut',
            animationDelay: function (idx) {
                return Math.random() * 200;
            }
        }]
    };
    
    chart.setOption(option);
    
    // 强制resize确保正确显示
    setTimeout(() => {
        chart.resize();
    }, 100);
}

// 渲染航班时刻表
function renderFlightScheduleTable(data) {
    const tbody = document.getElementById('flight-schedule-tbody');
    if (!tbody) {
        console.error('找不到航班时刻表容器');
        return;
    }
    // 清空现有内容
    tbody.innerHTML = '';
    if (!data || data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:#666;">暂无航班时刻表数据</td></tr>';
        return;
    }
    // 渲染数据
    data.forEach(schedule => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${schedule.flightNo || ''}</td>
            <td>${schedule.airline || ''}</td>
            <td>${schedule.firstDepartureTime || ''}</td>
            <td>${schedule.lastArrivalTime || ''}</td>
        `;
        tbody.appendChild(row);
    });
}

// ================== 时间指标-航班甘特图 ==================

function initAirlineSelectAndGantt() {
    const select = document.getElementById('airline-select');
    if (!select) return;
    // 获取所有航司
    fetch('http://localhost:8080/flight-schedule/airlines')
        .then(res => res.json())
        .then(res => {
            if (res.code === 1 && Array.isArray(res.data)) {
                select.innerHTML = res.data.map(airline => `<option value="${airline}">${airline}</option>`).join('');
                if (res.data.length > 0) {
                    fetchAndRenderGantt(res.data[0]);
                }
            }
        });
    select.addEventListener('change', function() {
        fetchAndRenderGantt(this.value);
    });
}

function fetchAndRenderGantt(airline) {
    document.getElementById('airline-gantt-title').innerText = airline ? `当前航司：${airline}` : '';
    fetch(`http://localhost:8080/flight-schedule/airline/${encodeURIComponent(airline)}`)
        .then(res => res.json())
        .then(res => {
            if (res.code === 1 && Array.isArray(res.data)) {
                renderFlightGanttChart(res.data);
            } else {
                renderFlightGanttChart([]);
            }
        });
}

function renderFlightGanttChart(data) {
    const chartDom = document.getElementById('flight-gantt-chart');
    if (!chartDom) return;
    if (!data || data.length === 0) {
        chartDom.innerHTML = '<div style="text-align:center;line-height:300px;color:#666;">暂无该航司航班数据</div>';
        return;
    }
    // 每个航班24px，最小300px，最大1200px
    const height = Math.max(300, Math.min(data.length * 24, 1200));
    chartDom.style.height = height + 'px';
    chartDom.style.overflowY = 'auto';

    function timeToMinutes(t) {
        if (!t) return 0;
        const [h, m] = t.split(':').map(Number);
        return h * 60 + m;
    }
    const xMin = 0, xMax = 1440;
    const yData = data.map((_, idx) => idx + 1);

    const customData = data.map((item, idx) => ({
        flightNo: item.flightNo,
        firstDepartureTime: item.firstDepartureTime,
        lastArrivalTime: item.lastArrivalTime,
        y: idx,
        xStart: timeToMinutes(item.firstDepartureTime),
        xEnd: timeToMinutes(item.lastArrivalTime)
    }));

    // 高辨识度配色
    const colorList = [
        '#6c8ae4', '#50a3ba', '#d94e5d', '#eac736', '#5ab1ef', '#b6a2de',
        '#ffb980', '#2ec7c9', '#b7d28d', '#f5994e', '#c05050', '#4b565b',
        '#009688', '#f44336', '#8bc34a', '#ffc107', '#9c27b0', '#03a9f4',
        '#e91e63', '#607d8b', '#795548', '#00bcd4', '#ff5722', '#cddc39'
    ];

    const option = {
        tooltip: {
            formatter: function(params) {
                const d = params.data;
                return `航班号: <b>${d[0]}</b><br>起飞: <b>${d[1]}</b><br>降落: <b>${d[2]}</b>`;
            },
            backgroundColor: '#fff',
            borderColor: '#667eea',
            borderWidth: 1,
            textStyle: { color: '#333', fontSize: 13 }
        },
        grid: { left: 50, right: 40, top: 30, bottom: 50 },
        xAxis: {
            min: xMin,
            max: xMax,
            type: 'value',
            axisLabel: {
                fontSize: 11,
                formatter: function(val) {
                    const h = Math.floor(val / 60).toString().padStart(2, '0');
                    const m = (val % 60).toString().padStart(2, '0');
                    return `${h}:${m}`;
                }
            },
            splitNumber: 24,
            interval: 60,
            name: '时间',
            nameTextStyle: { fontWeight: 600, fontSize: 13 }
        },
        yAxis: {
            type: 'category',
            data: yData,
            name: '',
            axisLabel: { show: false }
        },
        series: [{
            type: 'custom',
            renderItem: function(params, api) {
                const yIndex = api.value(3);
                const xStart = api.coord([api.value(4), yIndex]);
                const xEnd = api.coord([api.value(5), yIndex]);
                const barHeight = 18;
                return {
                    type: 'rect',
                    shape: {
                        x: xStart[0],
                        y: xStart[1] - barHeight / 2,
                        width: Math.max(xEnd[0] - xStart[0], 2),
                        height: barHeight
                    },
                    style: api.style({
                        fill: colorList[yIndex % colorList.length], // 每个航班不同色
                        shadowColor: '#b3c6f7',
                        shadowBlur: 4
                    })
                };
            },
            encode: {
                x: [4, 5],
                y: 3
            },
            data: customData.map(d => [
                d.flightNo,
                d.firstDepartureTime,
                d.lastArrivalTime,
                d.y,
                d.xStart,
                d.xEnd
            ])
        }]
    };
    const chart = echarts.init(chartDom);
    chart.setOption(option);
    setTimeout(() => chart.resize(), 100);
}

// 支持航班多选下拉框鼠标滚轮滚动
(function enableFlightSelectWheelScroll() {
    const flightSelect = document.getElementById('flight-select');
    if (!flightSelect) return;
    flightSelect.addEventListener('wheel', function(e) {
        // 只在有滚动条时阻止默认
        if (this.scrollHeight > this.clientHeight) {
            e.preventDefault();
            this.scrollTop += e.deltaY;
        }
    });
})();

// 全选和清空按钮功能
(function enableFlightSelectButtons() {
    const flightSelect = document.getElementById('flight-select');
    const btnAll = document.getElementById('flight-select-all');
    const btnClear = document.getElementById('flight-select-clear');
    if (!flightSelect || !btnAll || !btnClear) return;
    btnAll.addEventListener('click', function() {
        for (let i = 0; i < flightSelect.options.length; i++) {
            flightSelect.options[i].selected = true;
        }
        renderSelectedFlightsGantt();
    });
    btnClear.addEventListener('click', function() {
        for (let i = 0; i < flightSelect.options.length; i++) {
            if (flightSelect.options[i].selected) {
                flightSelect.options[i].selected = false;
            }
        }
        renderSelectedFlightsGantt();
    });
})();

// ================== 时间指标-航班甘特图（多选航班） ==================

document.addEventListener('DOMContentLoaded', function() {
    initAirlineSelectAndGantt();
});

function initAirlineSelectAndGantt() {
    const airlineSelect = document.getElementById('airline-select');
    const flightSelect = document.getElementById('flight-select');
    if (!airlineSelect || !flightSelect) return;
    // 获取所有航司
    fetch('http://localhost:8080/flight-schedule/airlines')
        .then(res => res.json())
        .then(res => {
            if (res.code === 1 && Array.isArray(res.data)) {
                airlineSelect.innerHTML = res.data.map(airline => `<option value="${airline}">${airline}</option>`).join('');
                if (res.data.length > 0) {
                    fetchAndFillFlights(res.data[0]);
                }
            }
        });
    airlineSelect.addEventListener('change', function() {
        fetchAndFillFlights(this.value);
    });
    flightSelect.addEventListener('change', function() {
        renderSelectedFlightsGantt();
    });
}

let allFlightsOfCurrentAirline = [];

function fetchAndFillFlights(airline) {
    document.getElementById('airline-gantt-title').innerText = airline ? `当前航司：${airline}` : '';
    fetch(`http://localhost:8080/flight-schedule/airline/${encodeURIComponent(airline)}`)
        .then(res => res.json())
        .then(res => {
            if (res.code === 1 && Array.isArray(res.data)) {
                allFlightsOfCurrentAirline = res.data;
                const flightSelect = document.getElementById('flight-select');
                flightSelect.innerHTML = res.data.map(f => `<option value="${f.flightNo}">${f.flightNo}</option>`).join('');
                // 默认全选前10个
                for (let i = 0; i < Math.min(10, res.data.length); i++) {
                    flightSelect.options[i].selected = true;
                }
                renderSelectedFlightsGantt();
            } else {
                allFlightsOfCurrentAirline = [];
                document.getElementById('flight-select').innerHTML = '';
                renderFlightGanttChart([]);
            }
        });
}

function renderSelectedFlightsGantt() {
    const flightSelect = document.getElementById('flight-select');
    const selected = Array.from(flightSelect.selectedOptions).map(opt => opt.value);
    const showFlights = allFlightsOfCurrentAirline.filter(f => selected.includes(f.flightNo));
    renderFlightGanttChart(showFlights);
}