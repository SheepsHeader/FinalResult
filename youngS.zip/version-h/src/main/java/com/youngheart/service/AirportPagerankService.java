package com.youngheart.service;



import com.youngheart.domain.vo.time.AirportPagerankVO;
import com.youngheart.domain.vo.time.FlightRouteDensityStatsVO;
import com.youngheart.domain.vo.time.FlightTimeSlotStatsVO;
import com.youngheart.domain.vo.time.FlightScheduleVO;

import java.util.List;

public interface AirportPagerankService {

    /**
     * Retrieves all airport pagerank statistics.
     * @return A list of AirportPagerankVO objects.
     */
    List<AirportPagerankVO> getAllAirportPagerank();
    List<FlightTimeSlotStatsVO> findAllFlightTimeSlotStats();
    List<FlightRouteDensityStatsVO> findByRoute();
    
    /**
     * 获取所有航班时刻表数据
     * @return 航班时刻表列表
     */
    List<FlightScheduleVO> getAllFlightSchedules();
}