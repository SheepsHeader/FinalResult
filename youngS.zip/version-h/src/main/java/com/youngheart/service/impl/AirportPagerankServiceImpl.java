package com.youngheart.service.impl;

import com.youngheart.domain.vo.time.AirportPagerankVO;
import com.youngheart.domain.vo.time.FlightRouteDensityStatsVO;
import com.youngheart.domain.vo.time.FlightTimeSlotStatsVO;
import com.youngheart.domain.vo.time.FlightScheduleVO;
import com.youngheart.mapper.AirportPagerankMapper;
import com.youngheart.mapper.FlightScheduleMapper;
import com.youngheart.service.AirportPagerankService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AirportPagerankServiceImpl implements AirportPagerankService {

    private final AirportPagerankMapper airportPagerankMapper;
    private final FlightScheduleMapper flightScheduleMapper;

    @Autowired
    public AirportPagerankServiceImpl(AirportPagerankMapper airportPagerankMapper, FlightScheduleMapper flightScheduleMapper) {
        this.airportPagerankMapper = airportPagerankMapper;
        this.flightScheduleMapper = flightScheduleMapper;
    }

    @Override
    public List<AirportPagerankVO> getAllAirportPagerank() {
        // Error handling can be added here, but for a direct return,
        // Spring's default exception handling might suffice, or you can
        // throw custom exceptions to be handled by a @ControllerAdvice.
        return airportPagerankMapper.findAllAirportPagerank();
    }

    @Override
    public List<FlightTimeSlotStatsVO> findAllFlightTimeSlotStats() {
        return airportPagerankMapper.findAllFlightTimeSlotStats();
    }
    public List<FlightRouteDensityStatsVO> findByRoute(){
        return airportPagerankMapper.findByRoute();
    }

    @Override
    public List<FlightScheduleVO> getAllFlightSchedules() {
        return flightScheduleMapper.selectAllFlightSchedules();
    }
}