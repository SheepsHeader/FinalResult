package com.youngheart.service;

import com.youngheart.domain.vo.flight.GeoStatsResponseVO;

public interface GeoService {

GeoStatsResponseVO getAllGeoStats();
}
