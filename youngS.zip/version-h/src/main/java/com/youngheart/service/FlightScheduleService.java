package com.youngheart.service;

import com.youngheart.domain.vo.time.FlightScheduleVO;

import java.util.List;

public interface FlightScheduleService {
    
    /**
     * 获取所有航班时刻表数据
     * @return 航班时刻表列表
     */
    List<FlightScheduleVO> getAllFlightSchedules();
    
    /**
     * 根据航班号获取航班时刻表
     * @param flightNo 航班号
     * @return 航班时刻表信息
     */
    FlightScheduleVO getFlightScheduleByFlightNo(String flightNo);
    
    /**
     * 根据航空公司获取航班时刻表
     * @param airline 航空公司
     * @return 航班时刻表列表
     */
    List<FlightScheduleVO> getFlightSchedulesByAirline(String airline);
    
    /**
     * 添加航班时刻表
     * @param flightSchedule 航班时刻表对象
     * @return 是否成功
     */
    boolean addFlightSchedule(FlightScheduleVO flightSchedule);
    
    /**
     * 更新航班时刻表
     * @param flightSchedule 航班时刻表对象
     * @return 是否成功
     */
    boolean updateFlightSchedule(FlightScheduleVO flightSchedule);
    
    /**
     * 删除航班时刻表
     * @param flightNo 航班号
     * @return 是否成功
     */
    boolean deleteFlightSchedule(String flightNo);

    /**
     * 获取所有航司
     */
    List<String> getAllAirlines();
} 