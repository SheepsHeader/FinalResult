package com.youngheart.service;

import com.youngheart.domain.vo.core.CoreResult;

public interface CoreService {
    public CoreResult getCoreInfo();
}
