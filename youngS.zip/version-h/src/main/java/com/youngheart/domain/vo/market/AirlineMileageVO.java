package com.youngheart.domain.vo.market;

import lombok.Data;

@Data
public class AirlineMileageVO {
    private String airlineName;
    private Long totalMileage;

    public AirlineMileageVO(String airlineName, Long totalMileage) {
        this.airlineName = airlineName;
        this.totalMileage = totalMileage;
    }

    public AirlineMileageVO() {
    }

    public String getAirlineName() {
        return airlineName;
    }

    public void setAirlineName(String airlineName) {
        this.airlineName = airlineName;
    }

    public Long getTotalMileage() {
        return totalMileage;
    }

    public void setTotalMileage(Long totalMileage) {
        this.totalMileage = totalMileage;
    }
} 