package com.youngheart.domain.vo.market;

import lombok.Data;

@Data
public class AircraftFlightVO {
    private String aircraftModel;
    private Integer flightCount;

    public AircraftFlightVO(String aircraftModel, Integer flightCount) {
        this.aircraftModel = aircraftModel;
        this.flightCount = flightCount;
    }

    public AircraftFlightVO() {
    }

    public String getAircraftModel() {
        return aircraftModel;
    }

    public void setAircraftModel(String aircraftModel) {
        this.aircraftModel = aircraftModel;
    }

    public Integer getFlightCount() {
        return flightCount;
    }

    public void setFlightCount(Integer flightCount) {
        this.flightCount = flightCount;
    }
} 