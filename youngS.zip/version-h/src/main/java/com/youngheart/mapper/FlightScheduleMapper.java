package com.youngheart.mapper;

import com.youngheart.domain.vo.time.FlightScheduleVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface FlightScheduleMapper {
    
    /**
     * 查询所有航班时刻表数据
     * @return 航班时刻表列表
     */
    List<FlightScheduleVO> selectAllFlightSchedules();
    
    /**
     * 根据航班号查询航班时刻表
     * @param flightNo 航班号
     * @return 航班时刻表信息
     */
    FlightScheduleVO selectByFlightNo(String flightNo);
    
    /**
     * 根据航空公司查询航班时刻表
     * @param airline 航空公司
     * @return 航班时刻表列表
     */
    List<FlightScheduleVO> selectByAirline(String airline);
    
    /**
     * 插入新的航班时刻表数据
     * @param flightSchedule 航班时刻表对象
     * @return 影响的行数
     */
    int insertFlightSchedule(FlightScheduleVO flightSchedule);
    
    /**
     * 更新航班时刻表数据
     * @param flightSchedule 航班时刻表对象
     * @return 影响的行数
     */
    int updateFlightSchedule(FlightScheduleVO flightSchedule);
    
    /**
     * 根据航班号删除航班时刻表数据
     * @param flightNo 航班号
     * @return 影响的行数
     */
    int deleteByFlightNo(String flightNo);

    /**
     * 获取所有航司（去重）
     */
    List<String> getAllAirlines();
} 