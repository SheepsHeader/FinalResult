package com.youngheart.mapper;

import com.youngheart.domain.vo.core.DelayVO;
import com.youngheart.domain.vo.core.PrateVO;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface CoreMapper {

    //获取航司的Top5和Bottom5延误信息
    @Select("(SELECT name, avg_delay\n" +
            "FROM airline_delay_info\n" +
            "ORDER BY avg_delay DESC\n" +
            "LIMIT 5)\n" +
            "UNION ALL\n" +
            "(SELECT name, avg_delay\n" +
            "FROM airline_delay_info\n" +
            "WHERE avg_delay > 0\n" +
            "ORDER BY avg_delay ASC\n" +
            "LIMIT 5)\n" +
            "ORDER BY avg_delay DESC;")
    List<DelayVO> getAirlineDelay();

    //获取机场的Top5和Bottom5延误信息
    @Select("(SELECT name, avg_delay\n" +
            "FROM airport_delay_info\n" +
            "ORDER BY avg_delay DESC\n" +
            "LIMIT 5)\n" +
            "UNION ALL\n" +
            "(SELECT name, avg_delay\n" +
            "FROM airport_delay_info\n" +
            "WHERE avg_delay > 0\n" +
            "ORDER BY avg_delay ASC\n" +
            "LIMIT 5)\n" +
            "ORDER BY avg_delay DESC;")
    List<DelayVO> getAirportDelay();

    //获取线路的最大和最小的延误信息
    @Select("SELECT name, avg_delay FROM (\n" +
            "  SELECT name, avg_delay FROM line_delay_info ORDER BY avg_delay DESC LIMIT 5\n" +
            ") t1\n" +
            "UNION ALL\n" +
            "SELECT name, avg_delay FROM (\n" +
            "  SELECT name, avg_delay FROM line_delay_info WHERE avg_delay > 0 ORDER BY avg_delay ASC LIMIT 5\n" +
            ") t2")
    List<DelayVO> getLineDelay();

    @Select(
        "SELECT name, avg_punctuality AS punctuality FROM (" +
        "  SELECT airline_name AS name, avg_punctuality FROM airline_avg_punctuality ORDER BY avg_punctuality DESC LIMIT 5" +
        ") t1 " +
        "UNION ALL " +
        "SELECT name, avg_punctuality AS punctuality FROM (" +
        "  SELECT airline_name AS name, avg_punctuality FROM airline_avg_punctuality ORDER BY avg_punctuality ASC LIMIT 5" +
        ") t2"
    )
    List<PrateVO> getPrate();

}
