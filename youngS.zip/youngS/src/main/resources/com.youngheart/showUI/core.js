document.addEventListener('DOMContentLoaded', function() {
    // 初始化标签切换
    initTabSwitching();
    fetchCoreData();
    window.addEventListener('resize', function() {
        resizeAllCharts();
    });
});

// 存储所有图表实例
const coreCharts = {};
const marketCharts = {};
const timeCharts = {};
const geoCharts = {};

// 调整所有图表大小
function resizeAllCharts() {
    for (const key in coreCharts) {
        coreCharts[key] && coreCharts[key].resize();
    }
    for (const key in marketCharts) {
        marketCharts[key] && marketCharts[key].resize();
    }
    for (const key in timeCharts) {
        timeCharts[key] && timeCharts[key].resize();
    }
    for (const key in geoCharts) {
        geoCharts[key] && geoCharts[key].resize();
    }
}

// 初始化标签切换功能
function initTabSwitching() {
    const tabLinks = document.querySelectorAll('.tab-link');
    
    tabLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            tabLinks.forEach(item => item.classList.remove('active'));
            this.classList.add('active');
            const targetId = this.getAttribute('data-tab');
            document.querySelectorAll('.content-section').forEach(section => {
                section.classList.remove('active');
            });
            document.getElementById(targetId).classList.add('active');
            if (targetId === 'core-content') {
                fetchCoreData();
            } else if (targetId === 'market-content') {
                fetchMarketData();
            } else if (targetId === 'time-content') {
                fetchTimeData();
            } else if (targetId === 'geo-content') {
                fetchGeoData();
            }
        });
    });
}

// 获取业务指标数据
function fetchCoreData() {
    fetch('http://localhost:8080/core')
        .then(response => {
            if (!response.ok) {
                throw new Error('网络响应不正常');
            }
            return response.json();
        })
        .then(data => {
            renderCoreCharts(data);
        })
        .catch(error => {
            console.error('获取业务指标数据出错:', error);
            const mockData = getMockCoreData();
            renderCoreCharts(mockData);
        });
}

// 获取市场指标数据
function fetchMarketData() {
    fetch('http://localhost:8080/market')
        .then(response => {
            if (!response.ok) {
                throw new Error('网络响应不正常');
            }
            return response.json();
        })
        .then(data => {
            renderMarketCharts(data);
        })
        .catch(error => {
            console.error('获取市场指标数据出错:', error);
            const mockData = getMockMarketData();
            renderMarketCharts(mockData);
        });
}

// 获取时间指标数据
function fetchTimeData() {
    fetch('http://localhost:8080/time')
        .then(response => {
            if (!response.ok) {
                throw new Error('网络响应不正常');
            }
            return response.json();
        })
        .then(data => {
            console.log('时间指标数据:', data);
            renderTimeSlotPieChart(data.flightTimeSlotStatsVOList);
            renderRouteCompetitionBarChart(data.flightRouteDensityStatsVOList);
            renderAirportKnowledgeGraph(data.airportPagerankVOList);
        })
        .catch(error => {
            console.error('获取时间指标数据出错:', error);
            // 使用模拟数据进行展示
            const mockData = getMockTimeData();
            renderTimeSlotPieChart(mockData.flightTimeSlotStatsVOList);
            renderRouteCompetitionBarChart(mockData.flightRouteDensityStatsVOList);
            renderAirportKnowledgeGraph(mockData.airportPagerankVOList);
        });
}

// 渲染航班时间段分布饼图
function renderTimeSlotPieChart(data) {
    const chartDom = document.getElementById('time-slot-chart');
    if (!chartDom) return;
    const chart = echarts.init(chartDom);
    timeCharts.timeSlot = chart;

    // 聚合相同时间段的数据
    const timeSlotData = {};
    data.forEach(item => {
        if (!timeSlotData[item.timeSlot]) {
            timeSlotData[item.timeSlot] = 0;
        }
        timeSlotData[item.timeSlot] += item.flightCount;
    });

    // 准备饼图数据
    const pieData = Object.entries(timeSlotData).map(([name, value]) => ({
        name,
        value
    }));

    const option = {
        tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b}: {c} ({d}%)'
        },
        legend: {
            orient: 'vertical',
            left: 10,
            data: Object.keys(timeSlotData)
        },
        series: [
            {
                name: '航班数量',
                type: 'pie',
                radius: ['40%', '70%'],
                avoidLabelOverlap: false,
                itemStyle: {
                    borderRadius: 10,
                    borderColor: '#fff',
                    borderWidth: 2
                },
                label: {
                    show: false,
                    position: 'center'
                },
                emphasis: {
                    label: {
                        show: true,
                        fontSize: 16,
                        fontWeight: 'bold'
                    }
                },
                labelLine: {
                    show: false
                },
                data: pieData
            }
        ]
    };

    chart.setOption(option);
    window.addEventListener('resize', () => chart.resize());
}

// 渲染航线竞争强度柱状图
function renderRouteCompetitionBarChart(data) {
    const chartDom = document.getElementById('route-competition-chart');
    if (!chartDom) return;
    const chart = echarts.init(chartDom);
    timeCharts.competition = chart;

    // 提取前10条航线数据
    const topData = [...data].sort((a, b) => b.airlineCount - a.airlineCount).slice(0, 10);
    const routes = topData.map(item => item.route);
    const airlineCounts = topData.map(item => item.airlineCount);
    const flightDensity = topData.map(item => item.flightDensityDaily);

    const option = {
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'shadow'
            }
        },
        legend: {
            data: ['航空公司数量', '航班密度(每日)']
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis: {
            type: 'value',
            boundaryGap: [0, 0.01]
        },
        yAxis: {
            type: 'category',
            data: routes
        },
        series: [
            {
                name: '航空公司数量',
                type: 'bar',
                data: airlineCounts,
                itemStyle: {
                    color: '#50a3ba'
                }
            },
            {
                name: '航班密度(每日)',
                type: 'bar',
                data: flightDensity,
                itemStyle: {
                    color: '#d94e5d'
                }
            }
        ]
    };

    chart.setOption(option);
    window.addEventListener('resize', () => chart.resize());
}

function renderAirportKnowledgeGraph(data) {
    const chartDom = document.getElementById('airport-knowledge-graph');
    if (!chartDom) return;
    const chart = echarts.init(chartDom);
    timeCharts.knowledgeGraph = chart;

    const nodes = data.map(item => ({
        name: item.airport,
        value: item.pagerank,
        symbolSize: Math.min(50, Math.max(10, item.pagerank / 0.5))
    }));

    const links = [];
    for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < Math.min(i + 3, nodes.length); j++) {
            links.push({
                source: nodes[i].name,
                target: nodes[j].name,
                value: Math.random() * 3 + 1
            });
        }
    }

    const option = {
        title: {
            text: '机场重要性知识图谱',
            left: 'center'
        },
        tooltip: {
            formatter: '{b}: {c}'
        },
        legend: [{
            data: ['机场节点'],
            left: 'left'
        }],
        series: [{
            name: '机场节点',
            type: 'graph',
            layout: 'force',
            force: {
                repulsion: 200,
                edgeLength: 100
            },
            roam: true,
            label: {
                show: true
            },
            edgeSymbol: ['none', 'arrow'],
            edgeSymbolSize: [0, 10],
            edgeLabel: {
                fontSize: 10
            },
            data: nodes,
            links: links,
            lineStyle: {
                opacity: 0.9,
                width: 1,
                curveness: 0
            }
        }]
    };

    chart.setOption(option);
    window.addEventListener('resize', () => chart.resize());
}

// 生成时间指标模拟数据
function getMockTimeData() {
    return {
        "airportPagerankVOList": [
            {"airport": "首都机场", "pagerank": 6.6263577145856685},
            {"airport": "白云机场", "pagerank": 4.921869904311425},
            {"airport": "双流机场", "pagerank": 4.650052164994991},
            {"airport": "长水机场", "pagerank": 4.514393872340536},
            {"airport": "宝安机场", "pagerank": 4.490016265114064},
            {"airport": "江北机场", "pagerank": 4.465776759873335},
            {"airport": "咸阳机场", "pagerank": 3.817889621620452},
            {"airport": "浦东机场", "pagerank": 3.6499772736089393},
            {"airport": "地窝堡机场", "pagerank": 2.812630439318486},
            {"airport": "萧山机场", "pagerank": 2.788741854648085}
        ],
        "flightTimeSlotStatsVOList": [
            {"timeSlot": "00:00 - 01:59", "airline": "九元航空", "flightCount": 1},
            {"timeSlot": "00:00 - 01:59", "airline": "祥鹏航空", "flightCount": 1},
            {"timeSlot": "00:00 - 01:59", "airline": "东方航空", "flightCount": 1},
            {"timeSlot": "02:00 - 03:59", "airline": "南方航空", "flightCount": 2},
            {"timeSlot": "02:00 - 03:59", "airline": "中国国航", "flightCount": 1},
            {"timeSlot": "04:00 - 05:59", "airline": "海南航空", "flightCount": 3},
            {"timeSlot": "06:00 - 07:59", "airline": "东方航空", "flightCount": 15},
            {"timeSlot": "06:00 - 07:59", "airline": "南方航空", "flightCount": 12},
            {"timeSlot": "06:00 - 07:59", "airline": "中国国航", "flightCount": 10},
            {"timeSlot": "08:00 - 09:59", "airline": "东方航空", "flightCount": 28},
            {"timeSlot": "08:00 - 09:59", "airline": "南方航空", "flightCount": 25},
            {"timeSlot": "08:00 - 09:59", "airline": "中国国航", "flightCount": 22},
            {"timeSlot": "08:00 - 09:59", "airline": "海南航空", "flightCount": 18},
            {"timeSlot": "10:00 - 11:59", "airline": "东方航空", "flightCount": 32},
            {"timeSlot": "10:00 - 11:59", "airline": "南方航空", "flightCount": 29},
            {"timeSlot": "10:00 - 11:59", "airline": "中国国航", "flightCount": 26},
            {"timeSlot": "10:00 - 11:59", "airline": "海南航空", "flightCount": 20},
            {"timeSlot": "12:00 - 13:59", "airline": "东方航空", "flightCount": 25},
            {"timeSlot": "12:00 - 13:59", "airline": "南方航空", "flightCount": 22},
            {"timeSlot": "12:00 - 13:59", "airline": "中国国航", "flightCount": 20},
            {"timeSlot": "14:00 - 15:59", "airline": "东方航空", "flightCount": 30},
            {"timeSlot": "14:00 - 15:59", "airline": "南方航空", "flightCount": 28},
            {"timeSlot": "14:00 - 15:59", "airline": "中国国航", "flightCount": 25},
            {"timeSlot": "14:00 - 15:59", "airline": "海南航空", "flightCount": 22},
            {"timeSlot": "16:00 - 17:59", "airline": "东方航空", "flightCount": 35},
            {"timeSlot": "16:00 - 17:59", "airline": "南方航空", "flightCount": 32},
            {"timeSlot": "16:00 - 17:59", "airline": "中国国航", "flightCount": 28},
            {"timeSlot": "16:00 - 17:59", "airline": "海南航空", "flightCount": 25},
            {"timeSlot": "18:00 - 19:59", "airline": "东方航空", "flightCount": 38},
            {"timeSlot": "18:00 - 19:59", "airline": "南方航空", "flightCount": 35},
            {"timeSlot": "18:00 - 19:59", "airline": "中国国航", "flightCount": 30},
            {"timeSlot": "18:00 - 19:59", "airline": "海南航空", "flightCount": 28},
            {"timeSlot": "20:00 - 21:59", "airline": "东方航空", "flightCount": 25},
            {"timeSlot": "20:00 - 21:59", "airline": "南方航空", "flightCount": 22},
            {"timeSlot": "20:00 - 21:59", "airline": "中国国航", "flightCount": 20},
            {"timeSlot": "22:00 - 23:59", "airline": "东方航空", "flightCount": 10},
            {"timeSlot": "22:00 - 23:59", "airline": "南方航空", "flightCount": 8},
            {"timeSlot": "22:00 - 23:59", "airline": "中国国航", "flightCount": 5}
        ],
        "flightRouteDensityStatsVOList": [ 
            {"route": "重庆 -> 上海", "depCity": "重庆", "arrCity": "上海", "flightDensityDaily": 6.43, "airlineCount": 15, "totalFlights": 45, "coveredDays": 7},
            {"route": "上海 -> 西安", "depCity": "上海", "arrCity": "西安", "flightDensityDaily": 6.43, "airlineCount": 14, "totalFlights": 45, "coveredDays": 7},
            {"route": "上海 -> 成都", "depCity": "上海", "arrCity": "成都", "flightDensityDaily": 6.43, "airlineCount": 13, "totalFlights": 45, "coveredDays": 7},
            {"route": "昆明 -> 成都", "depCity": "昆明", "arrCity": "成都", "flightDensityDaily": 6.43, "airlineCount": 11, "totalFlights": 45, "coveredDays": 7},
            {"route": "北京 -> 重庆", "depCity": "北京", "arrCity": "重庆", "flightDensityDaily": 6.43, "airlineCount": 11, "totalFlights": 45, "coveredDays": 7},
            {"route": "大连 -> 上海", "depCity": "大连", "arrCity": "上海", "flightDensityDaily": 6.43, "airlineCount": 11, "totalFlights": 45, "coveredDays": 7},
            {"route": "成都 -> 昆明", "depCity": "成都", "arrCity": "昆明", "flightDensityDaily": 6.43, "airlineCount": 11, "totalFlights": 45, "coveredDays": 7},
            {"route": "北京 -> 上海", "depCity": "北京", "arrCity": "上海", "flightDensityDaily": 9.29, "airlineCount": 10, "totalFlights": 65, "coveredDays": 7},
            {"route": "广州 -> 上海", "depCity": "广州", "arrCity": "上海", "flightDensityDaily": 8.57, "airlineCount": 10, "totalFlights": 60, "coveredDays": 7},
            {"route": "深圳 -> 上海", "depCity": "深圳", "arrCity": "上海", "flightDensityDaily": 7.86, "airlineCount": 9, "totalFlights": 55, "coveredDays": 7}
        ]
    };
}

// 获取地理指标数据
function fetchGeoData() {
    fetch('http://localhost:8080/geo')
        .then(response => {
            if (!response.ok) {
                throw new Error('网络响应不正常');
            }
            return response.json();
        })
        .then(data => {
            console.log('地理指标数据:', data);
            renderGeoCharts(data);
        })
        .catch(error => {
            console.error('获取地理指标数据出错:', error);
            const mockData = getMockGeoData();
            renderGeoCharts(mockData);
        });
}

// 渲染地理指标图表
function renderGeoCharts(data) {
    // 提取数据
    const departureStats = data.departureStats || [];
    const landingStats = data.landingStats || [];
    const routeStats = data.routeStats || [];
    
    // 渲染各个图表
    renderGeoCityMapChart(data);
    renderGeoDepartureChart(departureStats);
    renderGeoLandingChart(landingStats);
    renderGeoRouteChart(routeStats);
}

// 渲染城市航班分布地图
function renderGeoCityMapChart(data) {
    const chartDom = document.getElementById('geo-city-map-chart');
    const chart = echarts.init(chartDom);
    geoCharts.cityMap = chart;
    
    // 加载中国地图
    chart.showLoading();
    registerMap(chart, function() {
        continueRenderMap();
    });
    
    function continueRenderMap() {
        // 准备地图数据
        const departureData = {};
        const arrivalData = {};
        
        // 处理出发数据
        if (data.departureStats && data.departureStats.length > 0) {
            data.departureStats.forEach(item => {
                const cityName = item.airportName.replace(/机场$/, '');
                departureData[cityName] = (departureData[cityName] || 0) + item.flightCount;
            });
        }
        
        // 处理到达数据
        if (data.landingStats && data.landingStats.length > 0) {
            data.landingStats.forEach(item => {
                const cityName = item.airportName.replace(/机场$/, '');
                arrivalData[cityName] = (arrivalData[cityName] || 0) + item.flightCount;
            });
        }
        
        // 合并城市数据
        const cities = new Set([...Object.keys(departureData), ...Object.keys(arrivalData)]);
        const mapData = [];
        
        // 城市坐标映射
        const cityCoordinates = {
            '北京': [116.405285, 39.904989],
            '上海': [121.472644, 31.231706],
            '广州': [113.280637, 23.125178],
            '深圳': [114.085947, 22.547],
            '成都': [104.065735, 30.659462],
            '杭州': [120.153576, 30.287459],
            '武汉': [114.298572, 30.584355],
            '西安': [108.948024, 34.263161],
            '重庆': [106.504962, 29.533155],
            '南京': [118.767413, 32.041544],
            '长沙': [112.982279, 28.19409],
            '昆明': [102.712251, 25.040609],
            '大连': [121.618622, 38.91459],
            '天津': [117.190182, 39.125596],
            '青岛': [120.355173, 36.082982],
            '沈阳': [123.429096, 41.796767],
            '厦门': [118.11022, 24.490474],
            '郑州': [113.665412, 34.757975],
            '济南': [117.000923, 36.675807],
            '福州': [119.306239, 26.075302],
            '长春': [125.3245, 43.886841],
            '哈尔滨': [126.642464, 45.756967],
            '南宁': [108.320004, 22.82402],
            '贵阳': [106.713478, 26.578343],
            '合肥': [117.283042, 31.86119],
            '石家庄': [114.502461, 38.045474],
            '太原': [112.549248, 37.857014],
            '南昌': [115.892151, 28.676493],
            '呼和浩特': [111.670801, 40.818311],
            '兰州': [103.823557, 36.058039]
        };
        
        // 生成地图数据
        cities.forEach(city => {
            if (cityCoordinates[city]) {
                const depCount = departureData[city] || 0;
                const arrCount = arrivalData[city] || 0;
                const totalCount = depCount + arrCount;
                
                if (totalCount > 0) {
                    mapData.push({
                        name: city,
                        value: [...cityCoordinates[city], totalCount],
                        depCount: depCount,
                        arrCount: arrCount
                    });
                }
            }
        });
        
        // 添加航线数据
        const linesData = [];
        if (data.routeStats && data.routeStats.length > 0) {
            data.routeStats.forEach(route => {
                const fromCity = route.depCity;
                const toCity = route.arrCity;
                
                if (cityCoordinates[fromCity] && cityCoordinates[toCity]) {
                    linesData.push({
                        coords: [cityCoordinates[fromCity], cityCoordinates[toCity]],
                        value: route.flightCount
                    });
                }
            });
        }
        
        const option = {
            tooltip: {
                trigger: 'item',
                formatter: function(params) {
                    if (params.seriesType === 'scatter') {
                        const data = params.data;
                        return `${data.name}<br/>总航班量: ${data.value[2]}<br/>出发: ${data.depCount}<br/>到达: ${data.arrCount}`;
                    } else if (params.seriesType === 'lines') {
                        return `${params.data.fromName} → ${params.data.toName}<br/>航班数: ${params.value}`;
                    }
                    return params.name;
                }
            },
            legend: {
                data: ['航班数量', '航线'],
                orient: 'horizontal',
                bottom: 10,
                textStyle: {
                    color: '#333'
                }
            },
            visualMap: {
                min: 0,
                max: Math.max(...mapData.map(item => item.value[2])),
                calculable: true,
                inRange: {
                    color: ['#50a3ba', '#eac736', '#d94e5d']
                },
                textStyle: {
                    color: '#333'
                },
                left: 'right',
                top: 'bottom',
                text: ['高航班量', '低航班量'],
                dimension: 2
            },
            geo: {
                map: 'china',
                roam: true,
                zoom: 1.2,
                center: [104.0, 37.5],
                label: {
                    show: true,
                    fontSize: 10,
                    color: '#333'
                },
                itemStyle: {
                    areaColor: '#f3f3f3',
                    borderColor: '#ddd',
                    borderWidth: 1
                },
                emphasis: {
                    label: {
                        show: true,
                        fontSize: 12,
                        fontWeight: 'bold'
                    },
                    itemStyle: {
                        areaColor: '#e6f7ff'
                    }
                }
            },
            series: [
                {
                    name: '航班数量',
                    type: 'scatter',
                    coordinateSystem: 'geo',
                    data: mapData,
                    symbolSize: function(val) {
                        return Math.min(Math.max(val[2] / 20, 8), 30);
                    },
                    encode: {
                        value: 2
                    },
                    itemStyle: {
                        color: function(params) {
                            const value = params.data.value[2];
                            if (value > 800) return '#d94e5d';
                            if (value > 400) return '#eac736';
                            return '#50a3ba';
                        },
                        shadowBlur: 10,
                        shadowColor: 'rgba(0, 0, 0, 0.3)'
                    },
                    tooltip: {
                        formatter: function(params) {
                            const data = params.data;
                            return `${data.name}<br/>总航班量: <b>${data.value[2]}</b><br/>出发航班: ${data.depCount}<br/>到达航班: ${data.arrCount}`;
                        }
                    },
                    label: {
                        formatter: '{b}',
                        position: 'right',
                        show: false
                    },
                    emphasis: {
                        label: {
                            show: true,
                            formatter: function(params) {
                                return params.name + '\n' + params.data.value[2] + '架次';
                            },
                            backgroundColor: 'rgba(255,255,255,0.8)',
                            padding: [4, 8],
                            borderRadius: 4
                        },
                        itemStyle: {
                            shadowBlur: 20,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    }
                },
                {
                    name: '航线',
                    type: 'lines',
                    coordinateSystem: 'geo',
                    zlevel: 1,
                    effect: {
                        show: true,
                        period: 6,
                        trailLength: 0.7,
                        color: '#fff',
                        symbolSize: 3
                    },
                    lineStyle: {
                        color: '#a6c84c',
                        width: 1,
                        opacity: 0.6,
                        curveness: 0.2
                    },
                    data: linesData.map(item => ({
                        coords: item.coords,
                        value: item.value,
                        fromName: data.routeStats.find(route => 
                            route.depCity === item.coords[0][0] && 
                            route.arrCity === item.coords[1][0]
                        )?.depCity || '',
                        toName: data.routeStats.find(route => 
                            route.depCity === item.coords[0][0] && 
                            route.arrCity === item.coords[1][0]
                        )?.arrCity || ''
                    }))
                }
            ]
        };
        
        chart.hideLoading();
        chart.setOption(option);
    }
}

// 渲染出发机场航班量图表
function renderGeoDepartureChart(data) {
    const chartDom = document.getElementById('geo-departure-chart');
    const chart = echarts.init(chartDom);
    geoCharts.departure = chart;
    
    // 排序数据
    data.sort((a, b) => b.flightCount - a.flightCount);
    // 只取前5个机场
    const topData = data.slice(0, 5);
    
    const option = {
        tooltip: {
            trigger: 'item',
            formatter: '{b}: {c}架次'
        },
        series: [{
            type: 'pie',
            radius: '70%',
            center: ['50%', '50%'],
            data: topData.map(item => ({
                name: item.airportName,
                value: item.flightCount
            })),
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            },
            label: {
                formatter: '{b}: {c}架次'
            },
            itemStyle: {
                color: function(params) {
                    const colorList = ['#5470c6', '#91cc75', '#fac858', '#ee6666', '#73c0de'];
                    return colorList[params.dataIndex % colorList.length];
                }
            }
        }]
    };
    
    chart.setOption(option);
}

// 渲染到达机场航班量图表
function renderGeoLandingChart(data) {
    const chartDom = document.getElementById('geo-landing-chart');
    const chart = echarts.init(chartDom);
    geoCharts.landing = chart;
    
    // 排序数据
    data.sort((a, b) => b.flightCount - a.flightCount);
    // 只取前5个机场
    const topData = data.slice(0, 5);
    
    const option = {
        tooltip: {
            trigger: 'item',
            formatter: '{b}: {c}架次'
        },
        series: [{
            type: 'pie',
            radius: '70%',
            center: ['50%', '50%'],
            data: topData.map(item => ({
                name: item.airportName,
                value: item.flightCount
            })),
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            },
            label: {
                formatter: '{b}: {c}架次'
            },
            itemStyle: {
                color: function(params) {
                    const colorList = ['#5470c6', '#91cc75', '#fac858', '#ee6666', '#73c0de'];
                    return colorList[params.dataIndex % colorList.length];
                }
            }
        }]
    };
    
    chart.setOption(option);
}

// 渲染热门航线图表
function renderGeoRouteChart(data) {
    const chartDom = document.getElementById('geo-route-chart');
    const chart = echarts.init(chartDom);
    geoCharts.route = chart;
    
    // 排序数据
    data.sort((a, b) => b.flightCount - a.flightCount);
    
    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: '{b}: {c}架次'
        },
        xAxis: {
            type: 'category',
            data: data.map(item => `${item.depCity} → ${item.arrCity}`),
            axisLabel: {
                interval: 0,
                rotate: 30
            }
        },
        yAxis: {
            type: 'value',
            name: '航班数量'
        },
        series: [{
            data: data.map(item => item.flightCount),
            type: 'bar',
            barWidth: '40%',
            itemStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                    { offset: 0, color: '#ff9a00' },
                    { offset: 1, color: '#ff6a00' }
                ])
            },
            label: {
                show: true,
                position: 'top',
                formatter: '{c}架次'
            }
        }]
    };
    
    chart.setOption(option);
}

// 渲染业务指标图表
function renderCoreCharts(data) {
    // 提取数据
    const delayData = data.delayVO;
    const prateData = data.prateVO;
    
    // 按类型分组延迟数据
    const airlineDelayData = delayData.filter(item => item.type === 1);
    const airportDelayData = delayData.filter(item => item.type === 2);
    const routeDelayData = delayData.filter(item => item.type === 3);
    
    // 渲染各个图表
    renderAirlineDelayChart(airlineDelayData);
    renderAirportDelayChart(airportDelayData);
    renderRouteDelayChart(routeDelayData);
    renderPunctualityChart(prateData);
}

// 渲染市场指标图表
function renderMarketCharts(data) {
    // 提取数据
    const airlineCountData = data.airlineCountVO;
    const cityCountData = data.cityCountVO;
    const airportCountData = data.airportCountVO;
    const top5Data = data.top5VO;
    const posCountData = data.posCountVO;
    
    // 渲染各个图表
    renderAirlineCountChart(airlineCountData);
    renderCityCountChart(cityCountData);
    renderAirportCountChart(airportCountData);
    renderCoverageChart(top5Data);
    renderCityMapChart(posCountData);
}

// 航司平均延迟时间图表
function renderAirlineDelayChart(data) {
    const chartDom = document.getElementById('airline-delay-chart');
    const chart = echarts.init(chartDom);
    coreCharts.airlineDelay = chart;
    
    // 排序数据以确保最高延迟在前
    data.sort((a, b) => parseFloat(b.avgDelay) - parseFloat(a.avgDelay));
    
    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: '{b}: {c}分钟'
        },
        xAxis: {
            type: 'category',
            data: data.map(item => item.name),
            axisLabel: {
                interval: 0,
                rotate: 30
            }
        },
        yAxis: {
            type: 'value',
            name: '平均延迟时间(分钟)'
        },
        series: [{
            data: data.map(item => parseFloat(item.avgDelay)),
            type: 'bar',
            itemStyle: {
                color: function(params) {
                    // 最高延迟为红色，最低为绿色
                    return params.dataIndex === 0 ? '#ff6b6b' : '#4ecdc4';
                }
            },
            label: {
                show: true,
                position: 'top',
                formatter: '{c}分钟'
            }
        }]
    };
    
    chart.setOption(option);
}

// 机场平均延迟时间图表
function renderAirportDelayChart(data) {
    const chartDom = document.getElementById('airport-delay-chart');
    const chart = echarts.init(chartDom);
    coreCharts.airportDelay = chart;
    
    // 排序数据以确保最高延迟在前
    data.sort((a, b) => parseFloat(b.avgDelay) - parseFloat(a.avgDelay));
    
    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: '{b}: {c}分钟'
        },
        xAxis: {
            type: 'category',
            data: data.map(item => item.name),
            axisLabel: {
                interval: 0,
                rotate: 30
            }
        },
        yAxis: {
            type: 'value',
            name: '平均延迟时间(分钟)'
        },
        series: [{
            data: data.map(item => parseFloat(item.avgDelay)),
            type: 'bar',
            itemStyle: {
                color: function(params) {
                    return params.dataIndex === 0 ? '#ff6b6b' : '#4ecdc4';
                }
            },
            label: {
                show: true,
                position: 'top',
                formatter: '{c}分钟'
            }
        }]
    };
    
    chart.setOption(option);
}

// 航线平均延迟时间图表
function renderRouteDelayChart(data) {
    const chartDom = document.getElementById('route-delay-chart');
    const chart = echarts.init(chartDom);
    coreCharts.routeDelay = chart;
    
    // 排序
    data.sort((a, b) => parseFloat(b.avgDelay) - parseFloat(a.avgDelay));
    
    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: '{b}: {c}分钟'
        },
        xAxis: {
            type: 'category',
            data: data.map(item => item.name),
            axisLabel: {
                interval: 0,
                rotate: 30
            }
        },
        yAxis: {
            type: 'value',
            name: '平均延迟时间(分钟)'
        },
        series: [{
            data: data.map(item => parseFloat(item.avgDelay)),
            type: 'bar',
            itemStyle: {
                color: function(params) {
                    return params.dataIndex === 0 ? '#ff6b6b' : '#4ecdc4';
                }
            },
            label: {
                show: true,
                position: 'top',
                formatter: '{c}分钟'
            }
        }]
    };
    
    chart.setOption(option);
}

// 航班准点率排名图表
function renderPunctualityChart(data) {
    const chartDom = document.getElementById('punctuality-chart');
    const chart = echarts.init(chartDom);
    coreCharts.punctuality = chart;
    
    // 排序
    data.sort((a, b) => parseFloat(b.punctuality) - parseFloat(a.punctuality));
    
    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: '{b}: {c}%'
        },
        xAxis: {
            type: 'category',
            data: data.map(item => item.name),
            axisLabel: {
                interval: 0,
                rotate: 30
            }
        },
        yAxis: {
            type: 'value',
            name: '准点率(%)',
            min: 0,
            max: 100
        },
        series: [{
            data: data.map(item => parseFloat(item.punctuality)),
            type: 'bar',
            barWidth: '40%',
            itemStyle: {
                color: function(params) {
                    const colorList = ['#4ecdc4', '#52b788', '#76c893', '#99d98c', '#b5e48c'];
                    return colorList[params.dataIndex] || '#b5e48c';
                }
            },
            label: {
                show: true,
                position: 'top',
                formatter: '{c}%'
            }
        }]
    };
    
    chart.setOption(option);
}

// 航司航班数量图表
function renderAirlineCountChart(data) {
    const chartDom = document.getElementById('airline-count-chart');
    const chart = echarts.init(chartDom);
    marketCharts.airlineCount = chart;
    
    // 排序
    data.sort((a, b) => b.count - a.count);
    
    const option = {
        tooltip: {
            trigger: 'item',
            formatter: '{b}: {c}架次'
        },
        series: [{
            type: 'pie',
            radius: '70%',
            center: ['50%', '50%'],
            data: data.map(item => ({
                name: item.airlineName,
                value: item.count
            })),
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            },
            label: {
                formatter: '{b}: {c}架次'
            }
        }]
    };
    
    chart.setOption(option);
}

// 城市航班数量图表
function renderCityCountChart(data) {
    const chartDom = document.getElementById('city-count-chart');
    const chart = echarts.init(chartDom);
    marketCharts.cityCount = chart;
    
    // 排序
    data.sort((a, b) => b.count - a.count);
    // 只取前6个城市
    const topData = data.slice(0, 6);
    
    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: '{b}: {c}架次'
        },
        xAxis: {
            type: 'category',
            data: topData.map(item => item.cityName),
            axisLabel: {
                interval: 0,
                rotate: 30
            }
        },
        yAxis: {
            type: 'value',
            name: '航班数量'
        },
        series: [{
            data: topData.map(item => item.count),
            type: 'bar',
            barWidth: '40%',
            itemStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                    { offset: 0, color: '#83a4d4' },
                    { offset: 1, color: '#b6fbff' }
                ])
            },
            label: {
                show: true,
                position: 'top',
                formatter: '{c}架次'
            }
        }]
    };
    
    chart.setOption(option);
}

// 机场航班数量图表
function renderAirportCountChart(data) {
    const chartDom = document.getElementById('airport-count-chart');
    const chart = echarts.init(chartDom);
    marketCharts.airportCount = chart;
    
    // 排序
    data.sort((a, b) => parseInt(b.count) - parseInt(a.count));
    // 只取前6个机场
    const topData = data.slice(0, 6);
    
    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: '{b}: {c}架次'
        },
        xAxis: {
            type: 'category',
            data: topData.map(item => item.airportName),
            axisLabel: {
                interval: 0,
                rotate: 30
            }
        },
        yAxis: {
            type: 'value',
            name: '航班数量'
        },
        series: [{
            data: topData.map(item => parseInt(item.count)),
            type: 'bar',
            barWidth: '40%',
            itemStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                    { offset: 0, color: '#5ee7df' },
                    { offset: 1, color: '#b490ca' }
                ])
            },
            label: {
                show: true,
                position: 'top',
                formatter: '{c}架次'
            }
        }]
    };
    
    chart.setOption(option);
}

// 航司覆盖率TOP5图表
function renderCoverageChart(data) {
    const chartDom = document.getElementById('coverage-chart');
    const chart = echarts.init(chartDom);
    marketCharts.coverage = chart;
    
    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: '{b}: {c}%'
        },
        xAxis: {
            type: 'value',
            name: '覆盖率(%)',
            max: 50
        },
        yAxis: {
            type: 'category',
            data: data.map(item => item.airline).reverse(),
            axisLabel: {
                interval: 0
            }
        },
        series: [{
            data: data.map(item => parseFloat(item.coverage_rate)).reverse(),
            type: 'bar',
            barWidth: '60%',
            itemStyle: {
                color: function(params) {
                    const colorList = ['#ff9a00', '#ff9a3c', '#ffa361', '#ffad86', '#ffb8a8'];
                    return colorList[params.dataIndex] || '#ffb8a8';
                }
            },
            label: {
                show: true,
                position: 'right',
                formatter: '{c}%'
            }
        }]
    };
    
    chart.setOption(option);
}

// 城市航班分布地图
function renderCityMapChart(data) {
    const chartDom = document.getElementById('city-map-chart');
    const chart = echarts.init(chartDom);
    marketCharts.cityMap = chart;
    
    // 加载中国地图
    chart.showLoading();
    registerMap(chart, function() {
        continueRenderMap();
    });
    
    function continueRenderMap() {

    const mapData = data.map(item => ({
        name: item.city,
        value: [item.lng, item.lat, item.depCount + item.arrCount],
        depCount: item.depCount,
        arrCount: item.arrCount
    }));
    
    const option = {
        tooltip: {
            trigger: 'item',
            formatter: function(params) {
                const data = params.data;
                return `${data.name}<br/>总航班量: ${data.value[2]}<br/>出发: ${data.depCount}<br/>到达: ${data.arrCount}`;
            }
        },
        visualMap: {
            min: 0,
            max: Math.max(...mapData.map(item => item.value[2])),
            calculable: true,
            inRange: {
                color: ['#50a3ba', '#eac736', '#d94e5d']
            },
            textStyle: {
                color: '#333'
            },
            left: 'right',
            top: 'bottom',
            text: ['高航班量', '低航班量'],
            dimension: 2
        },
        legend: {
            data: ['航班数量', '航线'],
            orient: 'horizontal',
            bottom: 10,
            textStyle: {
                color: '#333'
            }
        },
        geo: {
            map: 'china',
            roam: true,
            zoom: 1.2, 
            center: [104.0, 37.5], 
            label: {
                show: true,  
                fontSize: 10,
                color: '#333'
            },
            itemStyle: {
                areaColor: '#f3f3f3',
                borderColor: '#ddd',
                borderWidth: 1
            },
            emphasis: {
                label: {
                    show: true,
                    fontSize: 12,
                    fontWeight: 'bold'
                },
                itemStyle: {
                    areaColor: '#e6f7ff'
                }
            }
        },
        series: [{
            name: '航班数量',
            type: 'scatter',
            coordinateSystem: 'geo',
            data: mapData,
            symbolSize: function(val) {
                return Math.min(Math.max(val[2] / 2, 15), 45);
            },
            encode: {
                value: 2
            },
            itemStyle: {
                    color: function(params) {
                        const value = params.data.value[2];
                        if (value > 800) return '#d94e5d';
                        if (value > 400) return '#eac736';
                        return '#50a3ba';
                    },
                    shadowBlur: 10,
                    shadowColor: 'rgba(0, 0, 0, 0.3)'
                },
                tooltip: {
                    formatter: function(params) {
                        const data = params.data;
                        return `${data.name}<br/>总航班量: <b>${data.value[2]}</b><br/>出发航班: ${data.depCount}<br/>到达航班: ${data.arrCount}`;
                    }
                },
            label: {
                formatter: '{b}',
                position: 'right',
                show: true,
                color: '#333',
                fontWeight: 'bold'
            },
            emphasis: {
                label: {
                    show: true,
                    formatter: function(params) {
                        return params.name + '\n' + params.data.value[2] + '架次';
                    },
                    backgroundColor: 'rgba(255,255,255,0.8)',
                    padding: [4, 8],
                    borderRadius: 4
                },
                itemStyle: {
                    shadowBlur: 20,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            }
        }]
    };
    
    chart.hideLoading();
    chart.setOption(option);
    }
}

// 注册中国地图
function registerMap(chart, callback) {
    if (!echarts.getMap('china')) {
        console.log('正在加载中国地图数据...');
        $.get('https://geo.datav.aliyun.com/areas_v3/bound/100000_full.json', function(chinaJson) {
            console.log('中国地图数据加载成功');
            echarts.registerMap('china', chinaJson);
            if (callback) callback();
        });
    } else {
        console.log('中国地图数据已成功加载');
        if (callback) callback();
    }
}

// 调整所有图表大小
function resizeAllCharts() {
    const activeSection = document.querySelector('.content-section.active');
    if (activeSection.id === 'core-content') {
        Object.values(coreCharts).forEach(chart => {
            if (chart && typeof chart.resize === 'function') {
                chart.resize();
            }
        });
    } else if (activeSection.id === 'market-content') {
        Object.values(marketCharts).forEach(chart => {
            if (chart && typeof chart.resize === 'function') {
                chart.resize();
            }
        });
    } else if (activeSection.id === 'time-content') {
        Object.values(timeCharts).forEach(chart => {
            if (chart && typeof chart.resize === 'function') {
                chart.resize();
            }
        });
    } else if (activeSection.id === 'geo-content') {
        Object.values(geoCharts).forEach(chart => {
            if (chart && typeof chart.resize === 'function') {
                chart.resize();
            }
        });
    }
}

// 获取地理指标模拟数据
function getMockGeoData() {
    return {
        "departureStats": [
            {
                "airportName": "首都机场",
                "flightCount": 954
            },
            {
                "airportName": "江北机场",
                "flightCount": 680
            },
            {
                "airportName": "白云机场",
                "flightCount": 678
            },
            {
                "airportName": "长水机场",
                "flightCount": 672
            },
            {
                "airportName": "双流机场",
                "flightCount": 639
            }
        ],
        "landingStats":[
            {
                "airportName": "首都机场",
                "flightCount": 881
            },
            {
                "airportName": "白云机场",
                "flightCount": 695
            },
            {
                "airportName": "江北机场",
                "flightCount": 635
            },
            {
                "airportName": "双流机场",
                "flightCount": 627
            },
            {
                "airportName": "宝安机场",
                "flightCount": 620
            }
        ],
        "routeStats":[
            {
                "depCity": "成都",
                "arrCity": "昆明",
                "flightCount": 45
            },
            {
                "depCity": "上海",
                "arrCity": "成都",
                "flightCount": 45
            },
            {
                "depCity": "重庆",
                "arrCity": "北京",
                "flightCount": 45
            },
            {
                "depCity": "重庆",
                "arrCity": "上海",
                "flightCount": 45
            },
            {
                "depCity": "北京",
                "arrCity": "重庆",
                "flightCount": 45
            },
            {
                "depCity": "大连",
                "arrCity": "上海",
                "flightCount": 45
            },
            {
                "depCity": "昆明",
                "arrCity": "成都",
                "flightCount": 45
            }
        ]
    };
}