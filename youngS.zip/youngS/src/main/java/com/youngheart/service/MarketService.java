package com.youngheart.service;

import com.youngheart.domain.vo.market.MarketResult;

public interface MarketService {
    MarketResult getMarketResult();
}
