document.addEventListener('DOMContentLoaded', function() {
    const playButton = document.getElementById('play-button');
    const prevButton = document.getElementById('prev-button');
    const nextButton = document.getElementById('next-button');
    const recordCover = document.querySelector('.record-cover');
    const songTitle = document.getElementById('song-title');
    const volumeSlider = document.getElementById('volume-slider');
    const progressSlider = document.getElementById('progress-slider');
    const currentTimeDisplay = document.getElementById('current-time');
    const durationDisplay = document.getElementById('duration');
    let isPlaying = false;
    let audio = null;
    let currentSongIndex = 0;
    let isSeeking = false;
    
    // 歌曲列表 - 与media文件夹中的歌曲对应
    const songs = [
        { title: 'Educated Feet', src: 'tmpleates/media/Educated Feet.mp3', cover: 'tmpleates/image/fm/fm.png' },
        { title: '感官先生', src: 'tmpleates/media/感官先生.mp3', cover: 'tmpleates/image/fm/fm1.png' },
        { title: '独上c楼', src: 'tmpleates/media/独上c楼.mp3', cover: 'tmpleates/image/fm/fm2.png' },
        { title: '边缘行者', src: 'tmpleates/media/边缘行者.mp3', cover: 'tmpleates/image/fm/fm3.png'}
    ];

    // 创建音频元素
    function createAudioElement(src) {
        if (audio) {
            audio.pause();
            audio.remove();
        }
        audio = new Audio(src);
        audio.load();
        
        // 音频播放结束时自动播放下一首
        audio.addEventListener('ended', playNextSong);
        audio.addEventListener('timeupdate', updateProgress);
        audio.addEventListener('loadedmetadata', updateDuration);
    }
    
    // 更新歌曲标题显示
    function updateSongTitle() {
        if (songTitle) {
            // 添加过渡动画
            songTitle.classList.add('song-transition');
            recordCover.classList.add('song-transition');
            
            // 更新标题和封面
            songTitle.textContent = songs[currentSongIndex].title;
            recordCover.src = songs[currentSongIndex].cover;
            
            // 动画结束后移除类
            setTimeout(() => {
                songTitle.classList.remove('song-transition');
                recordCover.classList.remove('song-transition');
            }, 500);
        }
    }
    
    // 播放指定索引的歌曲
    function playSong(index) {
        if (progressSlider) progressSlider.value = 0;
        if (currentTimeDisplay) currentTimeDisplay.textContent = '00:00';
        if (durationDisplay) durationDisplay.textContent = '00:00';
        currentSongIndex = index;
        const song = songs[currentSongIndex];
        createAudioElement(song.src);
        updateSongTitle();
        
        if (isPlaying) {
            audio.play();
        }
    }
    
    // 播放上一首
    function playPrevSong() {
        currentSongIndex = (currentSongIndex - 1 + songs.length) % songs.length;
        playSong(currentSongIndex);
    }
    
    // 播放下一首
    function playNextSong() {
        currentSongIndex = (currentSongIndex + 1) % songs.length;
        playSong(currentSongIndex);
    }

    // 切换播放/暂停状态
    // 格式化时间显示
    function formatTime(seconds) {
        if (isNaN(seconds)) return '00:00';
        const minutes = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }

    // 更新进度条
    function updateProgress() {
        if (audio && !isSeeking) {
            const percent = (audio.currentTime / audio.duration) * 100;
            progressSlider.value = percent;
            currentTimeDisplay.textContent = formatTime(audio.currentTime);
        }
    }

    // 更新总时长
    function updateDuration() {
        if (audio) {
            durationDisplay.textContent = formatTime(audio.duration);
        }
    }

    function togglePlayback() {
        if (!audio) {
            createAudioElement();
            updateSongTitle();
        }

        if (isPlaying) {
            audio.pause();
            recordCover.classList.remove('rotating');
            playButton.innerHTML = '<i class="ri-play-fill"></i> 播放';
        } else {
            audio.play();
            recordCover.classList.add('rotating');
            playButton.innerHTML = '<i class="ri-pause-fill"></i> 暂停';
        }
        isPlaying = !isPlaying;
    }

    // 音量控制
    if (volumeSlider) {
        volumeSlider.addEventListener('input', function() {
            if (audio) {
                audio.volume = this.value;
            }
        });
    }

    // 进度条控制
    if (progressSlider) {
        progressSlider.addEventListener('mousedown', function() {
            isSeeking = true;
        });

        progressSlider.addEventListener('input', function() {
            if (audio && isSeeking) {
                const seekTime = audio.duration * (this.value / 100);
                currentTimeDisplay.textContent = formatTime(seekTime);
            }
        });

        progressSlider.addEventListener('mouseup', function() {
            if (audio) {
                const seekTime = audio.duration * (this.value / 100);
                audio.currentTime = seekTime;
                isSeeking = false;
            }
        });
    }

    // 添加按钮点击事件监听
    if (playButton) {
        playButton.addEventListener('click', togglePlayback);
    }
    
    if (prevButton) {
        prevButton.addEventListener('click', function() {
            // 添加按钮点击效果
            this.classList.add('button-active');
            setTimeout(() => this.classList.remove('button-active'), 200);
            playPrevSong();
        });
    }
    
    if (nextButton) {
        nextButton.addEventListener('click', function() {
            // 添加按钮点击效果
            this.classList.add('button-active');
            setTimeout(() => this.classList.remove('button-active'), 200);
            playNextSong();
        });
    }

    // 页面切换时停止播放
    const tabLinks = document.querySelectorAll('.tab-link');
    tabLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (isPlaying) {
                togglePlayback();
            }
        });
    });
    
    // 初始化播放第一首歌
    createAudioElement(songs[currentSongIndex].src);
    updateSongTitle();
});