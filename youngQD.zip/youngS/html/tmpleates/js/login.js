// 获取DOM元素
const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');
const loginBtn = document.getElementById('loginBtn');
const regBtn = document.getElementById('regBtn');
const errorMsg = document.getElementById('errorMsg');
const successMsg = document.getElementById('successMsg');

// 隐藏提示信息
function hideMessages() {
    errorMsg.style.display = 'none';
    successMsg.style.display = 'none';
}

// 显示错误信息
function showError(message) {
    errorMsg.textContent = message;
    errorMsg.style.display = 'block';
    successMsg.style.display = 'none';
}

// 显示成功信息
function showSuccess(message) {
    successMsg.textContent = message;
    successMsg.style.display = 'block';
    errorMsg.style.display = 'none';
}

// 获取表单数据
function getFormData() {
    return {
        username: usernameInput.value.trim(),
        password: passwordInput.value.trim()
    };
}

// 登录处理
loginBtn.addEventListener('click', async () => {
    hideMessages();
    const data = getFormData();

    // 简单验证
    if (!data.username || !data.password) {
        showError('用户名和密码不能为空');
        return;
    }

    try {
        const response = await fetch('http://localhost:8080/login/log', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        // 处理响应
        if (result && result.status === 1 && result.jwt) {
            // 存储jwt到localStorage
            localStorage.setItem('jwt', result.jwt);
            localStorage.setItem('username', data.username);
            showSuccess('登录成功，正在跳转...');
            
            // 登录成功后延迟片刻跳转（让用户看到成功提示）
            setTimeout(() => {
                window.location.href = 'core.html'; // 跳转到core.html
            }, 1000); // 1秒后跳转
        } else {
            showError('用户名或密码错误');
        }
    } catch (error) {
        console.error('登录请求失败:', error);
        showError('登录失败，请稍后重试');
    }
});

// 注册处理
regBtn.addEventListener('click', async () => {
    hideMessages();
    const data = getFormData();

    // 简单验证
    if (!data.username || !data.password) {
        showError('用户名和密码不能为空');
        return;
    }

    try {
        const response = await fetch('http://localhost:8080/login/reg', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.text();

        // 处理响应
        if (result === '注册成功') {
            showSuccess('注册成功，请登录');
            // 清空密码框
            passwordInput.value = '';
        } else {
            showError('注册失败: ' + result);
        }
    } catch (error) {
        console.error('注册请求失败:', error);
        showError('注册失败，请稍后重试');
    }
});