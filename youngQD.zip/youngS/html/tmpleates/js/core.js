document.addEventListener('DOMContentLoaded', function() {
    // 显示用户名和注销功能
    const usernameDisplay = document.getElementById('username-display');
    const logoutBtn = document.getElementById('logout-btn');
    const storedUsername = localStorage.getItem('username');
    
    if (storedUsername) {
        usernameDisplay.textContent = storedUsername;
    }
    
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            localStorage.removeItem('jwt');
            localStorage.removeItem('username');
            window.location.href = 'login.html';
        });
    }
    // 初始化标签切换
    initTabSwitching();
    fetchCoreData();
    fetchMileageRangeData(); // 页面首次加载时也获取里程区间数据
    fetchAircraftMileageData(); // 页面首次加载时也获取机型里程数据
    fetchAirlineLocationData(); // 页面首次加载时也获取航司辐射区域数据
    
    // 添加防抖的resize处理
    let resizeTimer;
    window.addEventListener('resize', function() {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(function() {
            resizeAllCharts();
        }, 300);
    });

    initAirlineSelectAndGantt();

    var flightSelect = document.getElementById('flight-select');
    if (flightSelect) {
        flightSelect.addEventListener('change', function() {
            renderSelectedFlightsGantt();
        });
    }

    var btnAll = document.getElementById('flight-select-all');
    if (btnAll && flightSelect) {
        btnAll.addEventListener('click', function() {
            for (let i = 0; i < flightSelect.options.length; i++) {
                flightSelect.options[i].selected = true;
            }
            renderSelectedFlightsGantt();
        });
    }
});

// 存储所有图表实例
const coreCharts = {};
const marketCharts = {};
const timeCharts = {};
const geoCharts = {};

// 调整所有图表大小
function resizeAllCharts() {
    for (const key in coreCharts) {
        coreCharts[key] && coreCharts[key].resize();
    }
    for (const key in marketCharts) {
        marketCharts[key] && marketCharts[key].resize();
    }
    for (const key in timeCharts) {
        timeCharts[key] && timeCharts[key].resize();
    }
    for (const key in geoCharts) {
        geoCharts[key] && geoCharts[key].resize();
    }
}

// 初始化标签切换功能
function initTabSwitching() {
    const tabLinks = document.querySelectorAll('.tab-link');
    
    tabLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            tabLinks.forEach(item => item.classList.remove('active'));
            this.classList.add('active');
            const targetId = this.getAttribute('data-tab');
            document.querySelectorAll('.content-section').forEach(section => {
                section.classList.remove('active');
            });
            document.getElementById(targetId).classList.add('active');
            
            // 延迟一点时间确保DOM渲染完成后再获取数据
            setTimeout(() => {
                if (targetId === 'core-content') {
                    fetchCoreData();
                    fetchMileageRangeData(); // 获取里程区间数据
                    fetchAircraftMileageData(); // 获取机型里程数据
                } else if (targetId === 'market-content') {
                    fetchMarketData();
                } else if (targetId === 'time-content') {
                    fetchTimeData();
                } else if (targetId === 'geo-content') {
                    fetchGeoData();
                    fetchAirlineLocationData(); // 获取航司辐射区域数据
                }
            }, 50);
            
            // 再延迟一点调整所有图表尺寸
            setTimeout(() => {
                resizeAllCharts();
            }, 200);
        });
    });
}

// 获取业务指标数据
function fetchCoreData() {
    fetch('http://localhost:8080/core', {
            headers: {
                'jwt': localStorage.getItem('jwt')
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('网络响应不正常');
            }
            return response.json();
        })
        .then(data => {
            renderCoreCharts(data);
        })
        .catch(error => {
            console.error('获取业务指标数据出错:', error);
            const mockData = getMockCoreData();
            renderCoreCharts(mockData);
        });
}

// 获取里程区间数据
function fetchMileageRangeData() {
    fetch('http://localhost:8080/core/mileage-range', {
            headers: {
                'jwt': localStorage.getItem('jwt')
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('网络响应不正常');
            }
            return response.json();
        })
        .then(data => {
            renderMileageRangeCharts(data);
        })
        .catch(error => {
            console.error('获取里程区间数据出错:', error);
            const mockData = getMockMileageRangeData();
            renderMileageRangeCharts(mockData);
        });
}

// 获取市场指标数据
function fetchMarketData() {
    fetch('http://localhost:8080/market', {
            headers: {
                'jwt': localStorage.getItem('jwt')
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('网络响应不正常');
            }
            return response.json();
        })
        .then(data => {
            renderMarketCharts(data);
        })
        .catch(error => {
            console.error('获取市场指标数据出错:', error);
            const mockData = getMockMarketData();
            renderMarketCharts(mockData);
        });
}

// 获取时间指标数据
function fetchTimeData() {
    fetch('http://localhost:8080/time', {
            headers: {
                'jwt': localStorage.getItem('jwt')
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('网络响应不正常');
            }
            return response.json();
        })
        .then(data => {
            console.log('时间指标数据:', data);
            setTimeout(() => {
                renderTimeCharts(data);
                fetchAndRenderSunburst(); // 新增：渲染旭日图
            }, 100);
        })
        .catch(error => {
            console.error('获取时间指标数据出错:', error);
            const mockData = getMockTimeData();
            renderTimeCharts(mockData);
            fetchAndRenderSunburst(); // 新增：渲染旭日图
        });
}

// 渲染里程区间图表
function renderMileageRangeCharts(data) {
    setTimeout(() => {
        renderMileageRangeFlightCountChart(data);
        renderMileageRangePunctualityChart(data);
        renderMileageRangeDelayChart(data);
    }, 100);
}

// 渲染里程区间航班数量漏斗图
function renderMileageRangeFlightCountChart(data) {
    const chartDom = document.getElementById('mileage-range-flight-count-chart');
    if (!ensureChartContainerSize(chartDom)) return;
    
    const chart = echarts.init(chartDom);
    coreCharts.mileageFlightCount = chart;

    var colors = ['#1cd389', '#668eff', '#ffc751', '#ff6e73', '#8683e6', '#9692ff'];
    
    // 准备数据
    var lineargroup = data.map((item, index) => ({
        value: item.flightCount,
        name: item.mileageRange,
        oriname: item.mileageRange,
        number: item.flightCount,
        color: colors[index % colors.length]
    }));

    var data1 = [];
    var data2 = [];

    for (var i = 0; i < lineargroup.length; i++) {
        var obj1 = {
            value: lineargroup[i].value,
            num: lineargroup[i].number,
            name: lineargroup[i].oriname
        };

        var obj2 = {
            value: lineargroup[i].value,
            name: lineargroup[i].name,
            itemStyle: {
                opacity: 0.8
            }
        };
        data1.push(obj1);
        data2.push(obj2);
    }

    const option = {
        color: colors,
        tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b}: {c} ({d}%)'
        },
        series: [{
            name: '航班数量',
            top: 0,
            type: 'funnel',
            height: '300',
            gap: 0,
            minSize: 80,
            left: '20%',
            width: '60%',
            label: {
                show: true,
                position: 'inside',
                fontSize: '12',
                formatter: function(d) {
                    return d.name + '\n' + d.data.num + '架次';
                }
            },
            data: data1
        }]
    };

    chart.setOption(option);
}

// 渲染里程区间准点率漏斗图
function renderMileageRangePunctualityChart(data) {
    const chartDom = document.getElementById('mileage-range-punctuality-chart');
    if (!ensureChartContainerSize(chartDom)) return;
    
    const chart = echarts.init(chartDom);
    coreCharts.mileagePunctuality = chart;

    var colors = ['#1cd389', '#668eff', '#ffc751', '#ff6e73', '#8683e6', '#9692ff'];
    
    // 准备数据，按准点率排序
    var sortedData = data.sort((a, b) => b.avgPunctuality - a.avgPunctuality);
    
    var lineargroup = sortedData.map((item, index) => ({
        value: Math.round(item.avgPunctuality * 100),
        name: item.mileageRange,
        oriname: item.mileageRange,
        number: (item.avgPunctuality * 100).toFixed(1),
        color: colors[index % colors.length]
    }));

    var data1 = [];
    var data2 = [];

    for (var i = 0; i < lineargroup.length; i++) {
        var obj1 = {
            value: lineargroup[i].value,
            num: lineargroup[i].number,
            name: lineargroup[i].oriname
        };

        var obj2 = {
            value: lineargroup[i].value,
            name: lineargroup[i].name,
            itemStyle: {
                opacity: 0.8
            }
        };
        data1.push(obj1);
        data2.push(obj2);
    }

    const option = {
        color: colors,
        tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b}: {c}%'
        },
        series: [{
            name: '平均准点率',
            top: 0,
            type: 'funnel',
            height: '300',
            gap: 0,
            minSize: 80,
            left: '20%',
            width: '60%',
            label: {
                show: true,
                position: 'inside',
                fontSize: '12',
                formatter: function(d) {
                    return d.name + '\n' + d.data.num + '%';
                }
            },
            data: data1
        }]
    };

    chart.setOption(option);
}

// 渲染里程区间延迟时间漏斗图
function renderMileageRangeDelayChart(data) {
    const chartDom = document.getElementById('mileage-range-delay-chart');
    if (!ensureChartContainerSize(chartDom)) return;
    
    const chart = echarts.init(chartDom);
    coreCharts.mileageDelay = chart;

    var colors = ['#1cd389', '#668eff', '#ffc751', '#ff6e73', '#8683e6', '#9692ff'];
    
    // 准备数据，按延迟时间排序
    var sortedData = data.sort((a, b) => b.avgDelay - a.avgDelay);
    
    var lineargroup = sortedData.map((item, index) => ({
        value: Math.round(item.avgDelay),
        name: item.mileageRange,
        oriname: item.mileageRange,
        number: item.avgDelay.toFixed(1),
        color: colors[index % colors.length]
    }));

    var data1 = [];
    var data2 = [];

    for (var i = 0; i < lineargroup.length; i++) {
        var obj1 = {
            value: lineargroup[i].value,
            num: lineargroup[i].number,
            name: lineargroup[i].oriname
        };

        var obj2 = {
            value: lineargroup[i].value,
            name: lineargroup[i].name,
            itemStyle: {
                opacity: 0.8
            }
        };
        data1.push(obj1);
        data2.push(obj2);
    }

    const option = {
        color: colors,
        tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b}: {c}分钟'
        },
        series: [{
            name: '平均延迟时间',
            top: 0,
            type: 'funnel',
            height: '300',
            gap: 0,
            minSize: 80,
            left: '20%',
            width: '60%',
            label: {
                show: true,
                position: 'inside',
                fontSize: '12',
                formatter: function(d) {
                    return d.name + '\n' + d.data.num + '分钟';
                }
            },
            data: data1
        }]
    };

    chart.setOption(option);
}

// 模拟里程区间数据
function getMockMileageRangeData() {
    return [
        {
            mileageRange: '0-500',
            flightCount: 996,
            avgPunctuality: 0.85,
            avgDelay: 19
        },
        {
            mileageRange: '500-1000',
            flightCount: 3404,
            avgPunctuality: 0.85,
            avgDelay: 18
        },
        {
            mileageRange: '1000-1500',
            flightCount: 4484,
            avgPunctuality: 0.84,
            avgDelay: 19
        },
        {
            mileageRange: '1500-2000',
            flightCount: 3323,
            avgPunctuality: 0.82,
            avgDelay: 20
        },
        {
            mileageRange: '2000-2500',
            flightCount: 1726,
            avgPunctuality: 0.79,
            avgDelay: 24
        },
        {
            mileageRange: '2500-3000',
            flightCount: 565,
            avgPunctuality: 0.75,
            avgDelay: 28
        },
        {
            mileageRange: '3000-3500',
            flightCount: 340,
            avgPunctuality: 0.74,
            avgDelay: 32
        },
        {
            mileageRange: '3500+',
            flightCount: 236,
            avgPunctuality: 0.66,
            avgDelay: 39
        }
    ];
}

// 渲染航班时间段分布饼图
function renderTimeSlotPieChart(data) {
    const chartDom = document.getElementById('time-slot-chart');
    if (!ensureChartContainerSize(chartDom)) return;
    
    const chart = echarts.init(chartDom);
    timeCharts.timeSlot = chart;

    // 聚合相同时间段的数据
    const timeSlotData = {};
    data.forEach(item => {
        if (!timeSlotData[item.timeSlot]) {
            timeSlotData[item.timeSlot] = 0;
        }
        timeSlotData[item.timeSlot] += item.flightCount;
    });

    // 准备饼图数据
    const pieData = Object.entries(timeSlotData).map(([name, value]) => ({
        name,
        value
    }));

    const option = {
        tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b}: {c} ({d}%)'
        },
        legend: {
            orient: 'vertical',
            left: 10,
            data: Object.keys(timeSlotData)
        },
        series: [
            {
                name: '航班数量',
                type: 'pie',
                radius: ['40%', '70%'],
                avoidLabelOverlap: false,
                itemStyle: {
                    borderRadius: 10,
                    borderColor: '#fff',
                    borderWidth: 2
                },
                label: {
                    show: false,
                    position: 'center'
                },
                emphasis: {
                    label: {
                        show: true,
                        fontSize: 16,
                        fontWeight: 'bold'
                    }
                },
                labelLine: {
                    show: false
                },
                data: pieData
            }
        ]
    };

    chart.setOption(option);
    
    // 强制resize确保正确显示
    setTimeout(() => {
        chart.resize();
    }, 100);
}

// 渲染航线竞争强度柱状图
function renderRouteCompetitionBarChart(data) {
    const chartDom = document.getElementById('route-competition-chart');
    if (!ensureChartContainerSize(chartDom)) return;
    
    console.log('航线竞争强度数据:', data);
    
    // 如果数据为空，显示提示信息
    if (!data || data.length === 0) {
        chartDom.innerHTML = '<div style="text-align:center;line-height:300px;color:#666;">暂无航线竞争强度数据</div>';
        return;
    }
    
    const chart = echarts.init(chartDom);
    marketCharts.competition = chart;

    // 提取前10条航线数据
    const topData = [...data].sort((a, b) => b.airlineCount - a.airlineCount).slice(0, 10);
    const routes = topData.map(item => item.route);
    const airlineCounts = topData.map(item => item.airlineCount);
    const flightDensity = topData.map(item => item.flightDensityDaily);

    const option = {
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'shadow'
            }
        },
        legend: {
            data: ['航空公司数量', '航班密度(每日)']
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis: {
            type: 'value',
            boundaryGap: [0, 0.01]
        },
        yAxis: {
            type: 'category',
            data: routes
        },
        series: [
            {
                name: '航空公司数量',
                type: 'bar',
                data: airlineCounts,
                itemStyle: {
                    color: '#50a3ba'
                }
            },
            {
                name: '航班密度(每日)',
                type: 'bar',
                data: flightDensity,
                itemStyle: {
                    color: '#d94e5d'
                }
            }
        ]
    };

    chart.setOption(option);
    
    // 强制resize确保正确显示
    setTimeout(() => {
        chart.resize();
    }, 100);
}

function renderAirportKnowledgeGraph(data) {
    const chartDom = document.getElementById('airport-knowledge-graph');
    if (!ensureChartContainerSize(chartDom)) return;
    
    console.log('机场知识图谱数据:', data);
    
    // 如果数据为空，显示提示信息
    if (!data || data.length === 0) {
        chartDom.innerHTML = '<div style="text-align:center;line-height:300px;color:#666;">暂无机场知识图谱数据</div>';
        return;
    }
    
    const chart = echarts.init(chartDom);
    marketCharts.knowledgeGraph = chart;

    const nodes = data.map(item => ({
        name: item.airport,
        value: item.pagerank,
        symbolSize: Math.min(50, Math.max(10, item.pagerank / 0.5))
    }));

    const links = [];
    for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < Math.min(i + 3, nodes.length); j++) {
            links.push({
                source: nodes[i].name,
                target: nodes[j].name,
                value: Math.random() * 3 + 1
            });
        }
    }

    const option = {
        title: {
            text: '机场重要性知识图谱',
            left: 'center'
        },
        tooltip: {
            formatter: '{b}: {c}'
        },
        legend: [{
            data: ['机场节点'],
            left: 'left'
        }],
        series: [{
            name: '机场节点',
            type: 'graph',
            layout: 'force',
            force: {
                repulsion: 200,
                edgeLength: 100
            },
            roam: true,
            label: {
                show: true
            },
            edgeSymbol: ['none', 'arrow'],
            edgeSymbolSize: [0, 10],
            edgeLabel: {
                fontSize: 10
            },
            data: nodes,
            links: links,
            lineStyle: {
                opacity: 0.9,
                width: 1,
                curveness: 0
            }
        }]
    };

    chart.setOption(option);
    
    // 强制resize确保正确显示
    setTimeout(() => {
        chart.resize();
    }, 100);
    
    // 再次延迟resize，确保图表完全渲染
    setTimeout(() => {
        chart.resize();
    }, 500);
}

// 生成时间指标模拟数据
function getMockTimeData() {
    return {
        "airportPagerankVOList": [
            {"airport": "首都机场", "pagerank": 6.6263577145856685},
            {"airport": "白云机场", "pagerank": 4.921869904311425},
            {"airport": "双流机场", "pagerank": 4.650052164994991},
            {"airport": "长水机场", "pagerank": 4.514393872340536},
            {"airport": "宝安机场", "pagerank": 4.490016265114064},
            {"airport": "江北机场", "pagerank": 4.465776759873335},
            {"airport": "咸阳机场", "pagerank": 3.817889621620452},
            {"airport": "浦东机场", "pagerank": 3.6499772736089393},
            {"airport": "地窝堡机场", "pagerank": 2.812630439318486},
            {"airport": "萧山机场", "pagerank": 2.788741854648085}
        ],
        "flightTimeSlotStatsVOList": [
            {"timeSlot": "00:00 - 01:59", "airline": "九元航空", "flightCount": 1},
            {"timeSlot": "00:00 - 01:59", "airline": "祥鹏航空", "flightCount": 1},
            {"timeSlot": "00:00 - 01:59", "airline": "东方航空", "flightCount": 1},
            {"timeSlot": "02:00 - 03:59", "airline": "南方航空", "flightCount": 2},
            {"timeSlot": "02:00 - 03:59", "airline": "中国国航", "flightCount": 1},
            {"timeSlot": "04:00 - 05:59", "airline": "海南航空", "flightCount": 3},
            {"timeSlot": "06:00 - 07:59", "airline": "东方航空", "flightCount": 15},
            {"timeSlot": "06:00 - 07:59", "airline": "南方航空", "flightCount": 12},
            {"timeSlot": "06:00 - 07:59", "airline": "中国国航", "flightCount": 10},
            {"timeSlot": "08:00 - 09:59", "airline": "东方航空", "flightCount": 28},
            {"timeSlot": "08:00 - 09:59", "airline": "南方航空", "flightCount": 25},
            {"timeSlot": "08:00 - 09:59", "airline": "中国国航", "flightCount": 22},
            {"timeSlot": "08:00 - 09:59", "airline": "海南航空", "flightCount": 18},
            {"timeSlot": "10:00 - 11:59", "airline": "东方航空", "flightCount": 32},
            {"timeSlot": "10:00 - 11:59", "airline": "南方航空", "flightCount": 29},
            {"timeSlot": "10:00 - 11:59", "airline": "中国国航", "flightCount": 26},
            {"timeSlot": "10:00 - 11:59", "airline": "海南航空", "flightCount": 20},
            {"timeSlot": "12:00 - 13:59", "airline": "东方航空", "flightCount": 25},
            {"timeSlot": "12:00 - 13:59", "airline": "南方航空", "flightCount": 22},
            {"timeSlot": "12:00 - 13:59", "airline": "中国国航", "flightCount": 20},
            {"timeSlot": "14:00 - 15:59", "airline": "东方航空", "flightCount": 30},
            {"timeSlot": "14:00 - 15:59", "airline": "南方航空", "flightCount": 28},
            {"timeSlot": "14:00 - 15:59", "airline": "中国国航", "flightCount": 25},
            {"timeSlot": "14:00 - 15:59", "airline": "海南航空", "flightCount": 22},
            {"timeSlot": "16:00 - 17:59", "airline": "东方航空", "flightCount": 35},
            {"timeSlot": "16:00 - 17:59", "airline": "南方航空", "flightCount": 32},
            {"timeSlot": "16:00 - 17:59", "airline": "中国国航", "flightCount": 28},
            {"timeSlot": "16:00 - 17:59", "airline": "海南航空", "flightCount": 25},
            {"timeSlot": "18:00 - 19:59", "airline": "东方航空", "flightCount": 38},
            {"timeSlot": "18:00 - 19:59", "airline": "南方航空", "flightCount": 35},
            {"timeSlot": "18:00 - 19:59", "airline": "中国国航", "flightCount": 30},
            {"timeSlot": "18:00 - 19:59", "airline": "海南航空", "flightCount": 28},
            {"timeSlot": "20:00 - 21:59", "airline": "东方航空", "flightCount": 25},
            {"timeSlot": "20:00 - 21:59", "airline": "南方航空", "flightCount": 22},
            {"timeSlot": "20:00 - 21:59", "airline": "中国国航", "flightCount": 20},
            {"timeSlot": "22:00 - 23:59", "airline": "东方航空", "flightCount": 10},
            {"timeSlot": "22:00 - 23:59", "airline": "南方航空", "flightCount": 8},
            {"timeSlot": "22:00 - 23:59", "airline": "中国国航", "flightCount": 5}
        ],
        "flightRouteDensityStatsVOList": [ 
            {"route": "重庆 -> 上海", "depCity": "重庆", "arrCity": "上海", "flightDensityDaily": 6.43, "airlineCount": 15, "totalFlights": 45, "coveredDays": 7},
            {"route": "上海 -> 西安", "depCity": "上海", "arrCity": "西安", "flightDensityDaily": 6.43, "airlineCount": 14, "totalFlights": 45, "coveredDays": 7},
            {"route": "上海 -> 成都", "depCity": "上海", "arrCity": "成都", "flightDensityDaily": 6.43, "airlineCount": 13, "totalFlights": 45, "coveredDays": 7},
            {"route": "昆明 -> 成都", "depCity": "昆明", "arrCity": "成都", "flightDensityDaily": 6.43, "airlineCount": 11, "totalFlights": 45, "coveredDays": 7},
            {"route": "北京 -> 重庆", "depCity": "北京", "arrCity": "重庆", "flightDensityDaily": 6.43, "airlineCount": 11, "totalFlights": 45, "coveredDays": 7},
            {
                "depCity": "大连",
                "arrCity": "上海",
                "flightDensityDaily": 6.43,
                "airlineCount": 11,
                "totalFlights": 45,
                "coveredDays": 7
            },
            {
                "depCity": "成都",
                "arrCity": "昆明",
                "flightDensityDaily": 6.43,
                "airlineCount": 11,
                "totalFlights": 45,
                "coveredDays": 7
            },
            {
                "depCity": "北京",
                "arrCity": "上海",
                "flightDensityDaily": 9.29,
                "airlineCount": 10,
                "totalFlights": 65,
                "coveredDays": 7
            },
            {
                "depCity": "广州",
                "arrCity": "上海",
                "flightDensityDaily": 8.57,
                "airlineCount": 10,
                "totalFlights": 60,
                "coveredDays": 7
            },
            {
                "depCity": "深圳",
                "arrCity": "上海",
                "flightDensityDaily": 7.86,
                "airlineCount": 9,
                "totalFlights": 55,
                "coveredDays": 7
            }
        ]
    };
}

// 获取地理指标数据
function fetchGeoData() {
    fetch('http://localhost:8080/geo', {
            headers: {
                'jwt': localStorage.getItem('jwt')
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('网络响应不正常');
            }
            return response.json();
        })
        .then(data => {
            console.log('地理指标数据:', data);
            renderGeoCharts(data);
        })
        .catch(error => {
            console.error('获取地理指标数据出错:', error);
            const mockData = getMockGeoData();
            renderGeoCharts(mockData);
        });
}

// 渲染地理指标图表
function renderGeoCharts(data) {
    // 延迟一点时间确保DOM完全渲染
    setTimeout(() => {
        // 提取数据
        const departureStats = data.departureStats || [];
        const landingStats = data.landingStats || [];
        const routeStats = data.routeStats || [];

        // 渲染各个图表
        renderGeoCityMapChart(data);
        renderGeoDepartureChart(departureStats);
        renderGeoLandingChart(landingStats);
        renderGeoRouteChart(routeStats);

        // 获取市场指标数据来渲染城市航班分布地图
        fetch('http://localhost:8080/market', {
            headers: {
                'jwt': localStorage.getItem('jwt')
            }
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('网络响应不正常');
                }
                return response.json();
            })
            .then(marketData => {
                const posData = marketData.posCountVO || [];
                renderCityMapChart(posData);
            })
            .catch(error => {
                console.error('获取市场指标数据出错:', error);
                // 如果获取失败，可以调用模拟数据或显示错误
                console.log('城市航班分布地图数据获取失败');
            });

        // 延迟后再次调整图表大小
        setTimeout(() => {
            Object.values(geoCharts).forEach(chart => {
                if (chart && typeof chart.resize === 'function') {
                    chart.resize();
                }
            });
        }, 500);
    }, 100);
}

// 渲染各省航班分布地图
function renderGeoCityMapChart(data) {
    const chartDom = document.getElementById('geo-city-map-chart');
    const chart = echarts.init(chartDom);
    geoCharts.provinceMap = chart;

    // 加载阿里云在线地图数据
    chart.showLoading();

    fetch('https://geo.datav.aliyun.com/areas_v3/bound/100000_full.json')
        .then(response => response.json())
        .then(geoJson => {
            // 注册地图
            echarts.registerMap('china', geoJson);

            // 使用后端返回的省份数据
            const provinceStats = data.provinceStats || [];
            const routeStats = data.routeStats || [];

            // 转换省份数据为地图需要的格式
            const regionData = {};
            provinceStats.forEach(item => {
                regionData[item.provinceName] = item.flightCount;
            });

            // 特殊处理：确保台湾省和南海诸岛显示为0而不是NaN
            regionData['台湾省'] = regionData['台湾省'] || 0;
            regionData['南海诸岛'] = regionData['南海诸岛'] || 0;

            // 如果没有后端数据，使用模拟数据
            if (provinceStats.length === 0) {
                Object.assign(regionData, {
                    '南海诸岛': 0, '北京市': 524, '天津市': 113, '上海市': 140, '重庆市': 752,
                    '河北省': 13, '河南省': 83, '云南省': 11, '辽宁省': 19, '黑龙江省': 415,
                    '湖南省': 269, '安徽省': 260, '山东省': 39, '新疆维吾尔自治区': 94,
                    '江苏省': 31, '浙江省': 104, '江西省': 36, '湖北省': 1052,
                    '广西壮族自治区': 33, '甘肃省': 347, '山西省': 129, '内蒙古自治区': 157,
                    '陕西省': 22, '吉林省': 46, '福建省': 18, '贵州省': 355, '广东省': 698,
                    '青海省': 341, '西藏自治区': 210, '四川省': 484, '宁夏回族自治区': 404,
                    '海南省': 224, '台湾省': 0, '香港特别行政区': 25, '澳门特别行政区': 225
                });
            }

            // 转换为ECharts需要的数据格式
            const outdata = Object.keys(regionData).map(name => ({
                name: name,
                value: isNaN(regionData[name]) ? 0 : regionData[name] // 防止NaN显示
            }));

            // 城市坐标映射（用于航线连接）
            const cityCoords = {
                '北京': [116.4074, 39.9042],
                '上海': [121.4737, 31.2304],
                '广州': [113.2644, 23.1291],
                '深圳': [114.0579, 22.5431],
                '成都': [104.0668, 30.5728],
                '重庆': [106.5516, 29.5630],
                '昆明': [102.8329, 24.8801],
                '西安': [108.9402, 34.3416],
                '杭州': [120.1551, 30.2741],
                '南京': [118.7969, 32.0603],
                '大连': [121.6147, 38.9140],
                '武汉': [114.3054, 30.5931],
                '天津': [117.2008, 39.0842],
                '青岛': [120.3826, 36.0673],
                '厦门': [118.0894, 24.4798],
                '长沙': [112.9388, 28.2282],
                '郑州': [113.6254, 34.7466],
                '沈阳': [123.4315, 41.8057],
                '哈尔滨': [126.5358, 45.8024],
                '济南': [117.1205, 36.6519],
                '福州': [119.2965, 26.0745],
                '海口': [110.3312, 20.0311],
                '乌鲁木齐': [87.6177, 43.7928],
                '呼和浩特': [111.7519, 40.8414],
                '长春': [125.3245, 43.8171],
                '石家庄': [114.5149, 38.0428],
                '太原': [112.5494, 37.8570],
                '兰州': [103.8343, 36.0611],
                '银川': [106.2309, 38.4872],
                '西宁': [101.7782, 36.6171],
                '拉萨': [91.1409, 29.6456],
                '贵阳': [106.7135, 26.5783],
                '南宁': [108.3661, 22.8177],
                '桂林': [110.2993, 25.2342],
                '三亚': [109.5113, 18.2577],
                '温州': [120.6994, 27.9944],
                '宁波': [121.5440, 29.8683],
                '无锡': [120.3019, 31.5745],
                '苏州': [120.6197, 31.3017],
                '合肥': [117.2272, 31.8206],
                '南昌': [115.8930, 28.6765],
                '包头': [109.9402, 40.6580],
                '唐山': [118.1943, 39.6856],
                '烟台': [121.3914, 37.5287],
                '威海': [122.1201, 37.5107]
            };

            // 生成热门航线的飞线数据
            const lineData = [];
            const scatterData = [];

            // 取前20条热门航线
            const topRoutes = routeStats.slice(0, 20);

            topRoutes.forEach((route, index) => {
                const depCoord = cityCoords[route.depCity];
                const arrCoord = cityCoords[route.arrCity];

                if (depCoord && arrCoord) {
                    // 根据航班数量计算线条宽度，范围在0.5-2之间（更细）
                    const maxFlightCount = Math.max(...topRoutes.map(r => r.flightCount));
                    const minFlightCount = Math.min(...topRoutes.map(r => r.flightCount));
                    const normalizedWidth = 0.5 + (route.flightCount - minFlightCount) / (maxFlightCount - minFlightCount) * 1.5;

                    // 根据排名设置颜色：前10名橙色，11-20名绿色
                    const lineColor = index < 10 ? '#ff8c00' : '#32cd32'; // 橙色和绿色

                    lineData.push({
                        name: `${route.depCity} → ${route.arrCity}`,
                        coords: [depCoord, arrCoord],
                        value: route.flightCount,
                        lineStyle: {
                            color: lineColor,
                            width: normalizedWidth,
                            opacity: 0.7 - (index / topRoutes.length) * 0.2 // 前面的航线更明显
                        }
                    });

                    // 添加起点和终点散点
                    scatterData.push([depCoord[0], depCoord[1], route.flightCount]);
                    scatterData.push([arrCoord[0], arrCoord[1], route.flightCount]);
                }
            });

            // 去重散点数据
            const uniqueScatter = [];
            const coordSet = new Set();
            scatterData.forEach(point => {
                const key = `${point[0]},${point[1]}`;
                if (!coordSet.has(key)) {
                    coordSet.add(key);
                    uniqueScatter.push(point);
                }
            });

            const planePath = 'path://M1705.06,1318.313v-89.254l-319.9-221.799l0.073-208.063c0.521-84.662-26.629-121.796-63.961-121.491c-37.332-0.305-64.482,36.829-63.961,121.491l0.073,208.063l-319.9,221.799v89.254l330.343-157.288l12.238,241.308l-134.449,92.931l0.531,42.034l175.125-42.917l175.125,42.917l0.531-42.034l-134.449-92.931l12.238-241.308L1705.06,1318.313z';

            const maxValue = Math.max(...Object.values(regionData));

            const option = {
                tooltip: {
                    show: true,
                    formatter: function (params) {
                        if (params.seriesType === 'map') {
                            const provinceData = provinceStats.find(p => p.provinceName === params.name);
                            if (provinceData) {
                                return `${params.name}<br/>
                                       总航班数: ${provinceData.flightCount}架次<br/>
                                       起飞航班: ${provinceData.departureCount || 0}架次<br/>
                                       降落航班: ${provinceData.arrivalCount || 0}架次`;
                            } else if (params.value !== undefined && !isNaN(params.value)) {
                                return `${params.name}<br/>航班数: ${params.value}架次`;
                            } else if (params.name === '台湾省' || params.name === '南海诸岛') {
                                return `${params.name}<br/>航班数: 0架次<br/>（暂无数据）`;
                            }
                            return `${params.name}<br/>航班数: 0架次`;
                        } else if (params.seriesType === 'lines') {
                            return `${params.name}<br/>航班数: ${params.value}架次`;
                        }
                        return params.name;
                    }
                },

                visualMap: {
                    type: 'continuous',
                    showLabel: true,
                    left: "20%",
                    bottom: "5%",
                    min: 0,
                    max: 2500,
                    seriesIndex: [0],
                    inRange: {
                        color: [
                            '#d0f9ff',  // 最浅蓝
                            '#c0f2fe',  // 浅蓝
                            '#bae6fd',  // 淡蓝
                            '#7dd3fc',  // 中蓝
                            '#38bdf8',  // 标准蓝
                            '#0ea5e9',  // 深蓝
                            '#0284c7',  // 更深蓝
                            '#0369a1',  // 深蓝色
                            '#075985'   // 最深蓝
                        ]
                    },
                    outOfRange: {
                        color: '#ff0000'  // 超出范围时显示红色
                    },
                    splitNumber: 8,
                    calculable: true,
                    realtime: true,
                    itemWidth: 20,
                    itemHeight: 120,
                    textStyle: {
                        color: '#333'
                    },
                    text: ['高', '低'],
                    formatter: function(value) {
                        return value + '架次';
                    }
                },

                geo: {
                    map: 'china',
                    show: true,
                    roam: false,
                    zoom: 1.5,
                    center: [104, 35],
                    label: {
                        show: true,
                        fontSize: 10,
                        color: '#333',
                        fontWeight: 'normal',
                        emphasis: {
                            show: true,
                            fontSize: 12,
                            color: '#000',
                            fontWeight: 'bold'
                        }
                    },
                    itemStyle: {
                        areaColor: '#f3f3f3',
                        borderColor: '#999',
                        borderWidth: 0.5
                    },
                    emphasis: {
                        itemStyle: {
                            areaColor: 'yellow'
                        }
                    }
                },

                series: [
                    {
                        type: 'map',
                        map: 'china',
                        geoIndex: 0,
                        aspectScale: 0.75,
                        zoom: 1.5,
                        label: {
                            show: true,
                            fontSize: 9,
                            color: '#555',
                            fontWeight: 'normal',
                            emphasis: {
                                show: true,
                                fontSize: 11,
                                color: '#000',
                                fontWeight: 'bold'
                            }
                        },
                        itemStyle: {
                            borderColor: '#fff',
                            borderWidth: 1
                        },
                        emphasis: {
                            itemStyle: {
                                areaColor: '#ffeb3b',
                                borderWidth: 2,
                                shadowColor: 'rgba(0,0,0,.3)',
                                shadowOffsetX: 5,
                                shadowOffsetY: 5
                            }
                        },
                        data: outdata
                    },
                    {
                        name: '重要城市',
                        type: 'effectScatter',
                        coordinateSystem: 'geo',
                        showEffectOn: 'render',
                        zlevel: 2,
                        rippleEffect: {
                            brushType: 'stroke',
                            number: 4,
                            period: 3,
                            scale: 4
                        },
                        data: uniqueScatter.map((coords) => ({
                            name: '重要城市',
                            value: coords,
                            itemStyle: {
                                color: '#ff6b35',
                                shadowBlur: 15,
                                shadowColor: '#ff6b35'
                            }
                        })),
                        symbolSize: function (val) {
                            return Math.min(Math.max(val[2] / 6, 12), 30);
                        }
                    },
                    {
                        name: '热门航线',
                        type: 'lines',
                        zlevel: 2,
                        symbol: ['none', 'arrow'],
                        symbolSize: 8,
                        effect: {
                            show: true,
                            period: 4,
                            trailLength: 0.6,
                            symbol: planePath,
                            symbolSize: 12,
                            color: '#ffd700' // 黄色飞机图标
                        },
                        lineStyle: {
                            width: 0.8,
                            opacity: 0.6,
                            curveness: 0.15
                        },
                        data: lineData,
                        tooltip: {
                            show: true,
                            formatter: function(params) {
                                const index = lineData.findIndex(d => d.name === params.name);
                                const rank = index + 1;
                                let rankColor = '#ff4757';
                                if (rank <= 5) rankColor = '#ff4757';
                                else if (rank <= 10) rankColor = '#ffa502';
                                else rankColor = '#70a1ff';

                                return `<div style="font-size:14px;">
                                    <div style="color:${rankColor};font-weight:bold;">🏆 排名: 第${rank}位</div>
                                    <div>${params.name}</div>
                                    <div style="color:#333;">✈️ 航班数: <strong>${params.value}架次</strong></div>
                                </div>`;
                            }
                        }
                    }
                ]
            };

            chart.hideLoading();
            chart.setOption(option);
        })
        .catch(error => {
            console.error('无法加载地图数据:', error);
            chart.hideLoading();
            chartDom.innerHTML = '<div style="text-align:center;line-height:600px;color:red;">地图数据加载失败，请检查网络连接</div>';
        });
}

// 渲染出发机场航班量图表
function renderGeoDepartureChart(data) {
    const chartDom = document.getElementById('geo-departure-chart');
    const chart = echarts.init(chartDom);
    geoCharts.departure = chart;
    
    // 排序数据
    data.sort((a, b) => b.flightCount - a.flightCount);
    // 只取前5个机场
    const topData = data.slice(0, 5);
    
    const option = {
        tooltip: {
            trigger: 'item',
            formatter: '{b}: {c}架次'
        },
        series: [{
            type: 'pie',
            radius: '70%',
            center: ['50%', '50%'],
            data: topData.map(item => ({
                name: item.airportName,
                value: item.flightCount
            })),
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            },
            label: {
                formatter: '{b}: {c}架次'
            },
            itemStyle: {
                color: function(params) {
                    const colorList = ['#5470c6', '#91cc75', '#fac858', '#ee6666', '#73c0de'];
                    return colorList[params.dataIndex % colorList.length];
                }
            }
        }]
    };
    
    chart.setOption(option);
}

// 渲染到达机场航班量图表
function renderGeoLandingChart(data) {
    const chartDom = document.getElementById('geo-landing-chart');
    const chart = echarts.init(chartDom);
    geoCharts.landing = chart;
    
    // 排序数据
    data.sort((a, b) => b.flightCount - a.flightCount);
    // 只取前5个机场
    const topData = data.slice(0, 5);
    
    const option = {
        tooltip: {
            trigger: 'item',
            formatter: '{b}: {c}架次'
        },
        series: [{
            type: 'pie',
            radius: '70%',
            center: ['50%', '50%'],
            data: topData.map(item => ({
                name: item.airportName,
                value: item.flightCount
            })),
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            },
            label: {
                formatter: '{b}: {c}架次'
            },
            itemStyle: {
                color: function(params) {
                    const colorList = ['#5470c6', '#91cc75', '#fac858', '#ee6666', '#73c0de'];
                    return colorList[params.dataIndex % colorList.length];
                }
            }
        }]
    };
    
    chart.setOption(option);
}

// 渲染热门航线图表
function renderGeoRouteChart(data) {
    const chartDom = document.getElementById('geo-route-chart');
    const chart = echarts.init(chartDom);
    geoCharts.route = chart;
    
    // 排序数据
    data.sort((a, b) => b.flightCount - a.flightCount);
    
    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: '{b}: {c}架次'
        },
        xAxis: {
            type: 'category',
            data: data.map(item => `${item.depCity} → ${item.arrCity}`),
            axisLabel: {
                interval: 0,
                rotate: 30
            }
        },
        yAxis: {
            type: 'value',
            name: '航班数量'
        },
        series: [{
            data: data.map(item => item.flightCount),
            type: 'bar',
            barWidth: '40%',
            itemStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                    { offset: 0, color: '#ff9a00' },
                    { offset: 1, color: '#ff6a00' }
                ])
            },
            label: {
                show: true,
                position: 'top',
                formatter: '{c}架次'
            }
        }]
    };
    
    chart.setOption(option);
}

// 渲染业务指标图表
function renderCoreCharts(data) {
    // 延迟一点时间确保DOM完全渲染
    setTimeout(() => {
        // 提取数据
        const delayData = data.delayVO;
        const prateData = data.prateVO;
        
        // 按类型分组延迟数据
        const airlineDelayData = delayData.filter(item => item.type === 1);
        const airportDelayData = delayData.filter(item => item.type === 2);
        const routeDelayData = delayData.filter(item => item.type === 3);
        
        // 渲染各个图表
        renderAirlineDelayTop5Chart(airlineDelayData);
        renderAirlineDelayBottom5Chart(airlineDelayData);
        renderAirportDelayTop5Chart(airportDelayData);
        renderAirportDelayBottom5Chart(airportDelayData);
        renderRouteDelayTop5Chart(routeDelayData);
        renderRouteDelayBottom5Chart(routeDelayData);
        renderPunctualityTop5Chart(prateData);
        renderPunctualityBottom5Chart(prateData);
        
        // 延迟后再次调整图表大小
        setTimeout(() => {
            Object.values(coreCharts).forEach(chart => {
                if (chart && typeof chart.resize === 'function') {
                    chart.resize();
                }
            });
        }, 500);
    }, 100);
}

// 延迟值转颜色（Top5深红到浅红，Bottom5天蓝到绿色）
function getDelayColor(value, min, max, mode = 'top') {
    let t = (value - min) / (max - min);
    t = Math.max(0, Math.min(1, t));
    if (mode === 'top') {
        // 深红到浅红
        const start = {r: 183, g: 28, b: 28};   // #b71c1c
        const end = {r: 255, g: 138, b: 128};   // #ff8a80
        const r = Math.round(start.r + (end.r - start.r) * (1 - t));
        const g = Math.round(start.g + (end.g - start.g) * (1 - t));
        const b = Math.round(start.b + (end.b - start.b) * (1 - t));
        return `rgb(${r},${g},${b})`;
    } else {
        // 蓝色到绿色过渡（大->小）
        const start = {r: 30, g: 144, b: 255};  // #1e90ff (道奇蓝)
        const end = {r: 50, g: 205, b: 50};     // #32cd32 (酸橙绿)
        // 反转t值，使得大的数值显示为蓝色
        const reversedT = 1 - t;
        const r = Math.round(start.r + (end.r - start.r) * reversedT);
        const g = Math.round(start.g + (end.g - start.g) * reversedT);
        const b = Math.round(start.b + (end.b - start.b) * reversedT);
        return `rgb(${r},${g},${b})`;
    }
}

// 确保图表容器有正确的尺寸
function ensureChartContainerSize(chartDom) {
    if (!chartDom) return false;
    
    // 确保容器可见
    if (chartDom.offsetWidth === 0 || chartDom.offsetHeight === 0) {
        console.warn('图表容器尺寸为0，强制设置最小尺寸');
        chartDom.style.width = '100%';
        chartDom.style.height = '300px';
        chartDom.style.minWidth = '300px';
        chartDom.style.minHeight = '300px';
    }
    
    return true;
}

// 航司平均延迟时间Top5图表
function renderAirlineDelayTop5Chart(data) {
    const chartDom = document.getElementById('airline-delay-top5-chart');
    if (!ensureChartContainerSize(chartDom)) return;
    
    const chart = echarts.init(chartDom);
    coreCharts.airlineDelayTop5 = chart;
    
    // 取前5并降序
    const top5 = [...data].sort((a, b) => parseFloat(b.avgDelay) - parseFloat(a.avgDelay)).slice(0, 5);
    const delays = top5.map(item => parseFloat(item.avgDelay));
    const max = Math.max(...delays);
    const min = Math.min(...delays);
    
    const option = {
        tooltip: { trigger: 'axis', formatter: '{b}: {c}分钟' },
        xAxis: { type: 'category', data: top5.map(item => item.name), axisLabel: { interval: 0, rotate: 30 } },
        yAxis: { type: 'value', name: '平均延误(分钟)' },
        series: [{
            data: delays,
            type: 'bar',
            itemStyle: {
                color: function(params) {
                    return getDelayColor(params.data, min, max, 'top');
                }
            },
            label: { show: true, position: 'top', formatter: '{c}分钟' }
        }]
    };
    chart.setOption(option);
    
    // 强制resize确保正确显示
    setTimeout(() => {
        chart.resize();
    }, 100);
}

// 航司平均延迟时间Bottom5图表
function renderAirlineDelayBottom5Chart(data) {
    const chartDom = document.getElementById('airline-delay-bottom5-chart');
    const chart = echarts.init(chartDom);
    coreCharts.airlineDelayBottom5 = chart;
    
    // 取后5并升序后再降序排列
    const bottom5 = [...data]
        .sort((a, b) => parseFloat(a.avgDelay) - parseFloat(b.avgDelay))
        .slice(0, 5)
        .sort((a, b) => parseFloat(b.avgDelay) - parseFloat(a.avgDelay));
    const delays = bottom5.map(item => parseFloat(item.avgDelay));
    const max = Math.max(...delays);
    const min = Math.min(...delays);
    
    const option = {
        tooltip: { trigger: 'axis', formatter: '{b}: {c}分钟' },
        xAxis: { type: 'category', data: bottom5.map(item => item.name), axisLabel: { interval: 0, rotate: 30 } },
        yAxis: { type: 'value', name: '平均延误(分钟)' },
        series: [{
            data: delays,
            type: 'bar',
            itemStyle: {
                color: function(params) {
                    return getDelayColor(params.data, min, max, 'bottom');
                }
            },
            label: { show: true, position: 'top', formatter: '{c}分钟' }
        }]
    };
    chart.setOption(option);
}

// 机场平均延迟时间Top5图表
function renderAirportDelayTop5Chart(data) {
    const chartDom = document.getElementById('airport-delay-top5-chart');
    const chart = echarts.init(chartDom);
    coreCharts.airportDelayTop5 = chart;
    
    // 取前5并降序
    const top5 = [...data].sort((a, b) => parseFloat(b.avgDelay) - parseFloat(a.avgDelay)).slice(0, 5);
    const delays = top5.map(item => parseFloat(item.avgDelay));
    const max = Math.max(...delays);
    const min = Math.min(...delays);
    
    const option = {
        tooltip: { trigger: 'axis', formatter: '{b}: {c}分钟' },
        xAxis: { type: 'category', data: top5.map(item => item.name), axisLabel: { interval: 0, rotate: 30 } },
        yAxis: { type: 'value', name: '平均延误(分钟)' },
        series: [{
            data: delays,
            type: 'bar',
            itemStyle: {
                color: function(params) {
                    return getDelayColor(params.data, min, max, 'top');
                }
            },
            label: { show: true, position: 'top', formatter: '{c}分钟' }
        }]
    };
    
    chart.setOption(option);
}

// 机场平均延迟时间Bottom5图表
function renderAirportDelayBottom5Chart(data) {
    const chartDom = document.getElementById('airport-delay-bottom5-chart');
    const chart = echarts.init(chartDom);
    coreCharts.airportDelayBottom5 = chart;
    
    // 取后5并升序后再降序排列
    const bottom5 = [...data]
        .sort((a, b) => parseFloat(a.avgDelay) - parseFloat(b.avgDelay))
        .slice(0, 5)
        .sort((a, b) => parseFloat(b.avgDelay) - parseFloat(a.avgDelay));
    const delays = bottom5.map(item => parseFloat(item.avgDelay));
    const max = Math.max(...delays);
    const min = Math.min(...delays);
    
    const option = {
        tooltip: { trigger: 'axis', formatter: '{b}: {c}分钟' },
        xAxis: { type: 'category', data: bottom5.map(item => item.name), axisLabel: { interval: 0, rotate: 30 } },
        yAxis: { type: 'value', name: '平均延误(分钟)' },
        series: [{
            data: delays,
            type: 'bar',
            itemStyle: {
                color: function(params) {
                    return getDelayColor(params.data, min, max, 'bottom');
                }
            },
            label: { show: true, position: 'top', formatter: '{c}分钟' }
        }]
    };
    chart.setOption(option);
}

// 渲染航线延迟Top5图表
function renderRouteDelayTop5Chart(data) {
    const chartDom = document.getElementById('route-delay-top5-chart');
    const chart = echarts.init(chartDom);
    coreCharts.routeDelayTop5 = chart;
    
    // 取前5并降序
    const top5 = [...data].sort((a, b) => parseFloat(b.avgDelay) - parseFloat(a.avgDelay)).slice(0, 5);
    const delays = top5.map(item => parseFloat(item.avgDelay));
    const max = Math.max(...delays);
    const min = Math.min(...delays);
    
    const option = {
        tooltip: { trigger: 'axis', formatter: '{b}: {c}分钟' },
        xAxis: { type: 'category', data: top5.map(item => item.name), axisLabel: { interval: 0, rotate: 30 } },
        yAxis: { type: 'value', name: '平均延误(分钟)' },
        series: [{
            data: delays,
            type: 'bar',
            itemStyle: {
                color: function(params) {
                    return getDelayColor(params.data, min, max, 'top');
                }
            },
            label: { show: true, position: 'top', formatter: '{c}分钟' }
        }]
    };
    chart.setOption(option);
}

// 渲染航线延迟Bottom5图表
function renderRouteDelayBottom5Chart(data) {
    const chartDom = document.getElementById('route-delay-bottom5-chart');
    const chart = echarts.init(chartDom);
    coreCharts.routeDelayBottom5 = chart;
    
    // 取后5并升序后再降序排列
    const bottom5 = [...data]
        .sort((a, b) => parseFloat(a.avgDelay) - parseFloat(b.avgDelay))
        .slice(0, 5)
        .sort((a, b) => parseFloat(b.avgDelay) - parseFloat(a.avgDelay));
    const delays = bottom5.map(item => parseFloat(item.avgDelay));
    const max = Math.max(...delays);
    const min = Math.min(...delays);
    
    const option = {
        tooltip: { trigger: 'axis', formatter: '{b}: {c}分钟' },
        xAxis: { type: 'category', data: bottom5.map(item => item.name), axisLabel: { interval: 0, rotate: 30 } },
        yAxis: { type: 'value', name: '平均延误(分钟)' },
        series: [{
            data: delays,
            type: 'bar',
            itemStyle: {
                color: function(params) {
                    return getDelayColor(params.data, min, max, 'bottom');
                }
            },
            label: { show: true, position: 'top', formatter: '{c}分钟' }
        }]
    };
    chart.setOption(option);
}

// 渲染航班准点率Top5图表
function renderPunctualityTop5Chart(data) {
    const chartDom = document.getElementById('punctuality-top5-chart');
    const chart = echarts.init(chartDom);
    coreCharts.punctualityTop5 = chart;

    // 取前5并降序
    let top5 = [...data].sort((a, b) => parseFloat(b.punctuality) - parseFloat(a.punctuality)).slice(0, 5);

    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: '{b}: {c}%'
        },
        xAxis: {
            type: 'category',
            data: top5.map(item => item.name),
            axisLabel: {
                interval: 0,
                rotate: 30
            }
        },
        yAxis: {
            type: 'value',
            name: '准点率(%)',
            min: 0,
            max: 100
        },
        series: [{
            data: top5.map(item => parseFloat(item.punctuality)),
            type: 'bar',
            barWidth: '40%',
            itemStyle: {
                color: function(params) {
                    const colorList = ['#4ecdc4', '#52b788', '#76c893', '#99d98c', '#b5e48c'];
                    return colorList[params.dataIndex % colorList.length] || '#b5e48c';
                }
            },
            label: {
                show: true,
                position: 'top',
                formatter: '{c}%'
            }
        }]
    };
    chart.setOption(option);
}

// 渲染航班准点率Bottom5图表
function renderPunctualityBottom5Chart(data) {
    const chartDom = document.getElementById('punctuality-bottom5-chart');
    const chart = echarts.init(chartDom);
    coreCharts.punctualityBottom5 = chart;

    // 取后5并降序
    let bottom5 = [...data].sort((a, b) => parseFloat(a.punctuality) - parseFloat(b.punctuality)).slice(0, 5).sort((a, b) => parseFloat(b.punctuality) - parseFloat(a.punctuality));

    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: '{b}: {c}%'
        },
        xAxis: {
            type: 'category',
            data: bottom5.map(item => item.name),
            axisLabel: {
                interval: 0,
                rotate: 30
            }
        },
        yAxis: {
            type: 'value',
            name: '准点率(%)',
            min: 0,
            max: 100
        },
        series: [{
            data: bottom5.map(item => parseFloat(item.punctuality)),
            type: 'bar',
            barWidth: '40%',
            itemStyle: {
                color: function(params) {
                    const colorList = ['#ff6b6b', '#ffb385', '#ffd6a5', '#fdffb6', '#caffbf'];
                    return colorList[params.dataIndex % colorList.length] || '#caffbf';
                }
            },
            label: {
                show: true,
                position: 'top',
                formatter: '{c}%'
            }
        }]
    };
    chart.setOption(option);
}

// 渲染市场指标图表
function renderMarketCharts(data) {
    console.log('市场指标数据:', data);
    
    // 延迟一点时间确保DOM完全渲染
    setTimeout(() => {
        // 提取数据
        const airlineCountData = data.airlineCountVO || [];
        const cityCountData = data.cityCountVO || [];
        const airportCountData = data.airportCountVO || [];
        const coverageData = data.top5VO || [];
        const posData = data.posCountVO || [];
        const airlineMileageData = data.airlineMileageVO || [];
        const aircraftFlightData = data.aircraftFlightVO || [];
        
        console.log('机型航班数据提取:', aircraftFlightData);
        
        // 渲染各个图表
        renderAirlineCountChart(airlineCountData);
        renderCityCountChart(cityCountData);
        renderAirportCountChart(airportCountData);
        renderCoverageChart(coverageData);
        renderAirlineMileageChart(airlineMileageData);
        renderAircraftFlight3DChart(aircraftFlightData);
        
        // 获取时间指标数据来渲染机场知识图谱和航线竞争强度
        fetch('http://localhost:8080/time', {
            headers: {
                'jwt': localStorage.getItem('jwt')
            }
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('网络响应不正常');
                }
                return response.json();
            })
            .then(timeData => {
                renderAirportKnowledgeGraph(timeData.airportPagerankVOList);
                renderRouteCompetitionBarChart(timeData.flightRouteDensityStatsVOList);
            })
            .catch(error => {
                console.error('获取时间指标数据出错:', error);
                // 使用模拟数据
                const mockData = getMockTimeData();
                renderAirportKnowledgeGraph(mockData.airportPagerankVOList);
                renderRouteCompetitionBarChart(mockData.flightRouteDensityStatsVOList);
            });
        
        // 延迟后再次调整图表大小
        setTimeout(() => {
            Object.values(marketCharts).forEach(chart => {
                if (chart && typeof chart.resize === 'function') {
                    chart.resize();
                }
            });
        }, 500);
    }, 100);
}

// 航司航班数量图表
function renderAirlineCountChart(data) {
    const chartDom = document.getElementById('airline-count-chart');
    const chart = echarts.init(chartDom);
    marketCharts.airlineCount = chart;
    
    // 排序
    data.sort((a, b) => b.count - a.count);
    
    const option = {
        tooltip: {
            trigger: 'item',
            formatter: '{b}: {c}架次'
        },
        series: [{
            type: 'pie',
            radius: '70%',
            center: ['50%', '50%'],
            data: data.map(item => ({
                name: item.airlineName,
                value: item.count
            })),
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            },
            label: {
                formatter: '{b}: {c}架次'
            }
        }]
    };
    
    chart.setOption(option);
}

// 城市航班数量图表
function renderCityCountChart(data) {
    const chartDom = document.getElementById('city-count-chart');
    const chart = echarts.init(chartDom);
    marketCharts.cityCount = chart;
    
    // 排序
    data.sort((a, b) => b.count - a.count);
    // 只取前6个城市
    const topData = data.slice(0, 6);
    
    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: '{b}: {c}架次'
        },
        xAxis: {
            type: 'category',
            data: topData.map(item => item.cityName),
            axisLabel: {
                interval: 0,
                rotate: 30
            }
        },
        yAxis: {
            type: 'value',
            name: '航班数量'
        },
        series: [{
            data: topData.map(item => item.count),
            type: 'bar',
            barWidth: '40%',
            itemStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                    { offset: 0, color: '#83a4d4' },
                    { offset: 1, color: '#b6fbff' }
                ])
            },
            label: {
                show: true,
                position: 'top',
                formatter: '{c}架次'
            }
        }]
    };
    
    chart.setOption(option);
}

// 机场航班数量图表
function renderAirportCountChart(data) {
    const chartDom = document.getElementById('airport-count-chart');
    const chart = echarts.init(chartDom);
    marketCharts.airportCount = chart;
    
    // 排序
    data.sort((a, b) => parseInt(b.count) - parseInt(a.count));
    // 只取前6个机场
    const topData = data.slice(0, 6);
    
    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: '{b}: {c}架次'
        },
        xAxis: {
            type: 'category',
            data: topData.map(item => item.airportName),
            axisLabel: {
                interval: 0,
                rotate: 30
            }
        },
        yAxis: {
            type: 'value',
            name: '航班数量'
        },
        series: [{
            data: topData.map(item => parseInt(item.count)),
            type: 'bar',
            barWidth: '40%',
            itemStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                    { offset: 0, color: '#5ee7df' },
                    { offset: 1, color: '#b490ca' }
                ])
            },
            label: {
                show: true,
                position: 'top',
                formatter: '{c}架次'
            }
        }]
    };
    
    chart.setOption(option);
}

// 航司覆盖率TOP5图表
function renderCoverageChart(data) {
    const chartDom = document.getElementById('coverage-chart');
    const chart = echarts.init(chartDom);
    marketCharts.coverage = chart;
    
    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: '{b}: {c}%'
        },
        xAxis: {
            type: 'value',
            name: '覆盖率(%)',
            max: 50
        },
        yAxis: {
            type: 'category',
            data: data.map(item => item.airline).reverse(),
            axisLabel: {
                interval: 0
            }
        },
        series: [{
            data: data.map(item => parseFloat(item.coverage_rate)).reverse(),
            type: 'bar',
            barWidth: '60%',
            itemStyle: {
                color: function(params) {
                    const colorList = ['#ff9a00', '#ff9a3c', '#ffa361', '#ffad86', '#ffb8a8'];
                    return colorList[params.dataIndex] || '#ffb8a8';
                }
            },
            label: {
                show: true,
                position: 'right',
                formatter: '{c}%'
            }
        }]
    };
    
    chart.setOption(option);
}

// 航司里程数图表
function renderAirlineMileageChart(data) {
    const chartDom = document.getElementById('airline-mileage-chart');
    if (!ensureChartContainerSize(chartDom)) return;
    
    const chart = echarts.init(chartDom);
    marketCharts.airlineMileage = chart;
    
    // 排序
    data.sort((a, b) => b.totalMileage - a.totalMileage);
    
    const option = {
        tooltip: {
            trigger: 'axis',
            formatter: '{b}: {c}公里'
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis: {
            type: 'value',
            name: '总里程数(公里)',
            axisLabel: {
                formatter: function(value) {
                    if (value >= 1000000) {
                        return (value / 1000000).toFixed(1) + 'M';
                    } else if (value >= 1000) {
                        return (value / 1000).toFixed(1) + 'K';
                    }
                    return value;
                }
            }
        },
        yAxis: {
            type: 'category',
            data: data.map(item => item.airlineName).reverse(),
            axisLabel: {
                interval: 0
            }
        },
        series: [{
            data: data.map(item => parseInt(item.totalMileage)).reverse(),
            type: 'bar',
            barWidth: '60%',
            itemStyle: {
                color: function(params) {
                    const colorList = ['#ff9a00', '#ff9a3c', '#ffa361', '#ffad86', '#ffb8a8'];
                    return colorList[params.dataIndex] || '#ffb8a8';
                }
            },
            label: {
                show: true,
                position: 'right',
                formatter: function(params) {
                    const value = params.value;
                    if (value >= 1000000) {
                        return (value / 1000000).toFixed(1) + 'M公里';
                    } else if (value >= 1000) {
                        return (value / 1000).toFixed(1) + 'K公里';
                    }
                    return value + '公里';
                }
            }
        }]
    };
    
    chart.setOption(option);
    
    // 强制resize确保正确显示
    setTimeout(() => {
        chart.resize();
    }, 100);
}

// 城市航班分布地图
function renderCityMapChart(data) {
    const chartDom = document.getElementById('city-map-chart');
    const chart = echarts.init(chartDom);
    geoCharts.cityMap = chart;
    
    // 加载中国地图
    chart.showLoading();
    registerMap(chart, function() {
        continueRenderMap();
    });
    
    function continueRenderMap() {
        try {
            const mapData = data.map(item => ({
                name: item.city,
                value: [item.lng, item.lat, item.depCount + item.arrCount],
                depCount: item.depCount,
                arrCount: item.arrCount
            }));
    
    const option = {
        tooltip: {
            trigger: 'item',
            formatter: function(params) {
                const data = params.data;
                return `${data.name}<br/>总航班量: ${data.value[2]}<br/>出发: ${data.depCount}<br/>到达: ${data.arrCount}`;
            }
        },
        visualMap: {
            min: 0,
            max: Math.max(...mapData.map(item => item.value[2])),
            calculable: true,
            inRange: {
                color: ['#50a3ba', '#eac736', '#d94e5d']
            },
            textStyle: {
                color: '#333'
            },
            left: 'right',
            top: 'bottom',
            text: ['高航班量', '低航班量'],
            dimension: 2
        },
        legend: {
            data: ['航班数量', '航线'],
            orient: 'horizontal',
            bottom: 10,
            textStyle: {
                color: '#333'
            }
        },
        geo: {
                map: 'china',
                roam: true,
                zoom: 1.2,
                center: [104.0, 37.5], 
            label: {
                show: true,  
                fontSize: 10,
                color: '#333'
            },
            itemStyle: {
                areaColor: '#f3f3f3',
                borderColor: '#ddd',
                borderWidth: 1
            },
            emphasis: {
                label: {
                    show: true,
                    fontSize: 12,
                    fontWeight: 'bold'
                },
                itemStyle: {
                    areaColor: '#e6f7ff'
                }
            }
        },
        series: [{
            name: '航班数量',
            type: 'scatter',
            coordinateSystem: 'geo',
            data: mapData,
            symbolSize: function(val) {
                return Math.min(Math.max(val[2] / 2, 15), 45);
            },
            encode: {
                value: 2
            },
            itemStyle: {
                    color: function(params) {
                        const value = params.data.value[2];
                        if (value > 800) return '#d94e5d';
                        if (value > 400) return '#eac736';
                        return '#50a3ba';
                    },
                    shadowBlur: 10,
                    shadowColor: 'rgba(0, 0, 0, 0.3)'
                },
                tooltip: {
                    formatter: function(params) {
                        const data = params.data;
                        return `${data.name}<br/>总航班量: <b>${data.value[2]}</b><br/>出发航班: ${data.depCount}<br/>到达航班: ${data.arrCount}`;
                    }
                },
            label: {
                formatter: '{b}',
                position: 'right',
                show: true,
                color: '#333',
                fontWeight: 'bold'
            },
            emphasis: {
                label: {
                    show: true,
                    formatter: function(params) {
                        return params.name + '\n' + params.data.value[2] + '架次';
                    },
                    backgroundColor: 'rgba(255,255,255,0.8)',
                    padding: [4, 8],
                    borderRadius: 4
                },
                itemStyle: {
                    shadowBlur: 20,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            }
        }]
    };
    
        chart.hideLoading();
        chart.setOption(option);
        } catch (error) {
            console.error('城市航班分布地图渲染错误:', error);
            chart.hideLoading();
            chartDom.innerHTML = '<div style="text-align:center;line-height:300px;color:red;">地图渲染失败</div>';
        }
    }
}

// 注册中国地图
function registerMap(chart, callback) {
    if (!echarts.getMap('china')) {
        console.log('正在加载中国地图数据...');
        $.get('https://geo.datav.aliyun.com/areas_v3/bound/100000_full.json', function(chinaJson) {
            console.log('中国地图数据加载成功');
            echarts.registerMap('china', chinaJson);
            if (callback) callback();
        });
    } else {
        console.log('中国地图数据已成功加载');
        if (callback) callback();
    }
}

// 调整所有图表大小
function resizeAllCharts() {
    const activeSection = document.querySelector('.content-section.active');
    if (activeSection.id === 'core-content') {
        Object.values(coreCharts).forEach(chart => {
            if (chart && typeof chart.resize === 'function') {
                chart.resize();
            }
        });
    } else if (activeSection.id === 'market-content') {
        Object.values(marketCharts).forEach(chart => {
            if (chart && typeof chart.resize === 'function') {
                chart.resize();
            }
        });
    } else if (activeSection.id === 'time-content') {
        Object.values(timeCharts).forEach(chart => {
            if (chart && typeof chart.resize === 'function') {
                chart.resize();
            }
        });
    } else if (activeSection.id === 'geo-content') {
        Object.values(geoCharts).forEach(chart => {
            if (chart && typeof chart.resize === 'function') {
                chart.resize();
            }
        });
    }
}

// 获取地理指标模拟数据
function getMockGeoData() {
    return {
        "departureStats": [
            {
                "airportName": "首都机场",
                "flightCount": 954
            },
            {
                "airportName": "江北机场",
                "flightCount": 680
            },
            {
                "airportName": "白云机场",
                "flightCount": 678
            },
            {
                "airportName": "长水机场",
                "flightCount": 672
            },
            {
                "airportName": "双流机场",
                "flightCount": 639
            }
        ],
        "landingStats":[
            {
                "airportName": "首都机场",
                "flightCount": 881
            },
            {
                "airportName": "白云机场",
                "flightCount": 695
            },
            {
                "airportName": "江北机场",
                "flightCount": 635
            },
            {
                "airportName": "双流机场",
                "flightCount": 627
            },
            {
                "airportName": "宝安机场",
                "flightCount": 620
            }
        ],
        "routeStats":[
            {
                "depCity": "成都",
                "arrCity": "昆明",
                "flightCount": 45
            },
            {
                "depCity": "上海",
                "arrCity": "成都",
                "flightCount": 45
            },
            {
                "depCity": "重庆",
                "arrCity": "北京",
                "flightCount": 45
            },
            {
                "depCity": "重庆",
                "arrCity": "上海",
                "flightCount": 45
            },
            {
                "depCity": "北京",
                "arrCity": "重庆",
                "flightCount": 45
            },
            {
                "depCity": "大连",
                "arrCity": "上海",
                "flightCount": 45
            },
            {
                "depCity": "昆明",
                "arrCity": "成都",
                "flightCount": 45
            }
        ]
    };
}

// 机型航班数饼图
function renderAircraftFlight3DChart(data) {
    const chartDom = document.getElementById('aircraft-flight-chart');
    if (!ensureChartContainerSize(chartDom)) return;
    
    console.log('机型航班数据:', data);
    
    // 如果数据为空，显示提示信息
    if (!data || data.length === 0) {
        chartDom.innerHTML = '<div style="text-align:center;line-height:300px;color:#666;">暂无机型航班数据</div>';
        return;
    }
    
    const chart = echarts.init(chartDom);
    marketCharts.aircraftFlight = chart;
    
    // 计算总数
    let total = 0;
    data.forEach(item => {
        total += item.flightCount;
    });
    
    // 转换数据格式，只显示前10个机型，其余归为"其他"
    const topData = [...data].sort((a, b) => b.flightCount - a.flightCount).slice(0, 10);
    const otherCount = data.slice(10).reduce((sum, item) => sum + item.flightCount, 0);
    
    const pieData = topData.map(item => ({
        name: item.aircraftModel,
        value: item.flightCount
    }));
    
    // 如果有其他机型，添加到数据中
    if (otherCount > 0) {
        pieData.push({
            name: '其他机型',
            value: otherCount
        });
    }
    
    const option = {
        tooltip: {
            trigger: 'item',
            formatter: function(params) {
                const percentage = ((params.value / total) * 100).toFixed(1);
                return `${params.name}<br/>航班数: ${params.value}架次<br/>占比: ${percentage}%`;
            }
        },
        legend: {
            orient: 'vertical',
            left: '2%',
            top: '10%',
            textStyle: {
                fontSize: 12
            },
            itemWidth: 12,
            itemHeight: 12,
            itemGap: 8
        },
        series: [{
            name: '机型分布',
            type: 'pie',
            radius: ['40%', '70%'],
            center: ['60%', '50%'],
            avoidLabelOverlap: false,
            itemStyle: {
                borderRadius: 8,
                borderColor: '#fff',
                borderWidth: 2
            },
            label: {
                show: true,
                position: 'outside',
                formatter: function(params) {
                    const percentage = ((params.value / total) * 100).toFixed(1);
                    // 确保百分比不为0.0%，如果小于0.1%则显示<0.1%
                    const displayPercentage = percentage === '0.0' ? '<0.1' : percentage;
                    return `${displayPercentage}%`;
                },
                fontSize: 11
            },
            emphasis: {
                label: {
                    show: true,
                    fontSize: 14,
                    fontWeight: 'bold'
                },
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            },
            labelLine: {
                show: true,
                length: 15,
                length2: 10
            },
            data: pieData,
            animationType: 'scale',
            animationEasing: 'elasticOut',
            animationDelay: function (idx) {
                return Math.random() * 200;
            }
        }]
    };
    
    chart.setOption(option);
    
    // 强制resize确保正确显示
    setTimeout(() => {
        chart.resize();
    }, 100);
}

// 渲染航班时刻表
function renderFlightScheduleTable(data) {
    const tbody = document.getElementById('flight-schedule-tbody');
    if (!tbody) {
        console.error('找不到航班时刻表容器');
        return;
    }
    // 清空现有内容
    tbody.innerHTML = '';
    if (!data || data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:#666;">暂无航班时刻表数据</td></tr>';
        return;
    }
    // 渲染数据
    data.forEach(schedule => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${schedule.flightNo || ''}</td>
            <td>${schedule.airline || ''}</td>
            <td>${schedule.firstDepartureTime || ''}</td>
            <td>${schedule.lastArrivalTime || ''}</td>
        `;
        tbody.appendChild(row);
    });
}

// ================== 时间指标-航班甘特图 ==================

function initAirlineSelectAndGantt() {
    const select = document.getElementById('airline-select');
    if (!select) return;
    // 获取所有航司
    fetch('http://localhost:8080/flight-schedule/airlines', {
            headers: {
                'jwt': localStorage.getItem('jwt')
            }
        })
        .then(res => res.json())
        .then(res => {
            if (res.code === 1 && Array.isArray(res.data)) {
                select.innerHTML = res.data.map(airline => `<option value="${airline}">${airline}</option>`).join('');
                if (res.data.length > 0) {
                    fetchAndRenderGantt(res.data[0]);
                }
            }
        });
    select.addEventListener('change', function() {
        fetchAndRenderGantt(this.value);
    });
}

function fetchAndRenderGantt(airline) {
    document.getElementById('airline-gantt-title').innerText = airline ? `当前航司：${airline}` : '';
    fetch(`http://localhost:8080/flight-schedule/airline/${encodeURIComponent(airline)}`, {
            headers: {
                'jwt': localStorage.getItem('jwt')
            }
        })
        .then(res => res.json())
        .then(res => {
            if (res.code === 1 && Array.isArray(res.data)) {
                renderFlightGanttChart(res.data);
            } else {
                renderFlightGanttChart([]);
            }
        });
}

function renderFlightGanttChart(data) {
    const chartDom = document.getElementById('flight-gantt-chart');
    if (!chartDom) return;
    if (!data || data.length === 0) {
        chartDom.innerHTML = '<div style="text-align:center;line-height:300px;color:#666;">暂无该航司航班数据</div>';
        return;
    }
    // 每个航班24px，最小300px，最大1200px
    const height = Math.max(300, Math.min(data.length * 24, 1200));
    chartDom.style.height = height + 'px';
    chartDom.style.overflowY = 'auto';

    function timeToMinutes(t) {
        if (!t) return 0;
        const [h, m] = t.split(':').map(Number);
        return h * 60 + m;
    }
    const xMin = 0, xMax = 1440;
    const yData = data.map((_, idx) => idx + 1);

    const customData = data.map((item, idx) => ({
        flightNo: item.flightNo,
        firstDepartureTime: item.firstDepartureTime,
        lastArrivalTime: item.lastArrivalTime,
        y: idx,
        xStart: timeToMinutes(item.firstDepartureTime),
        xEnd: timeToMinutes(item.lastArrivalTime)
    }));

    // 高辨识度配色
    const colorList = [
        '#6c8ae4', '#50a3ba', '#d94e5d', '#eac736', '#5ab1ef', '#b6a2de',
        '#ffb980', '#2ec7c9', '#b7d28d', '#f5994e', '#c05050', '#4b565b',
        '#009688', '#f44336', '#8bc34a', '#ffc107', '#9c27b0', '#03a9f4',
        '#e91e63', '#607d8b', '#795548', '#00bcd4', '#ff5722', '#cddc39'
    ];

    const option = {
        tooltip: {
            formatter: function(params) {
                const d = params.data;
                return `航班号: <b>${d[0]}</b><br>起飞: <b>${d[1]}</b><br>降落: <b>${d[2]}</b>`;
            },
            backgroundColor: '#fff',
            borderColor: '#667eea',
            borderWidth: 1,
            textStyle: { color: '#333', fontSize: 13 }
        },
        grid: { left: 50, right: 40, top: 30, bottom: 50 },
        xAxis: {
            min: xMin,
            max: xMax,
            type: 'value',
            axisLabel: {
                fontSize: 11,
                formatter: function(val) {
                    const h = Math.floor(val / 60).toString().padStart(2, '0');
                    const m = (val % 60).toString().padStart(2, '0');
                    return `${h}:${m}`;
                }
            },
            splitNumber: 24,
            interval: 60,
            name: '时间',
            nameTextStyle: { fontWeight: 600, fontSize: 13 }
        },
        yAxis: {
            type: 'category',
            data: yData,
            name: '',
            axisLabel: { show: false }
        },
        series: [{
            type: 'custom',
            renderItem: function(params, api) {
                const yIndex = api.value(3);
                const xStart = api.coord([api.value(4), yIndex]);
                const xEnd = api.coord([api.value(5), yIndex]);
                const barHeight = 18;
                return {
                    type: 'rect',
                    shape: {
                        x: xStart[0],
                        y: xStart[1] - barHeight / 2,
                        width: Math.max(xEnd[0] - xStart[0], 2),
                        height: barHeight
                    },
                    style: api.style({
                        fill: colorList[yIndex % colorList.length], // 每个航班不同色
                        shadowColor: '#b3c6f7',
                        shadowBlur: 4
                    })
                };
            },
            encode: {
                x: [4, 5],
                y: 3
            },
            data: customData.map(d => [
                d.flightNo,
                d.firstDepartureTime,
                d.lastArrivalTime,
                d.y,
                d.xStart,
                d.xEnd
            ])
        }]
    };
    const chart = echarts.init(chartDom);
    chart.setOption(option);
    setTimeout(() => chart.resize(), 100);
}

// 支持航班多选下拉框鼠标滚轮滚动
(function enableFlightSelectWheelScroll() {
    const flightSelect = document.getElementById('flight-select');
    if (!flightSelect) return;
    flightSelect.addEventListener('wheel', function(e) {
        // 只在有滚动条时阻止默认
        if (this.scrollHeight > this.clientHeight) {
            e.preventDefault();
            this.scrollTop += e.deltaY;
        }
    });
})();

// 全选和清空按钮功能
(function enableFlightSelectButtons() {
    const flightSelect = document.getElementById('flight-select');
    const btnAll = document.getElementById('flight-select-all');
    const btnClear = document.getElementById('flight-select-clear');
    if (!flightSelect || !btnAll || !btnClear) return;
    btnAll.addEventListener('click', function() {
        for (let i = 0; i < flightSelect.options.length; i++) {
            flightSelect.options[i].selected = true;
        }
        renderSelectedFlightsGantt();
    });
    btnClear.addEventListener('click', function() {
        for (let i = 0; i < flightSelect.options.length; i++) {
            if (flightSelect.options[i].selected) {
                flightSelect.options[i].selected = false;
            }
        }
        renderSelectedFlightsGantt();
    });
})();

// ================== 时间指标-航班甘特图（多选航班） ==================

document.addEventListener('DOMContentLoaded', function() {
    // 显示用户名和注销功能
    const usernameDisplay = document.getElementById('username-display');
    const logoutBtn = document.getElementById('logout-btn');
    const storedUsername = localStorage.getItem('username');
    
    if (storedUsername) {
        usernameDisplay.textContent = storedUsername;
    }
    
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            localStorage.removeItem('jwt');
            localStorage.removeItem('username');
            window.location.href = 'login.html';
        });
    }
    initAirlineSelectAndGantt();
});

function initAirlineSelectAndGantt() {
    const airlineSelect = document.getElementById('airline-select');
    const flightSelect = document.getElementById('flight-select');
    if (!airlineSelect || !flightSelect) return;
    // 获取所有航司
    fetch('http://localhost:8080/flight-schedule/airlines', {
            headers: {
                'jwt': localStorage.getItem('jwt')
            }
        })
        .then(res => res.json())
        .then(res => {
            if (res.code === 1 && Array.isArray(res.data)) {
                airlineSelect.innerHTML = res.data.map(airline => `<option value="${airline}">${airline}</option>`).join('');
                if (res.data.length > 0) {
                    fetchAndFillFlights(res.data[0]);
                }
            }
        });
    airlineSelect.addEventListener('change', function() {
        fetchAndFillFlights(this.value);
    });
    flightSelect.addEventListener('change', function() {
        renderSelectedFlightsGantt();
    });
}

let allFlightsOfCurrentAirline = [];

function fetchAndFillFlights(airline) {
    document.getElementById('airline-gantt-title').innerText = airline ? `当前航司：${airline}` : '';
    fetch(`http://localhost:8080/flight-schedule/airline/${encodeURIComponent(airline)}`, {
            headers: {
                'jwt': localStorage.getItem('jwt')
            }
        })
        .then(res => res.json())
        .then(res => {
            if (res.code === 1 && Array.isArray(res.data)) {
                allFlightsOfCurrentAirline = res.data;
                const flightSelect = document.getElementById('flight-select');
                flightSelect.innerHTML = res.data.map(f => `<option value="${f.flightNo}">${f.flightNo}</option>`).join('');
                // 默认全选前10个
                for (let i = 0; i < Math.min(10, res.data.length); i++) {
                    flightSelect.options[i].selected = true;
                }
                renderSelectedFlightsGantt();
            } else {
                allFlightsOfCurrentAirline = [];
                document.getElementById('flight-select').innerHTML = '';
                renderFlightGanttChart([]);
            }
        });
}

function renderSelectedFlightsGantt() {
    const flightSelect = document.getElementById('flight-select');
    const selected = Array.from(flightSelect.selectedOptions).map(opt => opt.value);
    const showFlights = allFlightsOfCurrentAirline.filter(f => selected.includes(f.flightNo));
    renderFlightGanttChart(showFlights);
}

// 获取机型里程数据
function fetchAircraftMileageData() {
    fetch('http://localhost:8080/core/aircraft-mileage', {
            headers: {
                'jwt': localStorage.getItem('jwt')
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('网络响应不正常');
            }
            return response.json();
        })
        .then(data => {
            renderAircraftMileageChart(data);
        })
        .catch(error => {
            console.error('获取机型里程数据出错:', error);
            const mockData = getMockAircraftMileageData();
            renderAircraftMileageChart(mockData);
        });
}

// 渲染机型里程数据图表
function renderAircraftMileageChart(data) {
    const chartDom = document.getElementById('aircraft-mileage-chart');
    if (!ensureChartContainerSize(chartDom)) return;
    
    const chart = echarts.init(chartDom);
    coreCharts.aircraftMileage = chart;

    // 提取数据
    const aircraftModels = data.map(item => item.aircraftModel);
    const totalMileages = data.map(item => item.totalMileage / 1000); // 转换为千公里
    const avgMileages = data.map(item => (item.avgMileage / 1000).toFixed(2)); // 转换为千公里并格式化

    const option = {
        backgroundColor: {
            type: 'linear',
            x: 0,
            y: 0,
            x2: 0,
            y2: 1,
            colorStops: [{
                offset: 0, color: 'rgba(135, 206, 250, 0.1)' // 天蓝色渐变开始
            }, {
                offset: 1, color: 'rgba(70, 130, 180, 0.05)' // 钢蓝色渐变结束
            }]
        },
        color: ["#1cd389", "#668eff", "#50a3ba", "#d94e5d"],
        grid: {
            top: '15%',
            left: '8%',
            right: '8%',
            bottom: '15%',
            containLabel: true,
        },
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'shadow'
            },
            textStyle: {
                fontSize: 14,
            },
            backgroundColor: "rgba(255,255,255,0.95)",
            extraCssText: "box-shadow: 2px 2px 4px 0px rgba(0,0,0,0.3);",
            formatter: (params) => {
                let result = `${params[0].name}<br>`;
                if (params[0]) {
                    result += `总里程: ${(params[0].value * 1000).toLocaleString()} 公里<br>`;
                }
                if (params[3]) {
                    result += `平均里程: ${(params[3].value * 1000).toLocaleString()} 公里`;
                }
                return result;
            }
        },
        xAxis: {
            type: 'category',
            data: aircraftModels,
            splitLine: {
                show: false,
            },
            axisLabel: {
                color: "#666",
                fontSize: 12,
                interval: 0,
                rotate: 30
            },
            axisTick: {
                show: false
            },
            axisLine: {
                lineStyle: {
                    color: 'rgba(102, 102, 102, 0.3)',
                }
            },
        },
        yAxis: [{
            type: 'value',
            name: "总里程(千公里)",
            nameGap: '30',
            min: 0,
            axisTick: {
                show: false
            },
            axisLabel: {
                show: true,
                fontSize: 12,
                color: "#666",
            },
            axisLine: {
                show: true,
                lineStyle: {
                    color: 'rgba(102, 102, 102, 0.3)',
                }
            },
            splitLine: {
                lineStyle: {
                    color: 'rgba(102, 102, 102, 0.1)',
                }
            },
            nameTextStyle: {
                color: "#666",
                fontWeight: 400,
                fontSize: 12,
            },
        }, {
            type: 'value',
            name: "平均里程(千公里)",
            nameGap: '30',
            nameTextStyle: {
                color: "#666",
                fontWeight: 400,
                fontSize: 12,
            },
            axisTick: {
                show: false
            },
            axisLabel: {
                show: true,
                fontSize: 12,
                color: "#666",
            },
            axisLine: {
                show: true,
                lineStyle: {
                    color: 'rgba(102, 102, 102, 0.3)',
                }
            },
            splitLine: {
                lineStyle: {
                    color: 'rgba(102, 102, 102, 0.1)',
                }
            },
        }],
        series: [{
            name: '总里程',
            data: totalMileages,
            type: "bar",
            barMaxWidth: "auto",
            barWidth: 30,
            itemStyle: {
                color: {
                    x: 0,
                    y: 0,
                    x2: 0,
                    y2: 1,
                    type: "linear",
                    global: false,
                    colorStops: [{
                        offset: 0,
                        color: "#1cd389"
                    }, {
                        offset: 0.5,
                        color: "#50a3ba"
                    }, {
                        offset: 1,
                        color: "#668eff"
                    }]
                }
            }
        }, {
            data: totalMileages.map(() => 1),
            type: "pictorialBar",
            barMaxWidth: "20",
            symbolOffset: [0, "50%"],
            symbolSize: [30, 10],
            itemStyle: {
                color: "#668eff"
            }
        }, {
            data: totalMileages,
            type: "pictorialBar",
            barMaxWidth: "20",
            symbolPosition: "end",
            symbolOffset: [0, "-50%"],
            symbolSize: [30, 8],
            zlevel: 2,
            itemStyle: {
                color: "#1cd389"
            }
        }, {
            name: '平均里程',
            type: 'line',
            showAllSymbol: true,
            lineStyle: {
                color: "#d94e5d",
                width: 3
            },
            showSymbol: true,
            symbol: 'circle',
            symbolSize: 12,
            itemStyle: {
                normal: {
                    color: "#fff",
                    borderColor: '#d94e5d',
                    borderWidth: 3
                }
            },
            data: avgMileages,
            yAxisIndex: 1,
        }]
    };

    chart.setOption(option);
}

// 模拟机型里程数据
function getMockAircraftMileageData() {
    return [
        {
            aircraftModel: '波音737(中)',
            totalMileage: 12500000,
            flightCount: 8500,
            avgMileage: 1470.59
        },
        {
            aircraftModel: '空客320(中)',
            totalMileage: 9800000,
            flightCount: 6200,
            avgMileage: 1580.65
        },
        {
            aircraftModel: '波音777(大)',
            totalMileage: 15600000,
            flightCount: 4100,
            avgMileage: 3804.88
        },
        {
            aircraftModel: 'ERJ-190(中)',
            totalMileage: 4200000,
            flightCount: 3800,
            avgMileage: 1105.26
        },
        {
            aircraftModel: '空客321(中)',
            totalMileage: 6800000,
            flightCount: 3500,
            avgMileage: 1942.86
        },
        {
            aircraftModel: 'CRJ(小)',
            totalMileage: 2100000,
            flightCount: 2800,
            avgMileage: 750.00
        },
        {
            aircraftModel: '波音787(大)',
            totalMileage: 8900000,
            flightCount: 2200,
            avgMileage: 4045.45
        },
        {
            aircraftModel: '空客319(中)',
            totalMileage: 3600000,
            flightCount: 2100,
            avgMileage: 1714.29
        }
    ];
}

// 获取市场指标数据
function fetchMarketData() {
    fetch('http://localhost:8080/market', {
            headers: {
                'jwt': localStorage.getItem('jwt')
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('网络响应不正常');
            }
            return response.json();
        })
        .then(data => {
            renderMarketCharts(data);
        })
        .catch(error => {
            console.error('获取市场指标数据出错:', error);
            const mockData = getMockMarketData();
            renderMarketCharts(mockData);
        });
}

// 获取航司辐射区域数据
function fetchAirlineLocationData() {
    fetch('http://localhost:8080/core/airline-location', {
            headers: {
                'jwt': localStorage.getItem('jwt')
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('网络响应不正常');
            }
            return response.json();
        })
        .then(result => {
            console.log('航司辐射区域原始数据:', result);
            // 检查返回的数据格式，处理Result类型
            if (result && result.data && Array.isArray(result.data)) {
                console.log('使用后端返回的航司辐射区域数据:', result.data);
                renderAirlineRadiationChart(result.data);
            } else if (result && Array.isArray(result)) {
                console.log('使用后端返回的航司辐射区域数据:', result);
                renderAirlineRadiationChart(result);
            } else {
                console.warn('后端返回的数据格式不正确，使用模拟数据');
                const mockData = getMockAirlineLocationData();
                renderAirlineRadiationChart(mockData);
            }
        })
        .catch(error => {
            console.error('获取航司辐射区域数据出错:', error);
            const mockData = getMockAirlineLocationData();
            renderAirlineRadiationChart(mockData);
        });
}

// 模拟航司辐射区域数据
function getMockAirlineLocationData() {
    return [
        {
            airlineName: '中国国航',
            avgLatitude: 39.9042,
            avgLongitude: 116.4074,
            flightCount: 2580
        },
        {
            airlineName: '东方航空',
            avgLatitude: 31.2304,
            avgLongitude: 121.4737,
            flightCount: 2340
        },
        {
            airlineName: '南方航空',
            avgLatitude: 23.1291,
            avgLongitude: 113.2644,
            flightCount: 2120
        },
        {
            airlineName: '海南航空',
            avgLatitude: 20.0311,
            avgLongitude: 110.3312,
            flightCount: 1890
        },
        {
            airlineName: '四川航空',
            avgLatitude: 30.5728,
            avgLongitude: 104.0668,
            flightCount: 1650
        },
        {
            airlineName: '深圳航空',
            avgLatitude: 22.5431,
            avgLongitude: 114.0579,
            flightCount: 1420
        },
        {
            airlineName: '厦门航空',
            avgLatitude: 24.4798,
            avgLongitude: 118.0894,
            flightCount: 1280
        },
        {
            airlineName: '山东航空',
            avgLatitude: 36.6519,
            avgLongitude: 117.1205,
            flightCount: 1150
        }
    ];
}

// 渲染航司辐射区域图表
function renderAirlineRadiationChart(data) {
    const chartDom = document.getElementById('airline-radiation-chart');
    if (!chartDom) return;
    
    const chart = echarts.init(chartDom);
    geoCharts.airlineRadiation = chart;
    
    // 航司logo图标
    var img2 = 'image://data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGUAAAAxCAYAAADDY2cuAAAPBUlEQVR4Xu1ca4xd11X+9uuccx/z8sx4PK0Te4idxJYIKY6QIpAYSFWVquFHW6MEhKoghAAJhBAvp9DGSVwifsAfpEooapVUNLFpg5AKrZAgU9qQJvE4Tpq4SWslE9u1x573zL33PPYLrX3OHY8fjRzVUkzvXM3xGXnunbl3f2etb61vffswbD5uuBVg7/qOvP/xP2fM33Cf5kZ6Qz/B2l256P4hPonPcWBGAh25hkTU0OYWgsUoXIrcGdxsUiyZE3jdAvsdNgG6eDl4z/dhWvRhWFxAR9aq9aMntGB9AzXr0DArWLVh/dhv2MuvpUtB8V5MYkYtYzkRiGsCPAG84hCCXuhgLcC0h005os4CkJ/ELg3G3I10kb5v78V7tg/TUkNFCaLEw9QleAxI6WA4h3QMXFsg9zCpxUAKnNXT2Gc2XtgXQQkR8ukoR6fuwfsd7IBEXHcwMQfjFvAECOBSD6wxmJUUrvUqFnOwXzHv20LcSH/Ye74LJ9U2pHUH2e/B+h18g4PFDCxc2AysAHyWA2sCenkArvWfuCMDY+sRsw7KpPdyGcebCZJBBr71wytDH/4F33d/xNgo/bJAIC6c3JvzneW//86P3jx7wbRt5owrHP2k5BjXY0HDeXlZeDBIMBFz2egT0b13bhnfv2dkZy3iyjMwRnjQ8ngUZ7n+nyf6z39Rw56V4AuncWZtBpN5N1o2gPJ2soZ0SEBs/cjKwMc/JkYeeuKHsyvvtPPCO+adcZ5Z5q2BW1rV+gdnWp3Oiil85pw3zsF5D3hPf7WnOIbRYnP6YkwyziPBRV3I8dE42bmtVotiziE8Z5RuJGM1xfl9E1sHeIyj/zB46i8MilmFeP453Na6FBTv2SRONDoQowJ+/MHlnf/09ZnFsX+dmV+zOZzNvXUa3mvnXG6sSb12bW1cx1qnnfGFpTjxcIRIrxVlFAOEC2cQnDHFhUi4lA0peJ0rnkhJQDEJxmMIGTPRXxPi6V++ffsh//b955rFawbywjReWeqSfhkp3rM7cXxAojYm4ccfWZn4l8deOVMcP9dOTdtb3XbGZtagMNYX1rjUWJ874zJjvbEOdFiChdJiD5bKjFGCYpCcokXwRHEWS8ESIVkUDsEiKVRTSNmAVDUmnrrn9u1P6fMHToys/ZdF7VwNEwtTjAVuXgfll/C9QYNkG4cbP7gyceTz06eyY6fbbb3mdTFfFLajCwIFmg7rPJ0L42ApdVXpyxKfUBrrktCNxMLX+b2sJ/4ACMB4AAWCcyjOmZICMRWuXCBSBJSUQyqOBkQUNZk8/NHbb37anD/w2kjrWQE+m6E1N83u0leA4hFt1bBbD63c8syjL5xJj8202sVSkRcLRebbWqPQBEQJjNEOxCXW0LlMXZ7SVw8+CBAifMGoe2CQkkMKDikFSnAEEiXVUBJHW2Si+rn66r17dh42F/78ldGVKQt+AejMXwHKPkz3CzS3ABg+tLzzPx7+zun02Mzaml7Mc72YZ75dVKBog0K7EhhHZwdnPCyBEnilt4ieOnfBGRgHJLUisgsKRQgPoERKohZJORjHcjhKogEVPfOJvRPPZBf++OXxxW9lMAsD+NDSFenrDrxaV1D9AqzvgbfG//0LL86yH55ZbemlPLdLee7bOYFikFOkaIu8oCgJqSwAYojsKXW58NUTj1ANc7oIWeivqcYiYJTkUBFHTIBEApGUSGIhCJTBKJEDcfzYRyY+eFSt/t5rE63vAsnKNKZblxI9gL3+9aiGpCbBkgtf6jw+t6R35itp7taK3K6mBTpaI88pfRlkhYUuHLS1MMZBOw9rHXwApLdSGKd+kFIXpTDGEVWREikCQyCO6JBIIiX6a4o1o5j3J9G24chu7BYPDE76HxRIs2nsS6/oU+C9+DWclCkK9dzf5Y/bjrmVdfLCUZ/SyjXSTCMrSkAKOqqIKaj6ovTlXai+Aig9hAsnkhcMAhQtJZcoxQPJEzAlIOFgjZrizTjytVgmN+M3f/a3srcLRGaj1LJBZgmKMAOmOD848IRPi1uRUdrKDNpZEQBJMwKFOKUCRjuUoJAsdpFTeiJ3bfiQoUehkjhiAZRIEBgXQamRlBgpNCPF6jWFWqJQj6J4KPpU9idvvAPs9xv1w6tL83/90peR6d1oZxQhBdq5QZ5pdAqDnL4vLDICJhA+pTHiF4qWild6CBXmGbgsKy8qiYncpeKoUfqKBJK4ipREoh4r1AmQRKEWReDykzj08+9cvlpXB+XAS08iK3ajkxVIU41OrtGhKKFDG6SFLfmFgOk2jyQeU0lMvNJDDSSnPqUqhyltEaeokLbKUrgW00FET2AQMBFqNfo+QsI/iYN3nbp2UNJ8FzodjXZeoBMipkxfaeAVg5wAyV1oIEP66lZgvUQopexb9iiCQRGnKI4kEDwPwBAg4aDoCOcIjZpCg0ARn7p2UP7qhSdBoBCXdKpIoYghfsm1QZZTSWyQGRdSWGgkrS+llqos7pUM1iV5SWWxLNMXHXEsEMsuIBKNpASmTF9Reaj3CEonvyUAEiKFgKHURVVXLELaovTVqJWR0qT0FRMo+99bpKyDQtFCJJ+ZcKYoIVLoTGVxIHtdpi+qwHqmc+ymgquBIstIIT6hcrhO4FDKut6gUJ9C6WsTlMsS8yYoNyBTbYKyCUpJ9BWnbKavH3NBvJ+Rskn0/w9AoZKYyuHN6qtsHC8pibvVV7ckvl7VVzvbhTR083SYILdcbB4r/auomscgtVTNI5XFPfSgWUro6PmGjj6oxKVCXHbxspRYfpLm8cALT6Kjd6FDc5TQo2ikqUGaVzJL6Owt8qAS02yFdC+a1ZNq31ug0PVXyvYMghpHUomrjp5EyXgjKDEpxBFIKW6+V5klCJI5qcQVKNU8hbSvILNkJLOU00cSJEPzSPMUQ26zHgMliJHlLCXILARKXEVKECTDKDhES5BZut18AOUaBMnSKc7wN9NPsjzf7UliaacaaUFq8YZIWVeIS1GSjBM0eSSZxV3hV/7pzmXrQ64qfUU0Cg5yC8n2pVoc0leQ8EmMlKwRR54EyYF4P/7sjncu92JvHHKtu8W//ejil3xW7PatIkc7LcJ8vjt5TDMid1KKy9RVipEXZZZemc9vUFnKGT2BQi4WAoXSF5E9yfdVpNDkkUTIZjV9rEdRYzvuu+l36m+fwF57VS/xPn9UDWN7tIaF+Pv/qB9PV/WEXc0Kv5bntkXcUlTjYEpdJEhWmhcBQkMuR0RPJN9Ds5QuMGQxCtYiGnRVgISZSjWjT0iQjCTrSyKaz/NmHNcHkmjwFvbpbffWT24B8m9gV3GFbfVuPJ9IjDY1TOPO/+078s03FvvOnW117HKR2eWMxsI6kHsYB9OMXpP/q5ylkHGCVemrFwXJbqTQ9FEpihjye1WRQtFCEn6ixEAcicEkFgNxfN9d4yPzo9nvLu8tjjvw1nO4rd1NY+sOyV/Em80MdkhADn12/qZvfv6509nxk8ureqnIzEKe+aAQk+eLCJ5ME5S+yPtVlcM0Rwner17LX1R9kb2ockfKMOwSwWLUdbOQxagWSzmUxGI4TqLBOPnKJ/ZOfN0s/OGrH1j+tgVfehGzK90tJeugTOL4QI6+EUBvfXh54t8eef5M59hbK61iIc/0fJb6FpnxjAuer9LNUrojdXBJktu+3FNE6atXCjCyq4I2OnQtRmRdrYheknmCzHiUxoJDUqnhOFbDSU0Nqfhrv75n4oid/9PXRtMpi3TOIF+8wiF5N04MeagxwI49svIzX330xVPpsZl2q1go8mI+T33HlLMUAiX4iYNdlXxf5IqkHqV0R/aGk3hjRVmBQmNhms/T1ocuMJwipgQlVlKRO3IkTuJBro58bM/OI3buL783sjLFIc5nuG1umtGmrA0GbwLFAOMSctvDKzsPHzp6Knv5VLuVr1it53Vmg22VGsXKxVICUhq8ieCpPyEvcdhW1COtCjkkQ7TQ/hTq7InoZWXyJl4hDxidlWCJlBQp8ZCMo37Iwx/ds+OwOf/gqyPtZzn4bIFbL1wBSpm+6tsY/AfIdf+3x0/lL/+o3TEtWN2yhetY47W2PrfW5yZsgyjd91QWEygECFVeFSC90NmHDUMVMKECY5xRpCjJeSIEi4VkFCUqbIWQakBK1WBKNZl4+p7bb3rKzh14fUv63wX07FUN3kT0HmIrgxv/zPLNX/vim+ejb51Z6ZjcW5vC0hY6b7ylTUM+tcZ0jPEdQ/9vw04uipJec0eWiJT/kP4lOWeSc55wKepSsLqQMpGSQOGKc5FAyBoTMgL/2q/uvekLbvb33xpY+26K7PzL+NBit1dZbx7v9qdrDovDCo2x314e/aMxre578NjMhflUG1eAAKGtdd4VsDa1Rq8ZY1OrXeos7fBCqUP25oy+1EEYAYKIc0k7uZpSyqZQvMaFkGBM0NY7MKkYf2DX2OA92wfbn+2bud9BnCvA5qbx5TWwh0Lpug7KPu+VwBv9tBVCQmz7g6Xxz+yJ6/dktBGI1puVeYkKq1dmW53Hps6cnZ0rcpuXEQR6HiOZ5adbVbnqpwubUcm2Ck4RUW8K+fGf2zL0wJ3bRhoxD7uCw0ZVBiSCsyWjT/+zm334+4PZUQM3F6Fv+Xlspx3CYY0vl1mSGINNBjNkwQdruR8ea6sPMsY459wxy4xwyNLULp442zo3f86srp2NsvaZ3CLuFXZ/l4tOxWLLDqcGd0T1HaNsdPtQY8wL17TMRxQp9MqOsMtzzfSsA19xkEsAVmvY1enuTbkUFACT/lm5iC2xQlKLoRoO7bpEFFmYal8yN92N+TF8S6IvncJL+mp3TejBeAl7R+nmBgmaiYGuO8QNQNcUoBxYdXMDujkEMo2iTTeIWEORncBeukHEesl6+R0nQn23CSelgI22wCqGWOYoRB1ABu8dpAGkjnC+uNzC35NAXP6hvRe78A25HTtUDkTd9UvAmYG2BpEF1nSEsSLGdj0FkBh5SQ9xdYP3xZu9BAqb3JDmpkqG6R69tZXuWq+6sH4HGbCXTWKUAZPVK6cwhUkHHATwOdr+cNWG7t3vYnStb2Lzedd1BTZBua7LeX1+2f8ByDqSeffFKG8AAAAASUVORK5CYII=';
    var mapName = 'china';
    
    // 转换数据格式
    var convertedData = data.map(item => ({
        name: item.airlineName,
        value: item.flightCount
    }));
    
    // 转换工具提示数据
    var toolTipData = data.map(item => ({
        name: item.airlineName,
        value: item.flightCount,
        latitude: item.avgLatitude,
        longitude: item.avgLongitude
    }));
    
    // 地理坐标映射
    var geoCoordMap = {};
    data.forEach(item => {
        geoCoordMap[item.airlineName] = [item.avgLongitude, item.avgLatitude];
    });
    
    // 加载地图数据
    chart.showLoading();
    fetch('https://geo.datav.aliyun.com/areas_v3/bound/100000_full.json')
        .then(response => response.json())
        .then(geoJson => {
            echarts.registerMap(mapName, geoJson);
            chart.hideLoading();
            
            // 转换数据格式
            var convertData = function (data) {
                var res = [];
                for (var i = 0; i < data.length; i++) {
                    var geoCoord = geoCoordMap[data[i].name];
                    if (geoCoord) {
                        res.push({
                            name: data[i].name,
                            value: geoCoord.concat(data[i].value),
                        });
                    }
                }
                return res;
            };
            
            // 柱状体的主干
            function lineData() {
                return toolTipData.map((item) => {
                    return {
                        coords: [geoCoordMap[item.name], [geoCoordMap[item.name][0], geoCoordMap[item.name][1] + 1.5]]
                    }
                })
            }
            
            // 柱状体的顶部
            function scatterData() {
                return toolTipData.map((item) => {
                    return [geoCoordMap[item.name][0], geoCoordMap[item.name][1] + 2, item]
                })
            }
            
            var option = {
                backgroundColor: "#003366",
                title: {
                    show: true,
                    text: "航司辐射区域分布图",
                    x: 'center',
                    top: "10",
                    textStyle: {
                        color: "#fff",
                        fontFamily: "等线",
                        fontSize: 18,
                    },
                },
                tooltip: {
                    trigger: 'item',
                    confine: true,
                    formatter: function (params) {
                        // 处理不同series的数据格式
                        var name, value, latitude, longitude;
                        
                        if (params.seriesName === '航司辐射') {
                            // effectScatter series的数据格式: {name, value: [lng, lat, count]}
                            name = params.name;
                            value = Array.isArray(params.value) ? params.value[2] : params.value;
                            longitude = Array.isArray(params.value) ? params.value[0] : null;
                            latitude = Array.isArray(params.value) ? params.value[1] : null;
                        } else if (params.data && params.data[2]) {
                            // scatter series的数据格式: [lng, lat, itemObject]
                            var itemData = params.data[2];
                            name = itemData.name;
                            value = itemData.value;
                            latitude = itemData.latitude;
                            longitude = itemData.longitude;
                        } else {
                            // 其他情况的处理
                            name = params.name;
                            value = Array.isArray(params.value) ? params.value[2] : params.value;
                            latitude = null;
                            longitude = null;
                        }
                        
                        // 确保数值格式正确
                        if (typeof value === 'string') {
                            // 处理可能的数字字符串，如 "111,85,29,09,239"
                            var parts = value.split(',');
                            if (parts.length > 1) {
                                value = parseInt(parts[0]) || value;
                            }
                        }
                        
                        return `<div style="padding: 12px; font-size: 14px; line-height: 1.6;">
                            <div style="color: #2c5aa0; font-weight: bold; margin-bottom: 10px; border-bottom: 1px solid #e8e8e8; padding-bottom: 6px;">
                                ✈️ ${name}
                            </div>
                            <div style="margin-bottom: 6px;">
                                📊 航班数量: <strong style="color: #e74c3c;">${value}架次</strong>
                            </div>
                            ${latitude && longitude ? `
                            <div style="margin-bottom: 6px;">
                                📍 辐射中心: <span style="color: #27ae60;">${latitude.toFixed(2)}°N, ${longitude.toFixed(2)}°E</span>
                            </div>` : ''}
                            <div style="font-size: 12px; color: #7f8c8d; margin-top: 10px; font-style: italic;">
                                💡 鼠标拖拽或滚轮缩放地图
                            </div>
                        </div>`;
                    },
                    backgroundColor: "rgba(255,255,255,0.96)",
                    borderColor: "#2c5aa0",
                    borderWidth: 2,
                    padding: [0, 0],
                    textStyle: {
                        color: "#333"
                    },
                    extraCssText: "box-shadow: 0 6px 20px rgba(0,0,0,0.25); border-radius: 10px; backdrop-filter: blur(5px);"
                },
                geo: {
                    map: mapName,
                    layoutCenter: ['50%', '50%'],
                    layoutSize: '160%',
                    roam: true,
                    zoom: 0.8,
                    aspectScale: 1,
                    label: {
                        normal: {
                            show: true,
                            fontSize: 10,
                            color: '#fff',
                            fontWeight: 'normal'
                        },
                        emphasis: {
                            show: true,
                            fontSize: 12,
                            color: '#fff',
                            fontWeight: 'bold'
                        }
                    },
                    itemStyle: {
                        normal: {
                            areaColor: {
                                type: "linear",
                                x: 1200,
                                y: 0,
                                x2: 0,
                                y2: 0,
                                colorStops: [{
                                    offset: 0,
                                    color: "rgba(3,27,78,0.85)",
                                }, {
                                    offset: 1,
                                    color: "rgba(58,149,253,0.85)",
                                }],
                                global: true,
                            },
                            borderColor: "#c0f3fb",
                            borderWidth: 1.5,
                            shadowColor: "#8cd3ef",
                            shadowOffsetY: 8,
                            shadowBlur: 25,
                        },
                        emphasis: {
                            areaColor: "rgba(0,254,233,0.6)",
                            shadowBlur: 35,
                            shadowColor: "#8cd3ef"
                        }
                    }
                },
                series: [
                    // 柱状体的主干
                    {
                        type: 'lines',
                        zlevel: 5,
                        effect: {
                            show: false,
                            symbolSize: 5
                        },
                        lineStyle: {
                            width: 6,
                            color: 'rgba(249, 105, 13, .6)',
                            opacity: 1,
                            curveness: 0
                        },
                        label: {
                            show: 0,
                            position: 'end',
                            formatter: '245'
                        },
                        silent: true,
                        data: lineData()
                    },
                    // 柱状体的顶部
                    {
                        type: 'scatter',
                        coordinateSystem: 'geo',
                        zlevel: 5,
                        label: {
                            normal: {
                                show: false,  // 默认隐藏标签，减少重叠
                                formatter: function (params) {
                                    var name = params.data[2].name
                                    var value = params.data[2].value
                                    var text = `{tline|${name}} : {fline|${value}}架次`
                                    return text;
                                },
                                color: '#fff',
                                rich: {
                                    fline: {
                                        color: '#fff',
                                        fontSize: 12,
                                        fontWeight: 600
                                    },
                                    tline: {
                                        color: '#ABF8FF',
                                        fontSize: 10,
                                    },
                                }
                            },
                            emphasis: {
                                show: true,  // 鼠标悬停时显示
                                fontSize: 14,
                                fontWeight: 'bold',
                                backgroundColor: 'rgba(0,0,0,0.7)',
                                padding: [4, 8],
                                borderRadius: 4
                            }
                        },
                        itemStyle: {
                            color: '#00FFF6',
                            opacity: 1
                        },
                        symbol: img2,
                        symbolSize: function(data) {
                            // 根据航班数量动态调整图标大小，避免过度重叠
                            var value = data[2].value;
                            var maxValue = Math.max(...toolTipData.map(item => item.value));
                            var minSize = 40;
                            var maxSize = 80;
                            var size = minSize + (value / maxValue) * (maxSize - minSize);
                            return [size * 1.4, size * 0.8];
                        },
                        symbolOffset: [0, -15],
                        z: 999,
                        data: scatterData(),
                    },
                    {
                        name: '航司辐射',
                        type: 'effectScatter',
                        coordinateSystem: 'geo',
                        data: convertData(toolTipData),
                        showEffectOn: 'render',
                        itemStyle: {
                            normal: {
                                color: '#00FFFF',
                            }
                        },
                        rippleEffect: {
                            scale: 3,
                            brushType: 'stroke',
                            period: 6,
                        },
                        label: {
                            normal: {
                                formatter: '{b}',
                                position: 'bottom',
                                show: false,
                                color: "#fff",
                                distance: 10,
                            },
                        },
                        symbol: 'circle',
                        symbolSize: function(val) {
                            // 根据航班数量调整散点大小
                            var value = val[2];
                            var maxValue = Math.max(...toolTipData.map(item => item.value));
                            var minSize = 8;
                            var maxSize = 16;
                            var size = minSize + (value / maxValue) * (maxSize - minSize);
                            return [size * 1.2, size * 0.8];
                        },
                        itemStyle: {
                            normal: {
                                color: '#16ffff',
                                shadowBlur: 10,
                                shadowColor: '#16ffff',
                            },
                            opacity: 1
                        },
                        zlevel: 4,
                    },
                ],
            };
            
            chart.setOption(option);
        })
        .catch(error => {
            console.error('无法加载地图数据:', error);
            chart.hideLoading();
            chartDom.innerHTML = '<div style="text-align:center;line-height:650px;color:red;">地图数据加载失败，请检查网络连接</div>';
        });
}

function fetchAndRenderSunburst() {
    console.log('fetchAndRenderSunburst 被调用');
    fetch('http://localhost:8080/time', {
        headers: {
            'jwt': localStorage.getItem('jwt')
        }
    })
        .then(res => res.json())
        .then(data => {
            const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
            const delay = data.delay || [];
            const distribution = data.distribution || [];
            const punctuality = data.punctuality || [];

            // --- 修改开始 ---
            const sunburstData = days.map(day => {
                const delayObj = delay.find(d => d.dayOfWeek && d.dayOfWeek.toLowerCase().includes(day.toLowerCase()));
                const distObj = distribution.find(d => d.dayOfWeek && d.dayOfWeek.toLowerCase().includes(day.toLowerCase()));
                const punctObj = punctuality.find(d => d.dayOfWeek && d.dayOfWeek.toLowerCase().includes(day.toLowerCase()));

                // 安全地获取数值
                const flightCount = (distObj && distObj.flightCount != null) ? distObj.flightCount : 0;
                const punctualFlights = (punctObj && punctObj.punctualFlights != null) ? punctObj.punctualFlights : 0;

                return {
                    name: day,
                    children: [
                        {
                            name: '航班量',
                            value: flightCount
                        },
                        {
                            name: '准点数',
                            value: punctualFlights
                        }
                    ]
                };
            });
            var chartDom = document.getElementById('sunburst-chart');
            chartDom.style.width = '600px';
            chartDom.style.height = '400px';
            var chart = echarts.init(chartDom);
            var option = {
                // title: { text: '每周航班统计旭日图', left: 'center' }, // 已去掉标题
                tooltip: {
                    trigger: 'item',
                    formatter: function(params) {
                        return params.treePathInfo.map(x => x.name).join(' > ') + ': ' + (params.value !== undefined ? params.value : '');
                    }
                },
                series: {
                    type: 'sunburst',
                    data: sunburstData,
                    center: ['50%', '50%'],
                    radius: ['15%', '85%'],
                    label: {
                        rotate: 'radial',
                        fontSize: 12,
                        formatter: function(params) {
                            const data = params.data;
                            const name = data.name || '';
                            if (data.children) {
                                return name;
                            }
                            return name + '\n' + data.value;
                        }
                    }
                }
            };
            chart.setOption(option);
            if (!window.timeCharts) window.timeCharts = {};
            window.timeCharts['sunburst'] = chart;
        });
}

// 自动修复：添加空的 renderTimeCharts 防止报错
function renderTimeCharts(data) {
    // 渲染航班时间段分布饼图
    renderTimeSlotPieChart(data.flightTimeSlotStatsVOList || []);
    // 如有其他时间类图表，可在此处继续调用
}