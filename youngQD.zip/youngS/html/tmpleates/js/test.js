
// 模拟业务指标数据
function getMockCoreData() {
    return {
        "delayVO": [
            { "type": 1, "name": "乌鲁木齐航空", "avgDelay": "49.13" },
            { "type": 1, "name": "日本航空", "avgDelay": "11.43" },
            { "type": 2, "name": "哈密机场", "avgDelay": "53.62" },
            { "type": 2, "name": "格尔木机场", "avgDelay": "8.0" },
            { "type": 3, "name": "哈密-上海", "avgDelay": "180.00" },
            { "type": 3, "name": "北海-贵阳", "avgDelay": "6.00" }
        ],
        "prateVO": [
            { "name": "日本航空", "punctuality": "91.0" },
            { "name": "江西航空", "punctuality": "90.5" },
            { "name": "乌鲁木齐航空", "punctuality": "56.33" },
            { "name": "红土航空", "punctuality": "68.31" }
        ]
    };
}

// 模拟市场指标数据
function getMockMarketData() {
    return {
        "airlineCountVO": [
            { "airlineName": "联合航空", "count": 8 },
            { "airlineName": "重庆航空", "count": 17 },
            { "airlineName": "酷航", "count": 3 },
            { "airlineName": "夏威夷航空", "count": 3 },
            { "airlineName": "北欧航空", "count": 2 },
            { "airlineName": "桂林航空", "count": 4 },
            { "airlineName": "红土航空", "count": 13 }
        ],
        "cityCountVO": [
            { "cityName": "阿克苏", "count": 24 },
            { "cityName": "阿勒泰", "count": 3 },
            { "cityName": "安庆", "count": 8 },
            { "cityName": "包头", "count": 60 },
            { "cityName": "保山", "count": 11 },
            { "cityName": "北海", "count": 50 }
        ],
        "airportCountVO": [
            { "airportName": "阿克苏机场", "count": "24" },
            { "airportName": "阿勒泰机场", "count": "3" },
            { "airportName": "天柱山机场", "count": "8" },
            { "airportName": "二里半机场", "count": "60" },
            { "airportName": "保山机场", "count": "11" },
            { "airportName": "福成机场", "count": "50" }
        ],
        "top5VO": [
            { "airline": "南方航空", "coverage_rate": "37.04" },
            { "airline": "东方航空", "coverage_rate": "28.69" },
            { "airline": "中国国航", "coverage_rate": "25.57" },
            { "airline": "深圳航空", "coverage_rate": "21.77" },
            { "airline": "厦门航空", "coverage_rate": "19.07" }
        ],
        "posCountVO": [
            { "city": "阿克苏", "lat": 41.18834, "lng": 80.29384, "depCount": 24, "arrCount": 25 },
            { "city": "阿勒泰", "lat": 47.890137, "lng": 87.926216, "depCount": 3, "arrCount": 3 },
            { "city": "安庆", "lat": 30.537897, "lng": 117.05874, "depCount": 8, "arrCount": 6 },
            { "city": "包头", "lat": 40.647118, "lng": 109.84624, "depCount": 60, "arrCount": 56 },
            { "city": "保山", "lat": 25.12049, "lng": 99.17799, "depCount": 11, "arrCount": 8 },
            { "city": "北海", "lat": 21.47272, "lng": 109.12263, "depCount": 50, "arrCount": 43 }
        ]
    };
}