package com.youngheart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YoungSApplicationTests {

    @Test
    void contextLoads() {
    }

}
