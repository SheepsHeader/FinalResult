package com.youngheart.domain.vo.time;
//航班时刻表

public class FlightScheduleVO {
    
    private String flightNo;              // 航班号
    private String airline;               // 航空公司
    private String firstDepartureTime;    // 首次起飞时间
    private String lastArrivalTime;       // 最后到达时间

    // 无参构造函数
    public FlightScheduleVO() {
    }

    // 全参构造函数
    public FlightScheduleVO(String flightNo, String airline, String firstDepartureTime, String lastArrivalTime) {
        this.flightNo = flightNo;
        this.airline = airline;
        this.firstDepartureTime = firstDepartureTime;
        this.lastArrivalTime = lastArrivalTime;
    }

    // Getter和Setter方法
    public String getFlightNo() {
        return flightNo;
    }

    public void setFlightNo(String flightNo) {
        this.flightNo = flightNo;
    }

    public String getAirline() {
        return airline;
    }

    public void setAirline(String airline) {
        this.airline = airline;
    }

    public String getFirstDepartureTime() {
        return firstDepartureTime;
    }

    public void setFirstDepartureTime(String firstDepartureTime) {
        this.firstDepartureTime = firstDepartureTime;
    }

    public String getLastArrivalTime() {
        return lastArrivalTime;
    }

    public void setLastArrivalTime(String lastArrivalTime) {
        this.lastArrivalTime = lastArrivalTime;
    }

    @Override
    public String toString() {
        return "FlightScheduleVO{" +
                "flightNo='" + flightNo + '\'' +
                ", airline='" + airline + '\'' +
                ", firstDepartureTime='" + firstDepartureTime + '\'' +
                ", lastArrivalTime='" + lastArrivalTime + '\'' +
                '}';
    }
} 