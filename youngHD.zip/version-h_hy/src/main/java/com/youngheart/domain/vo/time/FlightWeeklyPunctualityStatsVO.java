package com.youngheart.domain.vo.time;

public class FlightWeeklyPunctualityStatsVO {
    private String dayOfWeek;
    private Integer punctualFlights;
    private Integer totalFlights;
    public String getDayOfWeek() { return dayOfWeek; }
    public void setDayOfWeek(String dayOfWeek) { this.dayOfWeek = dayOfWeek; }
    public Integer getPunctualFlights() { return punctualFlights; }
    public void setPunctualFlights(Integer punctualFlights) { this.punctualFlights = punctualFlights; }
    public Integer getTotalFlights() { return totalFlights; }
    public void setTotalFlights(Integer totalFlights) { this.totalFlights = totalFlights; }
} 