package com.youngheart.domain.vo.core;

import lombok.Data;

@Data
public class MileageRangeVO {
    private String mileageRange;  // 里程区间
    private Integer flightCount;  // 航班数
    private Double avgPunctuality;  // 平均准点率
    private Double avgDelay;  // 平均延迟时间

    public MileageRangeVO() {
    }

    public MileageRangeVO(String mileageRange, Integer flightCount, Double avgPunctuality, Double avgDelay) {
        this.mileageRange = mileageRange;
        this.flightCount = flightCount;
        this.avgPunctuality = avgPunctuality;
        this.avgDelay = avgDelay;
    }

    // Getters and Setters
    public String getMileageRange() {
        return mileageRange;
    }

    public void setMileageRange(String mileageRange) {
        this.mileageRange = mileageRange;
    }

    public Integer getFlightCount() {
        return flightCount;
    }

    public void setFlightCount(Integer flightCount) {
        this.flightCount = flightCount;
    }

    public Double getAvgPunctuality() {
        return avgPunctuality;
    }

    public void setAvgPunctuality(Double avgPunctuality) {
        this.avgPunctuality = avgPunctuality;
    }

    public Double getAvgDelay() {
        return avgDelay;
    }

    public void setAvgDelay(Double avgDelay) {
        this.avgDelay = avgDelay;
    }
} 