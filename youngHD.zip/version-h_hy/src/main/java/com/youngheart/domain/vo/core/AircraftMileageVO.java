package com.youngheart.domain.vo.core;

import lombok.Data;

@Data
public class AircraftMileageVO {
    private String aircraftModel;  // 机型
    private Long totalMileage;     // 总里程数
    private Integer flightCount;   // 航班数量
    private Double avgMileage;     // 平均里程数

    public AircraftMileageVO() {
    }

    public AircraftMileageVO(String aircraftModel, Long totalMileage, Integer flightCount, Double avgMileage) {
        this.aircraftModel = aircraftModel;
        this.totalMileage = totalMileage;
        this.flightCount = flightCount;
        this.avgMileage = avgMileage;
    }

    // Getters and Setters
    public String getAircraftModel() {
        return aircraftModel;
    }

    public void setAircraftModel(String aircraftModel) {
        this.aircraftModel = aircraftModel;
    }

    public Long getTotalMileage() {
        return totalMileage;
    }

    public void setTotalMileage(Long totalMileage) {
        this.totalMileage = totalMileage;
    }

    public Integer getFlightCount() {
        return flightCount;
    }

    public void setFlightCount(Integer flightCount) {
        this.flightCount = flightCount;
    }

    public Double getAvgMileage() {
        return avgMileage;
    }

    public void setAvgMileage(Double avgMileage) {
        this.avgMileage = avgMileage;
    }
} 