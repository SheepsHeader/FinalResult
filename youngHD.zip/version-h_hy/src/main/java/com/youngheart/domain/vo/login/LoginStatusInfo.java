package com.youngheart.domain.vo.login;

public class LoginStatusInfo {
    private Integer status;//表示登录状态
    private String jwt ;//登录成功返回的jwt令牌

    public LoginStatusInfo() {
    }

    public LoginStatusInfo(Integer status, String jwt) {
        this.status = status;
        this.jwt = jwt;
    }

    /**
     * 获取
     * @return status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * 设置
     * @param status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * 获取
     * @return jwt
     */
    public String getJwt() {
        return jwt;
    }

    /**
     * 设置
     * @param jwt
     */
    public void setJwt(String jwt) {
        this.jwt = jwt;
    }

    public String toString() {
        return "LoginStatusInfo{status = " + status + ", jwt = " + jwt + "}";
    }
}
