package com.youngheart.domain.vo.flight;

public class ProvinceFlightVO {
    private String provinceName;
    private Integer flightCount;
    private Integer departureCount;
    private Integer arrivalCount;

    public ProvinceFlightVO() {}

    public ProvinceFlightVO(String provinceName, Integer flightCount) {
        this.provinceName = provinceName;
        this.flightCount = flightCount;
    }

    public ProvinceFlightVO(String provinceName, Integer departureCount, Integer arrivalCount) {
        this.provinceName = provinceName;
        this.departureCount = departureCount;
        this.arrivalCount = arrivalCount;
        this.flightCount = (departureCount != null ? departureCount : 0) + (arrivalCount != null ? arrivalCount : 0);
    }

    public String getProvinceName() {
        return provinceName;
    }

    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName;
    }

    public Integer getFlightCount() {
        return flightCount;
    }

    public void setFlightCount(Integer flightCount) {
        this.flightCount = flightCount;
    }

    public Integer getDepartureCount() {
        return departureCount;
    }

    public void setDepartureCount(Integer departureCount) {
        this.departureCount = departureCount;
    }

    public Integer getArrivalCount() {
        return arrivalCount;
    }

    public void setArrivalCount(Integer arrivalCount) {
        this.arrivalCount = arrivalCount;
    }
} 