package com.youngheart.domain.vo.core;

public class AirlineAvgLocationVO {
    private String airlineName;
    private Double avgLatitude;
    private Double avgLongitude;
    private Integer flightCount;

    public AirlineAvgLocationVO() {}

    public AirlineAvgLocationVO(String airlineName, Double avgLatitude, Double avgLongitude, Integer flightCount) {
        this.airlineName = airlineName;
        this.avgLatitude = avgLatitude;
        this.avgLongitude = avgLongitude;
        this.flightCount = flightCount;
    }

    public String getAirlineName() {
        return airlineName;
    }

    public void setAirlineName(String airlineName) {
        this.airlineName = airlineName;
    }

    public Double getAvgLatitude() {
        return avgLatitude;
    }

    public void setAvgLatitude(Double avgLatitude) {
        this.avgLatitude = avgLatitude;
    }

    public Double getAvgLongitude() {
        return avgLongitude;
    }

    public void setAvgLongitude(Double avgLongitude) {
        this.avgLongitude = avgLongitude;
    }

    public Integer getFlightCount() {
        return flightCount;
    }

    public void setFlightCount(Integer flightCount) {
        this.flightCount = flightCount;
    }

    @Override
    public String toString() {
        return "AirlineAvgLocationVO{" +
                "airlineName='" + airlineName + '\'' +
                ", avgLatitude=" + avgLatitude +
                ", avgLongitude=" + avgLongitude +
                ", flightCount=" + flightCount +
                '}';
    }
} 