package com.youngheart.domain.vo.time;

public class FlightWeeklyDistributionStatsVO {
    private String dayOfWeek;
    private Integer flightCount;
    private Double percentage;
    public String getDayOfWeek() { return dayOfWeek; }
    public void setDayOfWeek(String dayOfWeek) { this.dayOfWeek = dayOfWeek; }
    public Integer getFlightCount() { return flightCount; }
    public void setFlightCount(Integer flightCount) { this.flightCount = flightCount; }
    public Double getPercentage() { return percentage; }
    public void setPercentage(Double percentage) { this.percentage = percentage; }
} 