package com.youngheart.domain.vo.time;

public class FlightWeeklyDelayStatsVO {
    private String dayOfWeek;
    private Double averageDelayMinutes;
    public String getDayOfWeek() { return dayOfWeek; }
    public void setDayOfWeek(String dayOfWeek) { this.dayOfWeek = dayOfWeek; }
    public Double getAverageDelayMinutes() { return averageDelayMinutes; }
    public void setAverageDelayMinutes(Double averageDelayMinutes) { this.averageDelayMinutes = averageDelayMinutes; }
} 