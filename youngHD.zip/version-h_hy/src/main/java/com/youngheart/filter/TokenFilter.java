package com.youngheart.filter;

import com.youngheart.utils.JwtUtils;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.util.Enumeration;

/**
 * 令牌校验过滤器
 */
@Slf4j
@WebFilter(urlPatterns = "/*")
public class TokenFilter implements Filter {

    @Override
    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) resp;
        //1. 获取请求url。
        String url = request.getRequestURL().toString();

        System.out.println("请求的url是："+url);
        // 在获取jwt头的代码之前添加以下调试代码
        System.out.println("所有请求头:");
        String method = request.getMethod();

        // 放行预检请求
        if (method.equals("OPTIONS")) {
            System.out.println("预检请求，直接放行");
            chain.doFilter(request, response);
            return;
        }

        // 放行登录请求
        if(url.contains("login")){
            System.out.println("登录操作，直接放行");
            chain.doFilter(request, response);
            return;
        }

        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String headerName = headerNames.nextElement();
            System.out.println(headerName + ": " + request.getHeader(headerName));
        }

        //2. 判断请求url中是否包含login，如果包含，说明是登录操作，放行。
        if(url.contains("login")){ //登录请求
            System.out.println("登陆操作，直接放行");
            chain.doFilter(request, response);
            return;
        }

        //3. 获取请求头中的令牌（token）。
        String jwt = request.getHeader("jwt");
        System.out.println("获取到jwt令牌是"+jwt);

        //4. 判断令牌是否存在，如果不存在，返回错误结果（未登录）。
        if(!StringUtils.hasLength(jwt)){ //jwt为空
            System.out.println("获取到jwt令牌为空, 返回错误结果"+jwt);
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED); // 使用HttpServletResponse常量
            return;
        }

        //5. 解析token，如果解析失败，返回错误结果（未登录）。
        try {
            JwtUtils.parseJWT(jwt);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("解析令牌失败, 返回错误结果");
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED); // 使用HttpServletResponse常量
            return;
        }

        //6. 放行。
        System.out.println("令牌合法, 放行");
        chain.doFilter(request, response);
    }
}