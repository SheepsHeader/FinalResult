package com.youngheart.controller;

import com.youngheart.domain.Result;
import com.youngheart.domain.vo.time.FlightScheduleVO;
import com.youngheart.service.FlightScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/flight-schedule")
public class FlightScheduleController {

    @Autowired
    private FlightScheduleService flightScheduleService;

    /**
     * 获取所有航班时刻表
     * GET /flight-schedule
     */
    @GetMapping
    public Result getAllFlightSchedules() {
        try {
            List<FlightScheduleVO> schedules = flightScheduleService.getAllFlightSchedules();
            return Result.success(schedules);
        } catch (Exception e) {
            e.printStackTrace();
            return Result.error("获取航班时刻表失败: " + e.getMessage());
        }
    }

    /**
     * 根据航班号获取航班时刻表
     * GET /flight-schedule/{flightNo}
     */
    @GetMapping("/{flightNo}")
    public Result getFlightScheduleByFlightNo(@PathVariable String flightNo) {
        try {
            FlightScheduleVO schedule = flightScheduleService.getFlightScheduleByFlightNo(flightNo);
            if (schedule != null) {
                return Result.success(schedule);
            } else {
                return Result.error("未找到航班号: " + flightNo);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.error("查询航班时刻表失败: " + e.getMessage());
        }
    }

    /**
     * 根据航空公司获取航班时刻表
     * GET /flight-schedule/airline/{airline}
     */
    @GetMapping("/airline/{airline}")
    public Result getFlightSchedulesByAirline(@PathVariable String airline) {
        try {
            List<FlightScheduleVO> schedules = flightScheduleService.getFlightSchedulesByAirline(airline);
            return Result.success(schedules);
        } catch (Exception e) {
            e.printStackTrace();
            return Result.error("查询航空公司航班时刻表失败: " + e.getMessage());
        }
    }

    /**
     * 获取所有航司
     * GET /flight-schedule/airlines
     */
    @GetMapping("/airlines")
    public Result getAllAirlines() {
        try {
            List<String> airlines = flightScheduleService.getAllAirlines();
            System.out.println("[DEBUG] 查询到的航司列表: " + airlines);
            return Result.success(airlines);
        } catch (Exception e) {
            e.printStackTrace();
            return Result.error("获取航司列表失败: " + e.getMessage());
        }
    }

    /**
     * 添加航班时刻表
     * POST /flight-schedule
     */
    @PostMapping
    public Result addFlightSchedule(@RequestBody FlightScheduleVO flightSchedule) {
        try {
            boolean success = flightScheduleService.addFlightSchedule(flightSchedule);
            if (success) {
                return Result.success("添加航班时刻表成功");
            } else {
                return Result.error("添加航班时刻表失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.error("添加航班时刻表失败: " + e.getMessage());
        }
    }

    /**
     * 更新航班时刻表
     * PUT /flight-schedule
     */
    @PutMapping
    public Result updateFlightSchedule(@RequestBody FlightScheduleVO flightSchedule) {
        try {
            boolean success = flightScheduleService.updateFlightSchedule(flightSchedule);
            if (success) {
                return Result.success("更新航班时刻表成功");
            } else {
                return Result.error("更新航班时刻表失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.error("更新航班时刻表失败: " + e.getMessage());
        }
    }

    /**
     * 删除航班时刻表
     * DELETE /flight-schedule/{flightNo}
     */
    @DeleteMapping("/{flightNo}")
    public Result deleteFlightSchedule(@PathVariable String flightNo) {
        try {
            boolean success = flightScheduleService.deleteFlightSchedule(flightNo);
            if (success) {
                return Result.success("删除航班时刻表成功");
            } else {
                return Result.error("删除航班时刻表失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.error("删除航班时刻表失败: " + e.getMessage());
        }
    }
} 