package com.youngheart.controller;

import com.youngheart.service.TimeStatsService;
import com.youngheart.domain.vo.time.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;

@RestController
@RequestMapping("/api/timeStats")
public class TimeStatsController {
    @Autowired
    private TimeStatsService service;

    @GetMapping("/weekly")
    public Map<String, Object> getWeeklyStats() {
        Map<String, Object> result = new HashMap<>();
        result.put("delay", service.getWeeklyDelayStats());
        result.put("distribution", service.getWeeklyDistributionStats());
        result.put("punctuality", service.getWeeklyPunctualityStats());
        return result;
    }
} 