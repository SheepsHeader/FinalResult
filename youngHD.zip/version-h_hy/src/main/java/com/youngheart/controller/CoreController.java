package com.youngheart.controller;

import com.youngheart.domain.Result;
import com.youngheart.domain.vo.core.CoreResult;
import com.youngheart.domain.vo.core.MileageRangeVO;
import com.youngheart.domain.vo.core.AircraftMileageVO;
import com.youngheart.domain.vo.core.AirlineAvgLocationVO;
import com.youngheart.service.CoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/core")
public class CoreController {

    @Autowired
    private CoreService coreService;

    @GetMapping
    public CoreResult core() {
        return coreService.getCoreInfo();
    }

    @GetMapping("/mileage-range")
    public List<MileageRangeVO> getMileageRangeStats() {
        return coreService.getMileageRangeStats();
    }

    @GetMapping("/aircraft-mileage")
    public List<AircraftMileageVO> getAircraftMileageStats() {
        return coreService.getAircraftMileageStats();
    }

    @GetMapping("/airline-location")
    public Result getAirlineAvgLocationStats() {
        List<AirlineAvgLocationVO> airlineLocationList = coreService.getAirlineAvgLocationStats();
        return Result.success(airlineLocationList);
    }

}
