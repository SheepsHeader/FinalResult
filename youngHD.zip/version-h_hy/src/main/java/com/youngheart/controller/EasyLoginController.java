package com.youngheart.controller;

import com.youngheart.domain.dto.LoginDTO;
import com.youngheart.domain.vo.login.LoginStatusInfo;
import com.youngheart.service.EasyLoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/login")
public class EasyLoginController {
    @Autowired
    private EasyLoginService easyLoginService;

    @PostMapping("/reg")
    public String reg(@RequestBody LoginDTO loginDTO) {
        easyLoginService.register(loginDTO);
        return "注册成功";
    }

    @PostMapping("/log")
    public LoginStatusInfo login(@RequestBody LoginDTO loginDTO) {
        LoginStatusInfo login = easyLoginService.login(loginDTO);
        System.out.println("前端传来的数据是"+loginDTO);
        System.out.println("返回获取的数据是"+login);
        return login;
    }
}
