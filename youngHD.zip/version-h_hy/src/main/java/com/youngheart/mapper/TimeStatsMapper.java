package com.youngheart.mapper;

import com.youngheart.domain.vo.time.FlightWeeklyDelayStatsVO;
import com.youngheart.domain.vo.time.FlightWeeklyDistributionStatsVO;
import com.youngheart.domain.vo.time.FlightWeeklyPunctualityStatsVO;
import java.util.List;

public interface TimeStatsMapper {
    List<FlightWeeklyDelayStatsVO> getWeeklyDelayStats();
    List<FlightWeeklyDistributionStatsVO> getWeeklyDistributionStats();
    List<FlightWeeklyPunctualityStatsVO> getWeeklyPunctualityStats();
} 