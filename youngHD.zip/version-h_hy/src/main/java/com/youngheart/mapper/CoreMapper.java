package com.youngheart.mapper;

import com.youngheart.domain.vo.core.DelayVO;
import com.youngheart.domain.vo.core.PrateVO;
import com.youngheart.domain.vo.core.MileageRangeVO;
import com.youngheart.domain.vo.core.AircraftMileageVO;
import com.youngheart.domain.vo.core.AirlineAvgLocationVO;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface CoreMapper {

    //获取航司的Top5和Bottom5延误信息
    @Select("(SELECT name, avg_delay\n" +
            "FROM airline_delay_info\n" +
            "ORDER BY avg_delay DESC\n" +
            "LIMIT 5)\n" +
            "UNION ALL\n" +
            "(SELECT name, avg_delay\n" +
            "FROM airline_delay_info\n" +
            "WHERE avg_delay > 0\n" +
            "ORDER BY avg_delay ASC\n" +
            "LIMIT 5)\n" +
            "ORDER BY avg_delay DESC;")
    List<DelayVO> getAirlineDelay();

    //获取机场的Top5和Bottom5延误信息
    @Select("(SELECT name, avg_delay\n" +
            "FROM airport_delay_info\n" +
            "ORDER BY avg_delay DESC\n" +
            "LIMIT 5)\n" +
            "UNION ALL\n" +
            "(SELECT name, avg_delay\n" +
            "FROM airport_delay_info\n" +
            "WHERE avg_delay > 0\n" +
            "ORDER BY avg_delay ASC\n" +
            "LIMIT 5)\n" +
            "ORDER BY avg_delay DESC;")
    List<DelayVO> getAirportDelay();

    //获取线路的最大和最小的延误信息
    @Select("SELECT name, avg_delay FROM (\n" +
            "  SELECT name, avg_delay FROM line_delay_info ORDER BY avg_delay DESC LIMIT 5\n" +
            ") t1\n" +
            "UNION ALL\n" +
            "SELECT name, avg_delay FROM (\n" +
            "  SELECT name, avg_delay FROM line_delay_info WHERE avg_delay > 0 ORDER BY avg_delay ASC LIMIT 5\n" +
            ") t2")
    List<DelayVO> getLineDelay();

    @Select(
        "SELECT name, avg_punctuality AS punctuality FROM (" +
        "  SELECT airline_name AS name, avg_punctuality FROM airline_avg_punctuality ORDER BY avg_punctuality DESC LIMIT 5" +
        ") t1 " +
        "UNION ALL " +
        "SELECT name, avg_punctuality AS punctuality FROM (" +
        "  SELECT airline_name AS name, avg_punctuality FROM airline_avg_punctuality ORDER BY avg_punctuality ASC LIMIT 5" +
        ") t2"
    )
    List<PrateVO> getPrate();

    //获取里程区间的综合数据
    @Select("SELECT " +
            "  mfn.mileage_range AS mileageRange, " +
            "  mfn.flight_count AS flightCount, " +
            "  map.avg_punctuality AS avgPunctuality, " +
            "  mad.avg_delay AS avgDelay " +
            "FROM mileage_range_flight_num mfn " +
            "LEFT JOIN mileage_range_avg_punctuality map ON mfn.mileage_range = map.mileage_range " +
            "LEFT JOIN mileage_range_avg_delay mad ON mfn.mileage_range = mad.mileage_range " +
            "ORDER BY mfn.flight_count DESC")
    List<MileageRangeVO> getMileageRangeStats();

    //获取机型的总里程数和平均里程数
    @Select("SELECT " +
            "  atm.aircraft_model AS aircraftModel, " +
            "  atm.total_mileage AS totalMileage, " +
            "  afn.flight_count AS flightCount, " +
            "  CASE " +
            "    WHEN afn.flight_count > 0 THEN ROUND(atm.total_mileage / afn.flight_count, 2) " +
            "    ELSE 0 " +
            "  END AS avgMileage " +
            "FROM aircraft_total_mileage atm " +
            "LEFT JOIN aircraft_flight_num afn ON atm.aircraft_model = afn.aircraft_model " +
            "ORDER BY atm.total_mileage DESC " +
            "LIMIT 10")
    List<AircraftMileageVO> getAircraftMileageStats();

    //获取各航司航班的平均经纬度
    @Select("SELECT " +
            "  a.airline_name AS airlineName, " +
            "  a.avg_lat AS avgLatitude, " +
            "  a.avg_long AS avgLongitude, " +
            "  c.count AS flightCount " +
            "FROM airline_avg_lat_long a " +
            "LEFT JOIN airline_cnt_info c ON a.airline_name = c.airline_name " +
            "ORDER BY c.count DESC " +
            "LIMIT 20")
    List<AirlineAvgLocationVO> getAirlineAvgLocationStats();

}
