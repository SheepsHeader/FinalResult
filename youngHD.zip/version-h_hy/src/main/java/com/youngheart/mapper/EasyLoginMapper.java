package com.youngheart.mapper;

import com.youngheart.domain.dto.LoginDTO;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;

public interface EasyLoginMapper {

    @Insert("insert into users(username, password) values(#{username}, #{password})")
    void insertUser(LoginDTO user);

    @Select("SELECT id, username, password FROM users WHERE username = #{username} AND password = #{password}")
    LoginDTO findUser(LoginDTO user);

}
