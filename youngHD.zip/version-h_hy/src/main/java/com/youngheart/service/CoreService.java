package com.youngheart.service;

import com.youngheart.domain.vo.core.CoreResult;
import com.youngheart.domain.vo.core.MileageRangeVO;
import com.youngheart.domain.vo.core.AircraftMileageVO;
import com.youngheart.domain.vo.core.AirlineAvgLocationVO;

import java.util.List;

public interface CoreService {
    public CoreResult getCoreInfo();
    
    /**
     * 获取里程区间综合统计数据
     * @return 里程区间统计数据列表
     */
    public List<MileageRangeVO> getMileageRangeStats();
    
    /**
     * 获取机型里程统计数据
     * @return 机型里程统计数据列表
     */
    public List<AircraftMileageVO> getAircraftMileageStats();
    
    List<AirlineAvgLocationVO> getAirlineAvgLocationStats();
}
