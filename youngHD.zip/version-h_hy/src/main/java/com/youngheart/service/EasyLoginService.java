package com.youngheart.service;

import com.youngheart.domain.dto.LoginDTO;
import com.youngheart.domain.vo.login.LoginStatusInfo;

public interface EasyLoginService {

    void register(LoginDTO user);

    LoginStatusInfo login(LoginDTO user);

}
