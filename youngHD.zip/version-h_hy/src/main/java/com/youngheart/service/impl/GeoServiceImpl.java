package com.youngheart.service.impl;

import com.youngheart.domain.vo.flight.GeoStatsResponseVO;
import com.youngheart.domain.vo.flight.ProvinceFlightVO;
import com.youngheart.mapper.GeoMapper;
import com.youngheart.service.GeoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class GeoServiceImpl implements GeoService {
    private final GeoMapper geoMapper;

    @Autowired
    public GeoServiceImpl(GeoMapper geoMapper) {
        this.geoMapper = geoMapper;
    }

    @Override
    public GeoStatsResponseVO getAllGeoStats() {
        GeoStatsResponseVO response = new GeoStatsResponseVO();
        response.setDepartureStats(geoMapper.getArrCount());
        response.setLandingStats(geoMapper.getLandCount());
        response.setRouteStats(geoMapper.getFlightCount());

        // 获取和合并省份数据
        List<ProvinceFlightVO> provinceStats = mergeProvinceData();
        response.setProvinceStats(provinceStats);

        return response;
    }

    private List<ProvinceFlightVO> mergeProvinceData() {
        List<ProvinceFlightVO> departureData = geoMapper.getProvinceDepartureCount();
        List<ProvinceFlightVO> arrivalData = geoMapper.getProvinceArrivalCount();

        Map<String, ProvinceFlightVO> provinceMap = new HashMap<>();

        // 处理起飞数据
        if (departureData != null) {
            for (ProvinceFlightVO item : departureData) {
                String provinceName = item.getProvinceName();
                ProvinceFlightVO vo = provinceMap.getOrDefault(provinceName, new ProvinceFlightVO());
                vo.setProvinceName(provinceName);
                vo.setDepartureCount(item.getFlightCount());
                provinceMap.put(provinceName, vo);
            }
        }

        // 处理降落数据
        if (arrivalData != null) {
            for (ProvinceFlightVO item : arrivalData) {
                String provinceName = item.getProvinceName();
                ProvinceFlightVO vo = provinceMap.getOrDefault(provinceName, new ProvinceFlightVO());
                vo.setProvinceName(provinceName);
                vo.setArrivalCount(item.getFlightCount());
                provinceMap.put(provinceName, vo);
            }
        }

        // 计算总航班数
        for (ProvinceFlightVO vo : provinceMap.values()) {
            Integer departure = vo.getDepartureCount() != null ? vo.getDepartureCount() : 0;
            Integer arrival = vo.getArrivalCount() != null ? vo.getArrivalCount() : 0;
            vo.setFlightCount(departure + arrival);
        }

        return new ArrayList<>(provinceMap.values());
    }
}