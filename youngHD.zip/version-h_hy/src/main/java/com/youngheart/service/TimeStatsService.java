package com.youngheart.service;

import com.youngheart.domain.vo.time.FlightWeeklyDelayStatsVO;
import com.youngheart.domain.vo.time.FlightWeeklyDistributionStatsVO;
import com.youngheart.domain.vo.time.FlightWeeklyPunctualityStatsVO;
import java.util.List;

public interface TimeStatsService {
    List<FlightWeeklyDelayStatsVO> getWeeklyDelayStats();
    List<FlightWeeklyDistributionStatsVO> getWeeklyDistributionStats();
    List<FlightWeeklyPunctualityStatsVO> getWeeklyPunctualityStats();
} 