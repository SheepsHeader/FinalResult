package com.youngheart.service.impl;

import com.youngheart.domain.dto.LoginDTO;
import com.youngheart.domain.vo.login.LoginStatusInfo;
import com.youngheart.mapper.EasyLoginMapper;
import com.youngheart.service.EasyLoginService;
import com.youngheart.utils.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class EasyLoginServiceImpl implements EasyLoginService {
    @Autowired
    private EasyLoginMapper easyLoginMapper;

    @Override
    public void register(LoginDTO user) {
        easyLoginMapper.insertUser(user);
    }

    @Override
    public LoginStatusInfo login(LoginDTO user) {
        LoginDTO loginDTO = easyLoginMapper.findUser(user);
        System.out.println("mapper返回的数据为"+loginDTO);
        if (loginDTO == null) {
            return null;
        }
        Map<String,Object> dataMap = new HashMap<>();
        dataMap.put("id", loginDTO.getId());
        dataMap.put("username", loginDTO.getUsername());
        String jwt = JwtUtils.generateJwt(dataMap);
        return new LoginStatusInfo(1, jwt);
    }
}
