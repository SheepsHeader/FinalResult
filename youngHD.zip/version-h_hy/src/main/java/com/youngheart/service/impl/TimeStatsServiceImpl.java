package com.youngheart.service.impl;

import com.youngheart.mapper.TimeStatsMapper;
import com.youngheart.service.TimeStatsService;
import com.youngheart.domain.vo.time.*;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;

@Service
public class TimeStatsServiceImpl implements TimeStatsService {
    @Autowired
    private TimeStatsMapper mapper;

    @Override
    public List<FlightWeeklyDelayStatsVO> getWeeklyDelayStats() {
        return mapper.getWeeklyDelayStats();
    }
    @Override
    public List<FlightWeeklyDistributionStatsVO> getWeeklyDistributionStats() {
        return mapper.getWeeklyDistributionStats();
    }
    @Override
    public List<FlightWeeklyPunctualityStatsVO> getWeeklyPunctualityStats() {
        return mapper.getWeeklyPunctualityStats();
    }
} 