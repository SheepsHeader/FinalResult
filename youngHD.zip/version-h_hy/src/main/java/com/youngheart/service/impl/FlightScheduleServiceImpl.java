package com.youngheart.service.impl;

import com.youngheart.domain.vo.time.FlightScheduleVO;
import com.youngheart.mapper.FlightScheduleMapper;
import com.youngheart.service.FlightScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FlightScheduleServiceImpl implements FlightScheduleService {

    @Autowired
    private FlightScheduleMapper flightScheduleMapper;

    @Override
    public List<FlightScheduleVO> getAllFlightSchedules() {
        return flightScheduleMapper.selectAllFlightSchedules();
    }

    @Override
    public FlightScheduleVO getFlightScheduleByFlightNo(String flightNo) {
        return flightScheduleMapper.selectByFlightNo(flightNo);
    }

    @Override
    public List<FlightScheduleVO> getFlightSchedulesByAirline(String airline) {
        return flightScheduleMapper.selectByAirline(airline);
    }

    @Override
    public boolean addFlightSchedule(FlightScheduleVO flightSchedule) {
        try {
            int result = flightScheduleMapper.insertFlightSchedule(flightSchedule);
            return result > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean updateFlightSchedule(FlightScheduleVO flightSchedule) {
        try {
            int result = flightScheduleMapper.updateFlightSchedule(flightSchedule);
            return result > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteFlightSchedule(String flightNo) {
        try {
            int result = flightScheduleMapper.deleteByFlightNo(flightNo);
            return result > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<String> getAllAirlines() {
        return flightScheduleMapper.getAllAirlines();
    }
} 