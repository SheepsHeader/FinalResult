create table airline_avg_punctuality
(
    airline_name    text   null,
    avg_punctuality double null
);

INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('日本航空', 0.91);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('江西航空', 0.905);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('酷航', 0.8933);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('香港航空', 0.8918);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('扬子江航空', 0.891);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('幸福航空', 0.8888);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('春秋航空', 0.8779);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('新西兰航空', 0.8769);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('全日空航空', 0.8728);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('重庆航空', 0.8647);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('大新华航空', 0.8626);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('北欧航空', 0.86);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('吉祥航空', 0.8576);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('澳洲航空', 0.8566);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('华夏航空', 0.8505);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('山东航空', 0.8457);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('青岛航空', 0.8433);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('西部航空', 0.8391);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('中国国航', 0.8379);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('西藏航空', 0.8334);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('北部湾航空', 0.831);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('深圳航空', 0.8299);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('东方航空', 0.8296);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('南方航空', 0.8295);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('四川航空', 0.8279);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('天津航空', 0.8217);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('海南航空', 0.8214);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('上海航空', 0.82);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('首都航空', 0.8162);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('瑞丽航空', 0.8141);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('长龙航空', 0.8126);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('昆明航空', 0.8126);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('东海航空', 0.8106);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('长安航空', 0.81);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('厦门航空', 0.8079);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('河北航空', 0.797);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('夏威夷航空', 0.7933);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('成都航空', 0.7861);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('英国航空', 0.7804);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('祥鹏航空', 0.7694);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('福州航空', 0.7641);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('多彩航空', 0.7458);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('联合航空', 0.7375);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('九元航空', 0.7368);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('桂林航空', 0.725);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('奥凯航空', 0.7213);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('红土航空', 0.6831);
INSERT INTO flight.airline_avg_punctuality (airline_name, avg_punctuality) VALUES ('乌鲁木齐航空', 0.5633);
