create table province_landing_num
(
    province_name varchar(50) null,
    flight_count  int         null
);

INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('广东省', 1609);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('云南省', 906);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('北京市', 894);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('上海市', 871);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('四川省', 778);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('山东省', 740);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('浙江省', 665);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('重庆市', 655);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('海南省', 627);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('辽宁省', 579);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('福建省', 560);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('陕西省', 555);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('江苏省', 506);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('新疆维吾尔自治区', 473);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('贵州省', 448);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('内蒙古自治区', 438);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('广西壮族自治区', 395);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('黑龙江省', 395);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('湖北省', 372);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('河南省', 360);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('天津市', 330);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('湖南省', 309);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('山西省', 279);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('甘肃省', 266);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('吉林省', 248);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('江西省', 167);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('河北省', 161);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('安徽省', 140);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('宁夏回族自治区', 136);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('西藏自治区', 111);
INSERT INTO flight.province_landing_num (province_name, flight_count) VALUES ('青海省', 96);
