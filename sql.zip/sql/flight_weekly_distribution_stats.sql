create table flight_weekly_distribution_stats
(
    day_of_week  text   null,
    flight_count bigint null,
    percentage   double null
);

INSERT INTO flight.flight_weekly_distribution_stats (day_of_week, flight_count, percentage) VALUES ('Thursday', 10447, 14.42);
INSERT INTO flight.flight_weekly_distribution_stats (day_of_week, flight_count, percentage) VALUES ('Monday', 10258, 14.16);
INSERT INTO flight.flight_weekly_distribution_stats (day_of_week, flight_count, percentage) VALUES ('Wednesday', 10288, 14.2);
INSERT INTO flight.flight_weekly_distribution_stats (day_of_week, flight_count, percentage) VALUES ('Friday', 10409, 14.37);
INSERT INTO flight.flight_weekly_distribution_stats (day_of_week, flight_count, percentage) VALUES ('Sunday', 10272, 14.18);
INSERT INTO flight.flight_weekly_distribution_stats (day_of_week, flight_count, percentage) VALUES ('Tuesday', 10369, 14.31);
INSERT INTO flight.flight_weekly_distribution_stats (day_of_week, flight_count, percentage) VALUES ('Saturday', 10402, 14.36);
