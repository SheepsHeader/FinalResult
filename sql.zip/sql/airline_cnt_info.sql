create table airline_cnt_info
(
    airline_name text             null,
    count        bigint default 0 not null
);

INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('中国国航', 1442);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('南方航空', 2553);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('厦门航空', 1000);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('海南航空', 982);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('山东航空', 779);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('天津航空', 463);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('祥鹏航空', 332);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('深圳航空', 1183);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('首都航空', 268);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('华夏航空', 565);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('东方航空', 1862);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('四川航空', 468);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('瑞丽航空', 46);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('吉祥航空', 278);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('成都航空', 219);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('春秋航空', 298);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('奥凯航空', 90);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('新西兰航空', 52);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('西藏航空', 212);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('联合航空', 8);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('重庆航空', 17);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('全日空航空', 18);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('昆明航空', 239);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('河北航空', 292);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('福州航空', 68);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('大新华航空', 50);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('香港航空', 17);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('长龙航空', 167);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('上海航空', 214);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('夏威夷航空', 3);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('东海航空', 133);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('澳洲航空', 67);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('幸福航空', 195);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('九元航空', 60);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('红土航空', 13);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('青岛航空', 40);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('多彩航空', 52);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('西部航空', 92);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('北部湾航空', 111);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('扬子江航空', 42);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('英国航空', 26);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('日本航空', 13);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('乌鲁木齐航空', 30);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('酷航', 3);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('桂林航空', 4);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('江西航空', 4);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('长安航空', 2);
INSERT INTO flight.airline_cnt_info (airline_name, count) VALUES ('北欧航空', 2);
