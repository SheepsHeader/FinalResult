create table mileage_range_avg_delay
(
    mileage_range varchar(50) null,
    avg_delay     int         null
);

INSERT INTO flight.mileage_range_avg_delay (mileage_range, avg_delay) VALUES ('3500+', 39);
INSERT INTO flight.mileage_range_avg_delay (mileage_range, avg_delay) VALUES ('3000-3500', 32);
INSERT INTO flight.mileage_range_avg_delay (mileage_range, avg_delay) VALUES ('2500-3000', 28);
INSERT INTO flight.mileage_range_avg_delay (mileage_range, avg_delay) VALUES ('2000-2500', 24);
INSERT INTO flight.mileage_range_avg_delay (mileage_range, avg_delay) VALUES ('1500-2000', 20);
INSERT INTO flight.mileage_range_avg_delay (mileage_range, avg_delay) VALUES ('0-500', 19);
INSERT INTO flight.mileage_range_avg_delay (mileage_range, avg_delay) VALUES ('1000-1500', 19);
INSERT INTO flight.mileage_range_avg_delay (mileage_range, avg_delay) VALUES ('500-1000', 18);
