create table airline_avg_lat_long
(
    airline_name varchar(50)    null,
    avg_lat      decimal(10, 7) null,
    avg_long     decimal(10, 7) null
);

INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('海南航空', 31.4200000, 113.4800000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('天津航空', 33.2400000, 111.6300000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('新西兰航空', 37.9400000, 117.6500000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('夏威夷航空', 35.3100000, 118.6700000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('东海航空', 31.5400000, 114.4900000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('扬子江航空', 29.9500000, 115.0500000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('中国国航', 33.3400000, 113.0700000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('南方航空', 31.7800000, 112.2500000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('幸福航空', 35.1400000, 113.7400000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('青岛航空', 35.7300000, 114.5400000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('日本航空', 31.4300000, 115.4100000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('山东航空', 33.6100000, 113.8400000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('祥鹏航空', 28.5600000, 106.5200000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('深圳航空', 31.4400000, 114.1500000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('首都航空', 29.9400000, 112.4400000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('香港航空', 42.4800000, 117.3500000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('乌鲁木齐航空', 35.0500000, 99.2800000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('东方航空', 31.9900000, 112.9900000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('成都航空', 30.1900000, 110.8700000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('大新华航空', 36.0000000, 116.9500000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('上海航空', 32.0600000, 117.1100000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('四川航空', 31.3700000, 110.4300000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('春秋航空', 31.8800000, 115.2100000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('西藏航空', 30.7100000, 107.1300000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('长龙航空', 31.6500000, 114.5200000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('澳洲航空', 31.2400000, 117.4300000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('红土航空', 34.7200000, 115.3400000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('华夏航空', 33.2300000, 111.5400000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('重庆航空', 27.7900000, 109.6700000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('福州航空', 30.6100000, 116.0400000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('北欧航空', 30.8700000, 112.8900000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('厦门航空', 31.8100000, 112.4600000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('瑞丽航空', 28.8000000, 105.3000000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('联合航空', 35.6300000, 114.3800000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('全日空航空', 31.8000000, 114.5600000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('九元航空', 31.0600000, 114.7600000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('酷航', 37.6200000, 120.9700000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('吉祥航空', 30.8300000, 115.1500000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('奥凯航空', 29.8700000, 112.2500000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('河北航空', 31.2600000, 114.3200000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('多彩航空', 29.4800000, 111.4300000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('桂林航空', 34.0000000, 113.0200000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('昆明航空', 29.0900000, 111.8500000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('西部航空', 29.9500000, 108.8500000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('北部湾航空', 27.9800000, 111.1400000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('江西航空', 29.3600000, 116.5300000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('长安航空', 26.3800000, 109.0900000);
INSERT INTO flight.airline_avg_lat_long (airline_name, avg_lat, avg_long) VALUES ('英国航空', 31.4200000, 110.1200000);
