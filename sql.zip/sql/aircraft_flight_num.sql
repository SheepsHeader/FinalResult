create table aircraft_flight_num
(
    aircraft_model varchar(50) null,
    flight_count   int         null
);

INSERT INTO flight.aircraft_flight_num (aircraft_model, flight_count) VALUES ('波音737(中)', 6245);
INSERT INTO flight.aircraft_flight_num (aircraft_model, flight_count) VALUES ('空客320(中)', 3697);
INSERT INTO flight.aircraft_flight_num (aircraft_model, flight_count) VALUES ('空客319(中)', 1278);
INSERT INTO flight.aircraft_flight_num (aircraft_model, flight_count) VALUES ('JET', 988);
INSERT INTO flight.aircraft_flight_num (aircraft_model, flight_count) VALUES ('空客321(中)', 787);
INSERT INTO flight.aircraft_flight_num (aircraft_model, flight_count) VALUES ('ERJ-190(中)', 678);
INSERT INTO flight.aircraft_flight_num (aircraft_model, flight_count) VALUES ('庞巴迪CRJ900', 547);
INSERT INTO flight.aircraft_flight_num (aircraft_model, flight_count) VALUES ('其他机型', 457);
INSERT INTO flight.aircraft_flight_num (aircraft_model, flight_count) VALUES ('新舟60(小)', 145);
INSERT INTO flight.aircraft_flight_num (aircraft_model, flight_count) VALUES ('空客330(宽体机)', 108);
INSERT INTO flight.aircraft_flight_num (aircraft_model, flight_count) VALUES ('空客321(窄体机)', 37);
INSERT INTO flight.aircraft_flight_num (aircraft_model, flight_count) VALUES ('波音787(大)', 30);
INSERT INTO flight.aircraft_flight_num (aircraft_model, flight_count) VALUES ('CRJ(小)', 24);
INSERT INTO flight.aircraft_flight_num (aircraft_model, flight_count) VALUES ('ERJ(小)', 20);
INSERT INTO flight.aircraft_flight_num (aircraft_model, flight_count) VALUES ('波音777(大)', 15);
INSERT INTO flight.aircraft_flight_num (aircraft_model, flight_count) VALUES ('波音757(中)', 10);
INSERT INTO flight.aircraft_flight_num (aircraft_model, flight_count) VALUES ('空客380(大)', 5);
INSERT INTO flight.aircraft_flight_num (aircraft_model, flight_count) VALUES ('波音747(大)', 2);
INSERT INTO flight.aircraft_flight_num (aircraft_model, flight_count) VALUES ('波音767(大)', 1);
