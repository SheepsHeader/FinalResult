create table flight_weekly_delay_stats
(
    day_of_week           text   null,
    average_delay_minutes double null
);

INSERT INTO flight.flight_weekly_delay_stats (day_of_week, average_delay_minutes) VALUES ('1_Monday', 20.42);
INSERT INTO flight.flight_weekly_delay_stats (day_of_week, average_delay_minutes) VALUES ('2_Tuesday', 20.58);
INSERT INTO flight.flight_weekly_delay_stats (day_of_week, average_delay_minutes) VALUES ('3_Wednesday', 20.3);
INSERT INTO flight.flight_weekly_delay_stats (day_of_week, average_delay_minutes) VALUES ('4_Thursday', 20.51);
INSERT INTO flight.flight_weekly_delay_stats (day_of_week, average_delay_minutes) VALUES ('5_Friday', 20.34);
INSERT INTO flight.flight_weekly_delay_stats (day_of_week, average_delay_minutes) VALUES ('6_Saturday', 20.68);
INSERT INTO flight.flight_weekly_delay_stats (day_of_week, average_delay_minutes) VALUES ('7_Sunday', 20.23);
