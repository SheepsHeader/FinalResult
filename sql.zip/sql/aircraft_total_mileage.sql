create table aircraft_total_mileage
(
    aircraft_model varchar(50) null,
    total_mileage  bigint      null
);

INSERT INTO flight.aircraft_total_mileage (aircraft_model, total_mileage) VALUES ('波音737(中)', 9147345);
INSERT INTO flight.aircraft_total_mileage (aircraft_model, total_mileage) VALUES ('空客320(中)', 5663535);
INSERT INTO flight.aircraft_total_mileage (aircraft_model, total_mileage) VALUES ('空客319(中)', 1825052);
INSERT INTO flight.aircraft_total_mileage (aircraft_model, total_mileage) VALUES ('JET', 1448157);
INSERT INTO flight.aircraft_total_mileage (aircraft_model, total_mileage) VALUES ('空客321(中)', 1213195);
INSERT INTO flight.aircraft_total_mileage (aircraft_model, total_mileage) VALUES ('ERJ-190(中)', 737358);
INSERT INTO flight.aircraft_total_mileage (aircraft_model, total_mileage) VALUES ('其他机型', 559000);
INSERT INTO flight.aircraft_total_mileage (aircraft_model, total_mileage) VALUES ('庞巴迪CRJ900', 506222);
INSERT INTO flight.aircraft_total_mileage (aircraft_model, total_mileage) VALUES ('空客330(宽体机)', 174805);
INSERT INTO flight.aircraft_total_mileage (aircraft_model, total_mileage) VALUES ('新舟60(小)', 77805);
INSERT INTO flight.aircraft_total_mileage (aircraft_model, total_mileage) VALUES ('空客321(窄体机)', 51260);
INSERT INTO flight.aircraft_total_mileage (aircraft_model, total_mileage) VALUES ('波音787(大)', 46941);
INSERT INTO flight.aircraft_total_mileage (aircraft_model, total_mileage) VALUES ('波音777(大)', 29193);
INSERT INTO flight.aircraft_total_mileage (aircraft_model, total_mileage) VALUES ('CRJ(小)', 20448);
INSERT INTO flight.aircraft_total_mileage (aircraft_model, total_mileage) VALUES ('波音757(中)', 17365);
INSERT INTO flight.aircraft_total_mileage (aircraft_model, total_mileage) VALUES ('ERJ(小)', 16466);
INSERT INTO flight.aircraft_total_mileage (aircraft_model, total_mileage) VALUES ('空客380(大)', 9835);
INSERT INTO flight.aircraft_total_mileage (aircraft_model, total_mileage) VALUES ('波音747(大)', 3280);
INSERT INTO flight.aircraft_total_mileage (aircraft_model, total_mileage) VALUES ('波音767(大)', 1351);
