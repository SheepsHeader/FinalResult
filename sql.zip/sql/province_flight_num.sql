create table province_flight_num
(
    province_name varchar(50)      null,
    flight_count  bigint default 0 not null
);

INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('广东省', 1456);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('北京市', 959);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('云南省', 926);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('上海市', 861);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('四川省', 784);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('山东省', 762);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('浙江省', 704);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('重庆市', 695);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('海南省', 634);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('陕西省', 616);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('辽宁省', 580);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('福建省', 563);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('江苏省', 490);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('新疆维吾尔自治区', 472);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('内蒙古自治区', 439);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('广西壮族自治区', 409);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('黑龙江省', 396);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('河南省', 377);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('贵州省', 367);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('湖北省', 357);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('天津市', 345);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('湖南省', 327);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('甘肃省', 281);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('山西省', 248);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('吉林省', 229);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('江西省', 157);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('宁夏回族自治区', 155);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('安徽省', 149);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('河北省', 146);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('青海省', 99);
INSERT INTO flight.province_flight_num (province_name, flight_count) VALUES ('西藏自治区', 91);
