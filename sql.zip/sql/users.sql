create table users
(
    id       bigint unsigned auto_increment
        primary key,
    username varchar(50)  not null,
    password varchar(100) not null,
    constraint id
        unique (id),
    constraint username
        unique (username)
);

INSERT INTO flight.users (id, username, password) VALUES (1, 'admin', '123456');
INSERT INTO flight.users (id, username, password) VALUES (2, 'yh', '123456');
INSERT INTO flight.users (id, username, password) VALUES (3, 'young', '123456');
INSERT INTO flight.users (id, username, password) VALUES (5, 'uuii', '123456');
INSERT INTO flight.users (id, username, password) VALUES (6, 'woshhiasjdai', '123456');
INSERT INTO flight.users (id, username, password) VALUES (13, '123', 'admin');
