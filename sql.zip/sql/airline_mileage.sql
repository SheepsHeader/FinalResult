create table airline_mileage
(
    airline_name  varchar(50) null,
    total_mileage bigint      null
);

INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('南方航空', 3752072);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('东方航空', 2454619);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('中国国航', 2056660);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('深圳航空', 1837848);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('厦门航空', 1514976);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('海南航空', 1468696);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('山东航空', 1113901);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('四川航空', 699702);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('华夏航空', 697222);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('天津航空', 566511);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('春秋航空', 488779);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('首都航空', 452701);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('吉祥航空', 420566);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('河北航空', 419751);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('祥鹏航空', 413549);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('西藏航空', 357276);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('昆明航空', 343478);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('成都航空', 307091);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('上海航空', 295295);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('长龙航空', 226393);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('东海航空', 200424);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('幸福航空', 165471);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('奥凯航空', 141717);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('西部航空', 134273);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('北部湾航空', 133457);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('九元航空', 109189);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('福州航空', 98840);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('大新华航空', 86213);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('澳洲航空', 75848);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('乌鲁木齐航空', 69150);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('扬子江航空', 65086);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('青岛航空', 61124);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('多彩航空', 55532);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('新西兰航空', 50027);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('瑞丽航空', 42617);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('英国航空', 27135);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('香港航空', 26643);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('红土航空', 26235);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('全日空航空', 25428);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('重庆航空', 18630);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('日本航空', 16868);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('联合航空', 9568);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('桂林航空', 5542);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('江西航空', 4160);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('长安航空', 4134);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('夏威夷航空', 3578);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('北欧航空', 3564);
INSERT INTO flight.airline_mileage (airline_name, total_mileage) VALUES ('酷航', 1074);
