create table flight_weekly_punctuality_stats
(
    day_of_week      text   null,
    punctual_flights bigint null,
    total_flights    bigint null,
    punctuality_rate double null
);

INSERT INTO flight.flight_weekly_punctuality_stats (day_of_week, punctual_flights, total_flights, punctuality_rate) VALUES ('1_Monday', 3934, 10258, 38.35);
INSERT INTO flight.flight_weekly_punctuality_stats (day_of_week, punctual_flights, total_flights, punctuality_rate) VALUES ('2_Tuesday', 4031, 10369, 38.88);
INSERT INTO flight.flight_weekly_punctuality_stats (day_of_week, punctual_flights, total_flights, punctuality_rate) VALUES ('3_Wednesday', 3918, 10288, 38.08);
INSERT INTO flight.flight_weekly_punctuality_stats (day_of_week, punctual_flights, total_flights, punctuality_rate) VALUES ('4_Thursday', 4039, 10447, 38.66);
INSERT INTO flight.flight_weekly_punctuality_stats (day_of_week, punctual_flights, total_flights, punctuality_rate) VALUES ('5_Friday', 4025, 10409, 38.67);
INSERT INTO flight.flight_weekly_punctuality_stats (day_of_week, punctual_flights, total_flights, punctuality_rate) VALUES ('6_Saturday', 4024, 10402, 38.68);
INSERT INTO flight.flight_weekly_punctuality_stats (day_of_week, punctual_flights, total_flights, punctuality_rate) VALUES ('7_Sunday', 3939, 10272, 38.35);
