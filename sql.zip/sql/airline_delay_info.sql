create table airline_delay_info
(
    name      text   null,
    avg_delay double null
);

INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('中国国航', 14.98);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('南方航空', 17.38);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('厦门航空', 19.55);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('海南航空', 15.83);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('山东航空', 15.43);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('天津航空', 17.07);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('祥鹏航空', 24.3);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('深圳航空', 15.01);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('首都航空', 17.53);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('华夏航空', 14.81);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('东方航空', 15.48);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('四川航空', 17.55);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('瑞丽航空', 18.48);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('吉祥航空', 11.06);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('成都航空', 24.81);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('春秋航空', 10.42);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('奥凯航空', 28.4);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('新西兰航空', 11.94);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('西藏航空', 16.31);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('联合航空', 24);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('重庆航空', 11.35);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('全日空航空', 8.61);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('昆明航空', 16.79);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('河北航空', 19.7);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('福州航空', 17.41);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('大新华航空', 14.76);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('香港航空', 13.94);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('长龙航空', 15.27);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('上海航空', 16.25);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('夏威夷航空', 15.67);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('东海航空', 20.65);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('澳洲航空', 11.67);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('幸福航空', 10.64);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('九元航空', 24.77);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('红土航空', 40.15);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('青岛航空', 18.18);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('多彩航空', 17.5);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('西部航空', 17.26);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('北部湾航空', 15.77);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('扬子江航空', 8.74);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('英国航空', 19.58);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('日本航空', 6.15);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('乌鲁木齐航空', 49.13);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('酷航', 21);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('桂林航空', 37);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('江西航空', 10);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('长安航空', 16.5);
INSERT INTO flight.airline_delay_info (name, avg_delay) VALUES ('北欧航空', 15);
