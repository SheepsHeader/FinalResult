create table mileage_range_flight_num
(
    mileage_range varchar(50) null,
    flight_count  int         null
);

INSERT INTO flight.mileage_range_flight_num (mileage_range, flight_count) VALUES ('1000-1500', 4484);
INSERT INTO flight.mileage_range_flight_num (mileage_range, flight_count) VALUES ('500-1000', 3404);
INSERT INTO flight.mileage_range_flight_num (mileage_range, flight_count) VALUES ('1500-2000', 3323);
INSERT INTO flight.mileage_range_flight_num (mileage_range, flight_count) VALUES ('2000-2500', 1726);
INSERT INTO flight.mileage_range_flight_num (mileage_range, flight_count) VALUES ('0-500', 996);
INSERT INTO flight.mileage_range_flight_num (mileage_range, flight_count) VALUES ('2500-3000', 565);
INSERT INTO flight.mileage_range_flight_num (mileage_range, flight_count) VALUES ('3000-3500', 340);
INSERT INTO flight.mileage_range_flight_num (mileage_range, flight_count) VALUES ('3500+', 236);
