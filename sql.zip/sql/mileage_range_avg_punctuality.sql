create table mileage_range_avg_punctuality
(
    mileage_range   text   not null,
    avg_punctuality double null
);

INSERT INTO flight.mileage_range_avg_punctuality (mileage_range, avg_punctuality) VALUES ('0-500', 0.85);
INSERT INTO flight.mileage_range_avg_punctuality (mileage_range, avg_punctuality) VALUES ('500-1000', 0.85);
INSERT INTO flight.mileage_range_avg_punctuality (mileage_range, avg_punctuality) VALUES ('1000-1500', 0.84);
INSERT INTO flight.mileage_range_avg_punctuality (mileage_range, avg_punctuality) VALUES ('1500-2000', 0.82);
INSERT INTO flight.mileage_range_avg_punctuality (mileage_range, avg_punctuality) VALUES ('2000-2500', 0.79);
INSERT INTO flight.mileage_range_avg_punctuality (mileage_range, avg_punctuality) VALUES ('2500-3000', 0.75);
INSERT INTO flight.mileage_range_avg_punctuality (mileage_range, avg_punctuality) VALUES ('3000-3500', 0.74);
INSERT INTO flight.mileage_range_avg_punctuality (mileage_range, avg_punctuality) VALUES ('3500+', 0.66);
